# V91 · El Patufet i els antics locals del Tabalet

La cronologia arriba a 218 fites. El Patufet, al carrer de Mossèn Molé, 10, té dues fites sobre el cessament i els seus efectes des de la fi del curs 2005–2006. Es registra com a llar històrica a la cronologia.

Del Tabalet es documenta un acte informatiu sobre el nou edifici el 2002 i dos usos comunitaris després del trasllat. La memòria de l’IME (H163, p. 29) identifica el monogràfic d’El Punt Maresme del 5 de maig de 2002 i una guia amb adreces. L’hemeroteca del Museu Arxiu de Santa Maria conserva l’edició Maresme d’El Punt del 1995 al 2004 ([catàleg](https://masmm.org/hemeroteca.html)). Queda pendent consultar l’exemplar i els expedients de cessió per situar els dos locals.
