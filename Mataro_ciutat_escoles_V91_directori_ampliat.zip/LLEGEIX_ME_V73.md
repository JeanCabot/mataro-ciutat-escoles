# V73 · Portals i seus compartides

Set fitxes contrastades amb el geocodificador oficial. Sis tenen un punt vigent i una identifica l’antiga seu del Liceu al Centre Catòlic. El registre de seus incorpora la geometria del GEM Petit. El número 6 de la plaça dels Bous (Balmes) queda pendent de contrast.

| Codi | Portal | Font del centre | Coordenades |
| --- | --- | --- | --- |
| 08060253 | Plaça dels Bous, 5 | [Font](https://cfacanmarfa.cat/contacte/) | [41.54217112, 2.44457893](https://eines.icgc.cat/geocodificador/cerca?text=pla%C3%A7a+dels+Bous+5%2C+Matar%C3%B3&layers=address&size=4) |
| 08021302 | Plaça dels Bous, 5 | [Font](https://www.idc.cat/media/files/file_661_25165.pdf) | [41.54217112, 2.44457893](https://eines.icgc.cat/geocodificador/cerca?text=pla%C3%A7a+dels+Bous+5%2C+Matar%C3%B3&layers=address&size=4) |
| 08067661 | Carrer de Sant Pere, 4 | [Font](https://www.coromines.cat/lescola/som) | [41.53880365, 2.44932599](https://eines.icgc.cat/geocodificador/cerca?text=carrer+Sant+Pere+4%2C+Matar%C3%B3&layers=address&size=4) |
| 08021168 | Carrer d’Àvila, 9–43 | [Font](https://escolagem.cat/contacta/) | [41.54875397, 2.43986009](https://eines.icgc.cat/geocodificador/cerca?text=carrer+%C3%80vila+9%2C+Matar%C3%B3&layers=address&size=4) |
| 08065123 | Avinguda de Josep Puig i Cadafalch, 80 | [Font](https://documents.espai.educacio.gencat.cat/IPCNormativa/DisposicionsInternes/20260205_resolucio_llista_pfi_2025_2026.pdf) | [41.54068826, 2.43072849](https://eines.icgc.cat/geocodificador/cerca?text=avinguda+Puig+i+Cadafalch+80%2C+Matar%C3%B3&layers=address&size=4) |
| 08021089 | Avinguda de Josep Puig i Cadafalch, 80 | [Font](https://mataro.salesians.cat/contacte/) | [41.54068826, 2.43072849](https://eines.icgc.cat/geocodificador/cerca?text=avinguda+Puig+i+Cadafalch+80%2C+Matar%C3%B3&layers=address&size=4) |
| 08057126 | Plaça dels Bous, 1 | [Font](https://www.conservatoriliceu.es/noticies/escoles/xarxa-escoles-liceu-incorporacio-maristes-valldemia/) | [41.54209848, 2.44420953](https://eines.icgc.cat/geocodificador/cerca?text=pla%C3%A7a+dels+Bous+1%2C+Matar%C3%B3&layers=address&size=4) |
