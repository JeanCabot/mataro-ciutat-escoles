# V74 · Ubicacions de Balmes, l’Hospital i escoles bressol

Els dispositius hospitalaris comparteixen el punt aproximat del recinte. L’accés interior queda pendent. El cens original de Balmes recull el 6 i el web del centre publica l’1 com a contacte.

| Codi | Portal de referència ICGC | Coordenades (latitud, longitud) |
| --- | --- | --- |
| 08021016 | [plaça dels Bous 1](https://eines.icgc.cat/geocodificador/cerca?text=pla%C3%A7a+dels+Bous+1%2C+Matar%C3%B3&layers=address&size=4) | 41.54209848, 2.44420953 |
| 08062407 | [carretera de Cirera 230](https://eines.icgc.cat/geocodificador/cerca?text=carretera+de+Cirera+230%2C+Matar%C3%B3&layers=address&size=4) | 41.55630188, 2.42894669 |
| 08077277 | [carretera de Cirera 230](https://eines.icgc.cat/geocodificador/cerca?text=carretera+de+Cirera+230%2C+Matar%C3%B3&layers=address&size=4) | 41.55630188, 2.42894669 |
| 08067302 | [carrer Major 66](https://eines.icgc.cat/geocodificador/cerca?text=carrer+Major+66%2C+Matar%C3%B3&layers=address&size=4) | 41.54259374, 2.42758778 |
| 08062547 | [carrer del Rierot 2](https://eines.icgc.cat/geocodificador/cerca?text=carrer+del+Rierot+2%2C+Matar%C3%B3&layers=address&size=4) | 41.54380439, 2.44734303 |
| 08070209 | [carrer de Bonaire 14](https://eines.icgc.cat/geocodificador/cerca?text=carrer+de+Bonaire+14%2C+Matar%C3%B3&layers=address&size=4) | 41.54146139, 2.44527589 |
| 08066826 | [carrer de Creteil 41](https://eines.icgc.cat/geocodificador/cerca?text=carrer+de+Creteil+41%2C+Matar%C3%B3&layers=address&size=4) | 41.55401591, 2.4473054 |
| 08074291 | [camí ral 371](https://eines.icgc.cat/geocodificador/cerca?text=cam%C3%AD+ral+371%2C+Matar%C3%B3&layers=address&size=4) | 41.53731626, 2.44498138 |
| 08050235 | [carrer de Sant Joan Bosco 25](https://eines.icgc.cat/geocodificador/cerca?text=carrer+de+Sant+Joan+Bosco+25%2C+Matar%C3%B3&layers=address&size=4) | 41.53940366, 2.42425945 |
| 08076790 | [carrer de Vallespir 2](https://eines.icgc.cat/geocodificador/cerca?text=carrer+de+Vallespir+2%2C+Matar%C3%B3&layers=address&size=4) | 41.55366764, 2.45904472 |
