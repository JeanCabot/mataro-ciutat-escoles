# V82 · Colors dels marcadors

La llegenda del visor comparteix la paleta dels marcadors. Els punts tenen farciment opac i contorn blanc. Les seus secundàries comparteixen el color del centre.

- Blau · centres públics d’educació obligatòria
- Vermell · centres privats i concertats d’educació obligatòria
- Verd · altres centres, acadèmies i universitats
- Groc daurat · acadèmies de reforç
- Lila · lleure i casals
