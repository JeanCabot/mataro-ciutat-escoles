# V90 · Contrast de la cronologia de tres centres

La cronologia arriba a 213 fites. Dues addendes del Tabalet documenten el trasllat i els canvis de capacitat de 2004 i 2010. El directori de formació de persones adultes de març de 2008 confirma l’oferta diferenciada del Col·legi Salesià (08065123) i Sant Antoni de Pàdua (08021089), tots dos a la mateixa adreça.

La memòria municipal dels Projectes Singulars fa recular la primera activitat documentada de Picasoques al curs 2022–2023. Queden pendents l’autorització i el primer curs d’obertura, l’acte d’assignació del codi del Col·legi Salesià i les adreces dels dos antics locals del Tabalet.
