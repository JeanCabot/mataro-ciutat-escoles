# V78 · Contrast de les darreres adreces del cens

S’han contrastat 14 punts. Cenafe Mataró queda pendent de confirmació d’activitat presencial a la seu del cens. També queden pendents els dos accessos interiors de l’Hospital de Mataró.

El Turó adopta el número 46 publicat pel centre; el cens indica el 34. Les Cinc Sénies conserva el número 60 i utilitza el punt del mapa enllaçat per l’institut. El geocodificador de l’ICGC havia retornat el 59, a l’altra banda de la ronda.

La fitxa de l’Escola Pia indica les seves tres seus i localitza la de primària. Roques Albes continua pendent d’un marcador propi. L’ICGC retorna el número 1 del carrer de Galícia, documentat en un [acte municipal del 2021](https://entitatsmataro.cat/lajuntament/oferta-ocupacio-publica/acces-lliure/ofertes/auxiliar-administratiu-iva-via-ordinaria/acta-de-sessio-aux-adm.pdf), mentre que el web de l’institut indica el carrer sense número.

[Directori d’ensenyaments esportius](https://repositori.educacio.gencat.cat/bitstream/handle/20.500.12694/1999/tegm_8201_ca_2021.pdf?isAllowed=y&sequence=1) i [preinscripció de Cenafe](https://www.cenafe.es/preinscripcion-online/cataluna/cenafe-mataro).

| Centre | Adreça de partida | Referència cartogràfica | Coordenades (latitud, longitud) |
| --- | --- | --- | --- |
| [El Turó](https://www.escolaelturo.cat/contacte/) | rda. Roca Blanca, 34 | [Ronda de la Roca Blanca, 46](https://eines.icgc.cat/geocodificador/cerca?text=Ronda+de+la+Roca+Blanca+46%2C+Matar%C3%B3&layers=address&size=4) | 41.54455791, 2.42712606 |
| [Esc. de Música El Carreró](https://elcarrero.com/) | c. El Carreró, 33 | [Carrer El Carreró, 33](https://eines.icgc.cat/geocodificador/cerca?text=Carrer+El+Carrer%C3%B3+33%2C+Matar%C3%B3&layers=address&size=4) | 41.5401933, 2.44592542 |
| [Escola de Dansa Heidi Consegal](https://www.cambrils.cat/ca/serveis/educacio/fitxers/escola-de-dansa/danl48-30000_ca.pdf/@@download/file/DANL48.30000_CA.pdf) | c. Concepció, 11 | [Carrer de la Concepció, 11](https://eines.icgc.cat/geocodificador/cerca?text=Carrer+de+la+Concepci%C3%B3+11%2C+Matar%C3%B3&layers=address&size=4) | 41.53964824, 2.44045095 |
| [Escola Germanes Bertomeu](https://agora.xtec.cat/escolagermanesbertomeu/) | c. Colòmbia, 15 | [Carrer de Colòmbia, 15](https://eines.icgc.cat/geocodificador/cerca?text=Carrer+de+Col%C3%B2mbia+15%2C+Matar%C3%B3&layers=address&size=4) | 41.54827816, 2.44848917 |
| [Escola Maria-Mercè Marçal](https://agora.xtec.cat/escola-mmm-mataro/lescola/on-som/) | Riera de Figuera Major, 60 | [Riera de Figuera Major, 60](https://eines.icgc.cat/geocodificador/cerca?text=Riera+de+Figuera+Major+60%2C+Matar%C3%B3&layers=address&size=4) | 41.55298806, 2.4413509 |
| [Escola Marta Mata](https://agora.xtec.cat/esc-mmata-mataro/) | c. Aristòtil, 23 | [Carrer d'Aristòtil, 23](https://eines.icgc.cat/geocodificador/cerca?text=Carrer+d%27Arist%C3%B2til+23%2C+Matar%C3%B3&layers=address&size=4) | 41.55096026, 2.43456702 |
| [Escola Pia de Mataró](https://mataro.escolapia.cat/contacte/) | pl. Santa Anna, 1 | [Plaça de Santa Anna, 1](https://eines.icgc.cat/geocodificador/cerca?text=Pla%C3%A7a+de+Santa+Anna+1%2C+Matar%C3%B3&layers=address&size=4) | 41.53793588, 2.44433985 |
| [Institut Les Cinc Sénies](https://agora.xtec.cat/inslescincsenies/) | rda. de Rafael Estrany, 60 | [Mapa enllaçat pel centre](https://www.google.com/maps/place/Institut+P%C3%BAblic+Cinc+S%C3%A9nies/@41.5530971,2.4496593,16.08z/data=!4m5!3m4!1s0x0:0x26533bb97c51a221!8m2!3d41.552064!4d2.4492587) | 41.552064, 2.4492587 |
| [Llar d'infants La Fada](https://repositori.educacio.gencat.cat/bitstream/handle/20.500.12694/6429/Educaci%C3%B3%20infantil_0_3_anys.pdf?isAllowed=y&sequence=1) | rda. Alfons X, el Savi, 131, baixos | [Ronda d'Alfons X el Savi, 131](https://eines.icgc.cat/geocodificador/cerca?text=Ronda+d%27Alfons+X+el+Savi+131%2C+Matar%C3%B3&layers=address&size=4) | 41.54577903, 2.45000986 |
| [Mare de Déu de Lourdes](https://mdlourdes.cat/contacte/) | c. Ramon Llull, 5/c. Altafulla | [Carrer de Ramon Llull, 5](https://eines.icgc.cat/geocodificador/cerca?text=Carrer+de+Ramon+Llull+5%2C+Matar%C3%B3&layers=address&size=4) | 41.53985609, 2.43839341 |
| [Maristes Valldemia](https://www.maristasmurcia.com/wp-content/uploads/2026/01/151731_Directorio_Marista_2026_FINAL.pdf) | c. de la Riera, 124-182 | [La Riera, 124](https://eines.icgc.cat/geocodificador/cerca?text=La+Riera+124%2C+Matar%C3%B3&layers=address&size=4) | 41.54384402, 2.44273957 |
| [Meritxell](https://www.fundaciomeritxell.cat/faqs/) | c. Passet, 16 | [Carrer d'en Passet, 16](https://eines.icgc.cat/geocodificador/cerca?text=Carrer+d%27en+Passet+16%2C+Matar%C3%B3&layers=address&size=4) | 41.55597648, 2.46435942 |
| [Sant Josep](https://colegiosanjosemataro.com/contacte/) | rda. Cerdanya, 39 | [Ronda de la Cerdanya, 39](https://eines.icgc.cat/geocodificador/cerca?text=Ronda+de+la+Cerdanya+39%2C+Matar%C3%B3&layers=address&size=4) | 41.54290845, 2.42222156 |
| [Sol-Ixent](https://www.escolasol-ixent.cat/contacte/) | av. Gatassa, 68-86 | [Avinguda de la Gatassa, 68](https://eines.icgc.cat/geocodificador/cerca?text=Avinguda+de+la+Gatassa+68%2C+Matar%C3%B3&layers=address&size=4) | 41.53808304, 2.42759139 |
