# V83 · Fonts al visor cronològic

Les 75 dates de primera aparició s’han conciliat amb l’auditoria d’orígens i la taula de fites. La fitxa exposa la data, l’afirmació que documenta la font i un enllaç a la cronologia filtrada pel centre. El visor avisa que els marcadors del període seleccionat són les adreces del directori actual.

L’Escola Pia permet distingir l’establiment del 1737 de l’obertura del gener de 1738. A l’Institut Miquel Biada, el 1886 correspon a l’Escola d’Arts i Oficis, antecedent de l’institut.

Es mantenen les 168 fites existents i les dates de la V82. L’auditoria conserva els casos pendents de contrast de la documentació original.
