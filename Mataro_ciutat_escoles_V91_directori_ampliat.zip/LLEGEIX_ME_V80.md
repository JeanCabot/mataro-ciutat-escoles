# V80 · Seus docents al mapa

L’Escola Pia incorpora El Torrent i Mar. L’Institut Josep Puig i Cadafalch incorpora Roques Albes com a punt orientatiu. Cada centre manté una sola fitxa, amb botons per explorar les seus a la vista Actualitat.

| Seu | Coordenades (latitud, longitud) | Font |
| --- | --- | --- |
| Escola Pia de Mataró · El Torrent, 62 | 41.53911369, 2.44167749 | [Centre](https://mataro.escolapia.cat/lescola/installacions/) |
| Escola Pia de Mataró · Carrer de Sant Agustí, 59 | 41.53542481, 2.44624707 | [Centre](https://mataro.escolapia.cat/lescola/installacions/) |
| Institut Josep Puig i Cadafalch · Carrer de Galícia | 41.54604091, 2.42715768 | [Centre](https://inspuig.org/wp/centre/contacte-i-situacio/) |
