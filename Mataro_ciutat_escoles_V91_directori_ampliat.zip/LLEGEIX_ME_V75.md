# V75 · Filtres i colors del mapa

La portada obre amb Educació obligatòria activada. El punt al costat de cada filtre coincideix amb els marcadors del mapa.

- Verd · Educació obligatòria
- Blau · Altres centres, acadèmies i universitats
- Taronja · Acadèmies de reforç
- Lila · Lleure i casals

El filtre de titularitat s’aplica a l’educació obligatòria. Els centres amb estat d’activitat documentat com a tancat o inactiu mantenen el color de la categoria i es distingeixen amb un contorn discontinu i menys intensitat.
