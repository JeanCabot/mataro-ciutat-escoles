# V86 · Seus provisionals i projectes d’edifici

La cronologia passa de 183 a 190 fites. Les Cinc Sénies incorpora les cessions de 2017 i 2019 i la licitació de 2026. El Joan Coromines incorpora la presentació de la proposta, el lliurament de l’avantprojecte i la resposta parlamentària sobre el projecte executiu. Les fites administratives no acrediten l’obertura dels edificis definitius.

A l’Escola Municipal de Música, el balanç municipal confirma l’inici de les classes de l’1 d’octubre de 2009. L’acte inaugural a l’Institut Miquel Biada, el 30 de setembre, queda documentat per separat. El filtre anual conserva 2009 com a primer any.
