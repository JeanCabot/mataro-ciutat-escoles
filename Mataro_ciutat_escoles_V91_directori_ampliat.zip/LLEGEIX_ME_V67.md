# V67 · Xarxes i pàgina web oficial

Les fitxes admeten diversos perfils socials. El compte del Servei d’Ocupació de Mataró consta a les [preguntes freqüents municipals](https://www.mataro.cat/ca/ocupacio/persones/imatges-i-arxius-2/doc_faq_persones-v2.pdf).
