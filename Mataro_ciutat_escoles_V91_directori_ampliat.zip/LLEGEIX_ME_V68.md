# V68 · Perfils socials

- [Punt Òmnia CCC Mataró](https://xarxaomnia.gencat.cat/cercaelteupunt) · [Perfils generals de la Xarxa Òmnia](https://linktr.ee/xarxaomnia).
- [Canal de l’Escola Camí del Cros](https://www.youtube.com/channel/UCvqAB6O1_Zewu_TYsJJd28g).
- [Facebook d’El Xumet al directori](https://www.nomas900.org/escola-el-xumet-251911), amb el web i telèfon coincidents amb [el centre](https://elxumet.es/).
