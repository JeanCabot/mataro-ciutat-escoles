# V87 · Obertures de les escoles bressol

La cronologia recull 193 fites i 160 fonts registrades. Els Menuts va començar l’activitat el 8 de gener de 2007 i es va inaugurar el dia 20. Els Garrofers va obrir el 8 de setembre de 2009 i va celebrar la inauguració el 25 d’octubre.

L’estrena oficial de l’edifici del Tabalet queda datada el 18 de gener de 2004. El centre ja funcionava en dues ubicacions anteriors. Al registre d’Elna s’incorpora una segona font que confirma l’obertura el setembre de 2007.
