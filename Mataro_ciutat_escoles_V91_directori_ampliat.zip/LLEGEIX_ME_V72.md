# V72 · Seus i fitxes compartides

- GiEscola es publica una vegada, amb el codi 08078877. El registre històric d’incorporacions conserva la referència MAT-gi-arts. [Font](https://es.giescola.com/)
- L’Escola Municipal de Música mostra la Nau Minguell com a seu central. El punt correspon al lloc de l’equipament que enllaça el centre. El registre de seus manté l’observació d’Antonio Machado, una seu docent que també figura al web. [Font](https://www.emmmataro.cat/contacte/)
- Biblioteca Popular i Aules Sènior conserven el portal compartit i indiquen les plantes. [Biblioteca](https://www.culturamataro.cat/biblioteca-popular) · [Aules Sènior](https://auleseniormataro.org/contacte/)

163 fitxes al directori. Queden 71 coordenades marcades com a pendents de contrast.
