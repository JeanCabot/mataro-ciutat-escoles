# V79 · Titularitat al mapa

Els centres d’educació obligatòria s’identifiquen en verd si són públics i en granat si són privats o concertats. La llegenda mostra els dos colors al costat del filtre de titularitat.
