# V84 · Contrast de la cronologia escolar

La cronologia passa de 168 a 175 fites amb 138 registres de fonts. Les 75 primeres dates del visor es conserven.

- Anxaneta. Primeres classes a Can Serradures (octubre de 1965), inici del curs com a escola fusionada amb el Ravalet (setembre de 1994), trasllat a Antoni Solís (abril de 2007) i resolució de trasllat (juny de 2007).
- Antonio Machado. La mateixa resolució documenta el trasllat del CEIP de Mataró a la plaça d’Antonio Machado.
- Les Aigües. La cronologia conserva 1966–1967 i 1968, dues datacions publicades sobre l’escola predecessora Santa Bernadeta.
- Sant Josep. El web del centre indica 1968 i el document de caràcter propi indica 1970. El 4 de gener de 1970 correspon a la benedicció i el 6 de setembre a la constitució canònica de la comunitat. L’inici de classes queda pendent de datar.

Les taules V84 conserven els identificadors existents. Les versions V24 resten dins del paquet com a documentació anterior.
