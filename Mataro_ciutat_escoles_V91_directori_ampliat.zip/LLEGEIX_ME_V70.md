# V70 · Xarxes

- Acadèmia A Punt Mataró · [LinkedIn de l’acadèmia](https://es.linkedin.com/company/acad%C3%A8mia-a-punt-matar%C3%B3).
- Musical Mataró · [Facebook documentat al directori](https://www.nomas900.org/musical-mataro-s-l--476785), amb el mateix web i adreça.
