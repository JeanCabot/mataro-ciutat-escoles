# V89 · Llars d’infants privades històriques

La cronologia arriba a 208 fites. El Jardí i Mimus tenen filtre propi. S’hi distingeixen l’autorització d’obertura de 1993, la fi de curs en què el cessament va tenir efectes i la resolució de desembre de 2000. Es referencia la fotografia d’El Jardí de 1993 al Museu Arxiu de Santa Maria.

L’apartat de llars d’infants històriques recull també Picarol, Els Esclops i Napbuf. El 1984 de La Gralla continua pendent de confirmació amb una font datada.
