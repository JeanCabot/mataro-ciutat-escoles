# V85 · Escoles i edificis del període 2007–2014

La cronologia passa de 175 a 183 fites. Es contrasten quatre entrades en funcionament del curs 2007–2008 amb l’acta municipal i es documenten els edificis definitius de Montserrat Solà, Maria-Mercè Marçal i Marta Mata.

La V85 diferencia inici d’obres, entrada en ús, integració d’alumnat i actes inaugurals. A Marta Mata es mantenen les datacions divergents sobre l’ocupació per etapes i queda pendent contrastar-les amb un document contemporani. Es conserven les 75 dates de primera aparició del mapa.
