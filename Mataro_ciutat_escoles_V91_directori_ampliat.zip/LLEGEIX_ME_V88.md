# V88 · Els orígens de la xarxa d’escoles bressol

La cronologia recull 201 fites. El filtre de la xarxa municipal mostra sis fites col·lectives entre el primer grup de guarderies municipals de 1978 i la integració de l’Institut Municipal d’Educació a l’Ajuntament el 2013.

S’hi afegeixen dues fites del Tabalet anteriors a l’estrena de l’edifici actual. La memòria de l’IME documenta el local Tabalet I el 2002. El desembre de 2003, l’Ajuntament confirma que el Tabalet acollia 56 infants en dos locals del Pla d’en Boet. L’obertura inicial i els dos portals queden pendents.

L’apartat de llars d’infants històriques recull La Gralla al carrer d’Altafulla, 20. El 1984 es recull com a aportació pendent de confirmació documental.
