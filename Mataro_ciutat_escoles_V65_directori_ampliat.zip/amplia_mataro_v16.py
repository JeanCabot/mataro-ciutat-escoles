from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile,collections,subprocess
B=Path(__file__).parent;out=B/'mataro_escoles_v16';shutil.copytree(B/'mataro_escoles_v15',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,rows):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['codi_centre','centre','id_esdeveniment','tipus','data','id_font','afirmacio','decisio']);w.writeheader();w.writerows(rows)
a=read('mataro_centres_2026_2027.csv');am={r['codi_centre']:r for r in a};E=read('esdeveniments_historics_v15.csv');F=read('fonts_historiques_v15.csv');fm={r['id_font']:r for r in F}
def src(i,t,u,typ):
 r=dict(id_font=i,titol=t,url=u,consulta='2026-11-18',tipus=typ,abast='Fets i límits indicats en les fites i la revisió');F.append(r);fm[i]=r
src('H103','BOE — Ordre de 15 de juny de 1976, posada en funcionament de col·legis EGB','https://www.boe.es/boe/dias/1976/06/30/pdfs/A12802-12803.pdf','normativa; text íntegre consultat, pàgina 12803')
src('H104','25 anys fent camí. Escola pública Àngela Bransuela, 2002','https://capitaleconomiasocial.mataro.cat/ca/actualitat/publicacions/ensenyament/25-anys-fent-cami-escola-publica-angela-bransuela','publicació commemorativa escolar publicada per l’Ajuntament')
src('H105','Institut Escola Mar Mediterrània — L’Escola','https://agora.xtec.cat/iemarmediterrania/lescola/','història institucional del centre; web XTEC')
def ev(c,k,d,f,claim,loc,notes,end=None):
 E.append(dict(id_esdeveniment='HIST-'+str(max(int(x['id_esdeveniment'].split('-')[1]) for x in E)+1).zfill(3),id_entitat='ENT-'+c,codi_actual_referencia=c,centre=am[c]['nom'],tipus=k,data_min=d,data_max=end or d,precisio='curs' if end else 'any' if len(d)==4 else 'dia',afirmacio=claim,id_font=f,font_url=fm[f]['url'],localitzador=loc,estat='documentat; contrast parcial',notes=notes))




ev('08076157','autoritzacio_predecessor','1976-06-15','H103','L’Ordre de 15 de juny de 1976 autoritza la posada en funcionament del col·legi nacional Àngela Bransuela, amb 640 places escolars.','BOE 156, 30-06-1976, p. 12803, disposició 12587, apartat Mataró','Predecessor de primària; no és l’alta del codi actual de l’institut escola ni el primer dia de classes. La publicació commemorativa situa la inauguració al curs 1977–1978.')
ev('08076157','inauguracio_predecessor','1977','H104','La cronologia de la publicació escolar situa la inauguració de l’escola Àngela Bransuela al curs 1977–1978.','Pàgina numerada 5, cronologia, entrada 1977–1978','Afirmació retrospectiva explícita; es conserva separada de l’autorització de 1976. No s’infereix un dia exacte.',end='1978')
ev('08076145','creacio_predecessor','1976','H105','La història institucional de Mar Mediterrània situa la creació de l’escola predecessora Tomàs Viñas l’any 1976.','L’Escola, segon paràgraf del cos principal','Data del predecessor, no del codi actual: la mateixa font situa el naixement de l’institut escola al curs 2018–2019, ja documentat al conjunt.')
E.sort(key=lambda e:(e['data_min'],e['id_esdeveniment']));counts=collections.Counter(e['codi_actual_referencia'] for e in E)
assert len(E)==134 and len(counts)==73
write('esdeveniments_historics_v16.csv',E);write('fonts_historiques_v16.csv',F)
changes=[]
for c,eid,typ in [('08076157','HIST-132','autorització de funcionament del predecessor de primària'),('08076145','HIST-134','creació del predecessor Tomàs Viñas; IE des de 2018')]:
 r=am[c];e=next(e for e in E if e['id_esdeveniment']==eid)
 changes.append(dict(codi_centre=c,centre=r['nom'],tipus_anterior=r['tipus_data_origen'],data_anterior=r['origen_data_min'],nou_tipus=typ,nova_data_min=e['data_min'],nova_data_max=e['data_max'],id_esdeveniment=eid,id_font=e['id_font'],limit=e['notes']))
 r.update(tipus_data_origen=typ,origen_data_min=e['data_min'],origen_data_max=e['data_max'],fundacio_any='',fundacio_font=e['font_url'],estat_recerca_historica='origen del predecessor documentat; separat de la creació de l’institut escola')
for r in a:r['nombre_fites_documentades']=counts[r['codi_centre']]
write('revisio_origens_v16.csv',changes);write('mataro_centres_2026_2027.csv',a)
g=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in g['features']:f['properties']=am[f['properties']['codi_centre']]
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(g,ensure_ascii=False,indent=2))
write('registre_recerca_v16.csv',[dict(data_consulta='2026-11-18',via='Font institucional',consulta=f['titol'],resultat='Text consultat; fites i límits detallats a HIST-132–134.',limit='Antecedents de primària; no dates fundacionals dels codis actuals.') for f in F if f['id_font'] in {'H103','H104','H105'}])
# Audit is rebuilt from the updated canonical data and events.
by=collections.defaultdict(list)
for e in E:by[e['codi_actual_referencia']].append(e)
audit=[]
for r in a:
 c=r['codi_centre'];es=sorted(by[c],key=lambda e:(e['data_min'],e['id_esdeveniment']));first=es[0] if es else {};typ=r['tipus_data_origen'];d=r['origen_data_min']
 if not d:cat='camp d’origen buit; recerca pendent'
 elif 'antecedent' in typ or 'patronat' in typ or 'predecessor' in typ:cat='antecedent; no obertura del centre actual'
 elif 'autorització' in typ:cat='autorització d’obertura; no primeres classes'
 elif 'administrativa' in typ or 'creació' in typ or 'transformació' in typ or typ=='creacio_escola':cat='constitució o creació; classes pendents de distingir'
 elif 'projecte' in typ:cat='inici de projecte; no autorització del codi'
 else:cat='data d’origen declarada; contrast segons font'
 specific={
 '08065123':'Conciliar codis 08065123 i 08021089 i trobar autorització pròpia. No heretar 1905 ni 2004.',
 '08078695':'Autorització i primer curs pendents. Corregir coordenada del CSV només amb portal 27 documentat.',
 '08073946':'Autorització i efectes legals confirmats; primer curs real i relació amb Pinotxo pendents.',
 '08078877':'2012 és consolidació del projecte segons la directora; alta del codi i autorització de cicles pendents.',
 '08056948':'2015 és actuació escolar; no és fundació ni autorització.',
 '08021181':'Conciliar 1968/1970: classes inicials, comunitat religiosa i actes d’inauguració.',
 }
 audit.append(dict(codi_centre=c,centre=r['nom'],fites_documentades=len(es),categoria_origen=cat,tipus_data_origen=typ,origen_data_min=d,origen_data_max=r['origen_data_max'],font_origen=r['fundacio_font'],primera_fita_id=first.get('id_esdeveniment',''),primera_fita_data=first.get('data_min',''),primera_fita_tipus=first.get('tipus',''),primera_fita_font=first.get('font_url',''),control='Primera fita cronològica no equival a fundació.',tasca_prioritaria=specific.get(c,'Precisar què data la font d’origen i contrastar-la.' if d else 'Cercar origen del centre; no adoptar la primera fita com a fundació.')))
write('auditoria_origens_v16.csv',audit);stats=collections.Counter(x['categoria_origen'] for x in audit);norigin=sum(bool(x['origen_data_min']) for x in audit);assert norigin==56
# Candidates are extracted from documented events but do not silently overwrite canonical origins.
missing=[e for e in E if not next(r for r in a if r['codi_centre']==e['codi_actual_referencia'])['origen_data_min'] and e['tipus'] in {'origen_declarat','inauguracio_escola','antecedent_aulari','consolidacio_projecte_escolar','autoritzacio_obertura'}]
write('pistes_origen_per_revisar_v16.csv',[dict(codi_centre=e['codi_actual_referencia'],centre=e['centre'],id_esdeveniment=e['id_esdeveniment'],tipus=e['tipus'],data=e['data_min'],id_font=e['id_font'],afirmacio=e['afirmacio'],decisio='Candidat de revisió; no afegit al camp canònic d’origen automàticament.') for e in missing])
chron=(out/'cronologia.html').read_text();opts='<option value="">Tots els centres documentats</option>'+''.join('<option value="'+c+'">'+html.escape(n)+'</option>' for c,n in sorted({(e['codi_actual_referencia'],e['centre']) for e in E},key=lambda x:x[1]));chron=re.sub(r'(<select id="centre">).*?(</select>)',lambda m:m[1]+opts+m[2],chron,count=1,flags=re.S)
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['data_min']+'–'+e['data_max'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(fm[e['id_font']]['titol'])+' · '+html.escape(e['localitzador'])+'</a></p></article>' for e in E)
chron=re.sub(r'<article.*?</article>(?:<article.*?</article>)*',lambda m:items,chron,count=1,flags=re.S).replace('131 fites documentades de 73 dels 75 registres de base (97,3%)','134 fites documentades de 73 dels 75 registres de base (97,3%)').replace('V15','V16');(out/'cronologia.html').write_text(chron)
idx=(out/'index.html').read_text().replace('versió 15','versió 16').replace('131 fites','134 fites').replace('71 centres amb alguna fita documentada','73 centres amb alguna fita documentada').replace('71/75 registres · 94,7%','73/75 registres · 97,3%');idx=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',idx,count=1,flags=re.S);(out/'index.html').write_text(idx)
style='<style>body{max-width:1200px;margin:32px auto;padding:20px;font:16px system-ui;color:#223b39;background:#f5f1e8}h1{font:32px Georgia}table{border-collapse:collapse;width:100%;background:white}td,th{text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid #ccd5ce}small{display:block;line-height:1.5}a{color:#16665c}input,select{padding:10px;margin:8px 8px 16px 0;max-width:100%;font:inherit}.scroll{overflow:auto}</style>'
rows=''.join('<tr data-search="'+html.escape(x['centre'].lower()+' '+x['codi_centre'],quote=True)+'" data-cat="'+html.escape(x['categoria_origen'],quote=True)+'"><td><b>'+html.escape(x['centre'])+'</b><small>'+x['codi_centre']+'</small></td><td>'+str(x['fites_documentades'])+'</td><td>'+html.escape(x['categoria_origen'])+'<small>'+html.escape(x['origen_data_min']+' '+x['tipus_data_origen'])+'</small></td><td>'+html.escape(x['primera_fita_data']+' '+x['primera_fita_tipus'])+'</td><td>'+html.escape(x['tasca_prioritaria'])+'</td></tr>' for x in sorted(audit,key=lambda x:x['centre']))
opts='<option value="">Totes les categories</option>'+''.join('<option>'+html.escape(c)+'</option>' for c in sorted(stats))
script="""const q=document.querySelector('#q'),cat=document.querySelector('#cat'),rows=[...document.querySelectorAll('tbody tr')];function filter(){let n=0;for(const r of rows){const show=r.dataset.search.includes(q.value.toLowerCase().trim())&&(!cat.value||r.dataset.cat===cat.value);r.hidden=!show;if(show)n++;}document.querySelector('#n').textContent=n+' registres';}q.addEventListener('input',filter);cat.addEventListener('change',filter);filter();"""
(out/'auditoria-origens.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Mataró · Auditoria d’orígens V16</title>'+style+'<a href="index.html">← Mapa</a> · <a href="cronologia.html">Cronologia</a><h1>Què sabem dels orígens?</h1><p><b>73/75 codis amb alguna fita · 134 fites. 56/75 tenen una data al camp d’origen; 19 el tenen buit.</b> Les 56 dates inclouen fundacions declarades, antecedents, constitucions administratives i inicis de projectes: no són 56 primers dies de classe verificats. El 97,3% mesura qualsevol fita, no la cobertura de fundacions.</p><p>La primera fita conservada és només la més antiga de les documentades al conjunt actual. No s’utilitza automàticament com a fundació ni com a inici d’ocupació de la seu del mapa. Els 75 són codis de la base registral; no tots actius confirmats.</p><p><a href="auditoria_origens_v16.csv">Dades de l’auditoria</a> · <a href="pistes_origen_per_revisar_v16.csv">Pistes d’origen</a> · <a href="registre_recerca_v16.csv">Registre de recerca</a> · <a href="pla_recerca_pendent_v12.md">Consultes documentals preparades</a></p><label for="q">Centre o codi </label><input id="q" type="search"><label for="cat"> Categoria </label><select id="cat">'+opts+'</select><p id="n"></p><div class="scroll"><table><thead><tr><th>Centre</th><th>Fites</th><th>Camp d’origen</th><th>Primera fita documentada</th><th>Tasca pendent</th></tr></thead><tbody>'+rows+'</tbody></table></div><script>'+script+'</script></html>')




(out/'cobertura.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><title>Cobertura V16</title>'+style+'<h1>73/75 codis amb alguna fita · 134 fites</h1><p>56 camps amb una data relacionada amb l’origen; 19 buits. Les dues incorporacions daten predecessors de primària, no la creació dels instituts escola actuals. No són 56 fundacions verificades. Els 75 codis no són tots actius confirmats.</p><p><a href="index.html">Mapa</a> · <a href="cronologia.html">Cronologia</a> · <a href="auditoria-origens.html">Auditoria</a></p><table><tr><th>Centre</th><th>Fites</th><th>Recerca</th></tr>'+''.join('<tr><td>'+html.escape(r['nom'])+'</td><td>'+str(counts[r['codi_centre']])+'</td><td>'+html.escape(r['estat_recerca_historica'])+'</td></tr>' for r in sorted(a,key=lambda r:r['nom']))+'</table>')
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=16,fites_historiques=134,fites_noves_v16=3,camps_origen_nous_v16=2,codis_amb_camp_origen_informat=56,codis_sense_camp_origen=19,categories_auditoria_origen=dict(stats),nota='73 de 75 codis amb qualsevol fita; no equival a cobertura de fundacions. 56 camps daten orígens de naturalesa diversa, inclosos predecessors.',nota_v16='Àngela Bransuela: autorització de 1976 i inauguració de 1977–1978 separades. Mar Mediterrània: creació de Tomàs Viñas el 1976 segons el centre. Cap data heretada com a fundació dels IE actuals.');(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V16.md').write_text("""# Mataró, ciutat d’escoles — V16, 18-11-2026
Paquet acumulatiu. Obre index.html. Sense publicació en línia.
134 fites de 73/75 codis (97,3% amb qualsevol fita). 56 camps amb data relacionada amb l’origen; 19 buits. No són 56 fundacions verificades.

Tres fites noves i tres fonts:
- HIST-132 / H103: autorització de funcionament del predecessor de primària Àngela Bransuela, Ordre de 15-06-1976, publicada el 30-06-1976, BOE 156, p. 12803. No és primer dia de classes.
- HIST-133 / H104: inauguració d’Àngela Bransuela durant 1977–1978 segons la cronologia escolar publicada el 2002, p. 5. Es manté separada de l’autorització; no se selecciona una data única de fundació.
- HIST-134 / H105: creació de Tomàs Viñas el 1976 segons la història institucional de Mar Mediterrània. L’institut escola actual neix el curs 2018–2019; aquesta transformació ja estava documentada.
Els camps canònics dels dos IE daten explícitament els predecessors. fundacio_any es manté buit per evitar presentar aquestes dates com la fundació dels codis actuals. Cap geometria modificada.

Fitxers vigents: base CSV/GeoJSON, esdeveniments_historics_v16.csv, fonts_historiques_v16.csv, auditoria_origens_v16.csv, pistes_origen_per_revisar_v16.csv, revisio_origens_v16.csv, registre_recerca_v16.csv i resum_auditoria.json. Historial de versions conservat, sense sumar-lo. D15 i la pista bibliogràfica V15 continuen vigents.

Pendents: 19 camps d’origen buits; dos codis sense cap fita (Col·legi Salesià 08065123 i Picasoques 08078695). Les consultes de V12 no s’han enviat. Els 75 codis no equivalen a centres actius confirmats. El mapa conserva els avisos de vigència.

Validació automatitzada de codis, fonts, dates, CSV/GeoJSON/visor, 134 articles de cronologia, 75 files d’auditoria i de cobertura, sintaxi JavaScript, enllaços locals, manifest SHA256 i ZIP. Sense inspecció visual en navegador.
""")
shutil.copy2(__file__,out/'amplia_mataro_v16.py')
assert len(a)==75 and len(audit)==75 and norigin==56 and len(E)==134
assert len({e['id_esdeveniment'] for e in E})==134
assert all(e['id_font'] in fm and e['data_min']<=e['data_max'] for e in E)
assert chron.count('<article data-year=')==134
assert '134 fites' in chron and '134 fites' in idx
assert (out/'cobertura.html').read_text().count('<tr>')==76
payload=re.search(r'const centres=(.*?);const esc=',idx,re.S).group(1)
assert json.loads(payload)==a
assert all(f['properties']==am[f['properties']['codi_centre']] for f in g['features'])
assert len([f for f in g['features'] if f['geometry']])==73
for name in ['index.html','cronologia.html','cobertura.html','auditoria-origens.html']:
 text=(out/name).read_text()
 for link in re.findall(r'href="([^"#]+)"',text):
  if not link.startswith(('http:','https:',chr(39))):assert (out/link).exists(),link
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',text,re.S)):
  path=Path('/tmp')/('v16_'+name+str(i)+'.js');path.write_text(s);subprocess.run(['node','--check',str(path)],check=True,capture_output=True)
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(manifest,indent=2))
zp=B/'Mataro_ciutat_escoles_V16_predecessors_2026-11-18.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v16/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(json.dumps(dict(zip=str(zp),fites=len(E),camps_origen=norigin,pendents=75-norigin)))
