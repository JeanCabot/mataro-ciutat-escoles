# Esborranys de consultes, no enviats

## Col·legi Salesià
En el marc de la cartografia històrica dels centres educatius de Mataró, sol·licito la referència i, si és possible, còpia de: Expedient d’alta 08065123 i relació amb 08021089; actes de 1992 i unificació 2005. Centre: Col·legi Salesià, codi 08065123. Cal distingir la creació administrativa, l’inici de classes, els canvis de nom i els trasllats. Si no es conserva al vostre fons, agrairia la indicació del fons o organisme competent.

## EB privada Peques
En el marc de la cartografia històrica dels centres educatius de Mataró, sol·licito la referència i, si és possible, còpia de: Resolució d’autorització prèvia a ENS/2170/2013 i primera matrícula; noms Peques i Acuarella Mataró. Centre: EB privada Peques, codi 08062547. Cal distingir la creació administrativa, l’inici de classes, els canvis de nom i els trasllats. Si no es conserva al vostre fons, agrairia la indicació del fons o organisme competent.

## EB privada Picasoques
En el marc de la cartografia històrica dels centres educatius de Mataró, sol·licito la referència i, si és possible, còpia de: Expedient d’autorització 08078695, llicència d’activitat a República 27 i primer curs. Centre: EB privada Picasoques, codi 08078695. Cal distingir la creació administrativa, l’inici de classes, els canvis de nom i els trasllats. Si no es conserva al vostre fons, agrairia la indicació del fons o organisme competent.

## Escola Angeleta Ferrer
Per a la cartografia històrica dels centres educatius de Mataró, sol·licito referència i, si és possible, còpia de: Expedient de l’escola graduada de nenes del carrer Sant Cugat, trasllat de 1940 i continuïtat amb 08020905; acta del Ple de 08-02-2001 i resolució d’Ensenyament del canvi de nom. Cal distingir l’antiguitat de l’escola de la del seu edifici i els actes de proposta dels acords efectivament adoptats.

## Escola Bressol Cerdanyola
En el marc de la cartografia històrica dels centres educatius de Mataró, sol·licito la referència i, si és possible, còpia de: Actes de creació, municipalització i primer curs de Cerdanyola; consultar Una escola avançada (2007). Centre: Escola Bressol Cerdanyola, codi 08046402. Cal distingir la creació administrativa, l’inici de classes, els canvis de nom i els trasllats. Si no es conserva al vostre fons, agrairia la indicació del fons o organisme competent.

## Escola de Dansa Heidi Consegal
En el marc de la cartografia històrica dels centres educatius de Mataró, sol·licito la referència i, si és possible, còpia de: Autorització original de Dúnia i expedient del canvi de denominació a Heidi Consegal; primer curs. Centre: Escola de Dansa Heidi Consegal, codi 08056948. Cal distingir la creació administrativa, l’inici de classes, els canvis de nom i els trasllats. Si no es conserva al vostre fons, agrairia la indicació del fons o organisme competent.

## Llar d'infants La Llàntia
En el marc de la cartografia històrica dels centres educatius de Mataró, sol·licito la referència i, si és possible, còpia de: Creació i primer curs al carrer Boixa; consultar Una escola avançada (2007). Centre: Llar d'infants La Llàntia, codi 08046414. Cal distingir la creació administrativa, l’inici de classes, els canvis de nom i els trasllats. Si no es conserva al vostre fons, agrairia la indicació del fons o organisme competent.

## Llar d'infants La Riereta
En el marc de la cartografia històrica dels centres educatius de Mataró, sol·licito la referència i, si és possible, còpia de: Acta d’obertura, primer curs i conveni de creació de 15-10-1997; consultar Una escola avançada (2007). Centre: Llar d'infants La Riereta, codi 08057515. Cal distingir la creació administrativa, l’inici de classes, els canvis de nom i els trasllats. Si no es conserva al vostre fons, agrairia la indicació del fons o organisme competent.

## Llar d'infants Rocafonda
En el marc de la cartografia històrica dels centres educatius de Mataró, sol·licito la referència i, si és possible, còpia de: Acta d’inauguració i primer curs de la bressol; continuïtat amb guarderies veïnals si existeix. Centre: Llar d'infants Rocafonda, codi 08046426. Cal distingir la creació administrativa, l’inici de classes, els canvis de nom i els trasllats. Si no es conserva al vostre fons, agrairia la indicació del fons o organisme competent.

## Llar d'infants Tabalet
En el marc de la cartografia històrica dels centres educatius de Mataró, sol·licito la referència i, si és possible, còpia de: Creació dels Tabalet I i II, primers cursos i unificació; consultar Una escola avançada (2007). Centre: Llar d'infants Tabalet, codi 08046451. Cal distingir la creació administrativa, l’inici de classes, els canvis de nom i els trasllats. Si no es conserva al vostre fons, agrairia la indicació del fons o organisme competent.

## LLI privada Nemomarlin Maresme
En el marc de la cartografia històrica dels centres educatius de Mataró, sol·licito la referència i, si és possible, còpia de: Autorització original 08076790, titulars i noms anteriors, primera matrícula al carrer Vallespir 2. Centre: LLI privada Nemomarlin Maresme, codi 08076790. Cal distingir la creació administrativa, l’inici de classes, els canvis de nom i els trasllats. Si no es conserva al vostre fons, agrairia la indicació del fons o organisme competent.

## Sant Josep
En el marc de la cartografia històrica dels centres educatius de Mataró, sol·licito la referència i, si és possible, còpia de: Acta fundacional, primera matrícula i autorització; aclariment explícit dels anys 1968 i 1970. Centre: Sant Josep, codi 08021181. Cal distingir la creació administrativa, l’inici de classes, els canvis de nom i els trasllats. Si no es conserva al vostre fons, agrairia la indicació del fons o organisme competent.

