# Consultes documentals preparades, no enviades

## Col·legi Salesià · 08065123
Fons o organisme: Registre de centres / arxiu Salesians

Expedient d’alta 08065123 i relació amb 08021089; actes de 1992 i unificació 2005.

## EB privada Peques · 08062547
Fons o organisme: Registre de centres / arxiu municipal d’activitats

Resolució d’autorització prèvia a ENS/2170/2013 i primera matrícula; noms Peques i Acuarella Mataró.

## EB privada Picasoques · 08078695
Fons o organisme: Registre de centres / arxiu municipal d’activitats

Expedient d’autorització 08078695, llicència d’activitat a República 27 i primer curs.

## Escola Angeleta Ferrer · 08020905
Fons o organisme: Arxiu municipal / Registre de centres

Expedient de creació de les Escuelas Nacionales Femeninas Nuestra Señora del Pilar a plaça de Cuba; continuïtat amb 08020905.

## Escola Bressol Cerdanyola · 08046402
Fons o organisme: Arxiu municipal / Servei d’Educació

Actes de creació, municipalització i primer curs de Cerdanyola; consultar Una escola avançada (2007).

## Escola de Dansa Heidi Consegal · 08056948
Fons o organisme: Registre de centres / arxiu del centre

Autorització original de Dúnia i expedient del canvi de denominació a Heidi Consegal; primer curs.

## Llar d'infants La Llàntia · 08046414
Fons o organisme: Arxiu municipal / Servei d’Educació

Creació i primer curs al carrer Boixa; consultar Una escola avançada (2007).

## Llar d'infants La Riereta · 08057515
Fons o organisme: Arxiu municipal / Servei d’Educació

Acta d’obertura, primer curs i conveni de creació de 15-10-1997; consultar Una escola avançada (2007).

## Llar d'infants Rocafonda · 08046426
Fons o organisme: Arxiu municipal / Servei d’Educació

Acta d’inauguració i primer curs de la bressol; continuïtat amb guarderies veïnals si existeix.

## Llar d'infants Tabalet · 08046451
Fons o organisme: Arxiu municipal / Servei d’Educació

Creació dels Tabalet I i II, primers cursos i unificació; consultar Una escola avançada (2007).

## LLI privada Nemomarlin Maresme · 08076790
Fons o organisme: Registre de centres / arxiu municipal d’activitats

Autorització original 08076790, titulars i noms anteriors, primera matrícula al carrer Vallespir 2.

## Sant Josep · 08021181
Fons o organisme: Arxiu del centre / congregació / Registre de centres

Acta fundacional, primera matrícula i autorització; aclariment explícit dels anys 1968 i 1970.

