# Mataró, ciutat d’escoles — V4
Guia vigent. Paquet acumulatiu de 18-11-2026, amb 75 centres actuals i 21 fites de 10 centres (8 noves). Conserva CSV, fonts i dades de versions anteriors amb noms de versió; els fitxers històrics vigents són els V4.

Obriu index.html per al mapa contemporani i cronologia.html per a la cronologia amb filtre per centre i any. El mapa requereix connexió; la llista i la cronologia estan incorporades als fitxers.

## Aportacions
- Satorras: constitució del patronat COPEM, 20-10-1958. No s’assimila automàticament a l’institut republicà de 1933/1934 ni es dona per fundada la seu actual el 1958.
- Anxaneta: pas a la xarxa pública el 1987; la fundació i els trasllats requereixen recerca addicional. No es presenta 1987 com a origen escolar.
- Camí del Mig i Rocafonda: ordre de constitució de 08-01-1979 (BOE publicat el 24-02-1979). Dates administratives, no d’inici de classes. El text BOE conté adreces que cal conciliar.
- Angeleta Ferrer: tancament de la seu de plaça de Cuba el 08-11-2012, continuïtat provisional a Torre Llauder, activitat a Can Fàbregas el curs 2017/2018 i inauguració oficial el 27-02-2019. La precisió del curs evita confondre el dia administratiu d’inici de setembre amb el primer dia lectiu.
- Les Cinc Sénies: posada en marxa el curs 2017/2018; no és una inauguració d’edifici definitiu.

ocupacions_angeleta_ferrer_v4.csv inicia el model d’ocupacions amb límits coneguts i desconeguts. És una taula documental; no s’han afegit geometries històriques no verificades. Els casos sense data fundacional segueixen sense any de fundació al cens.

Validació: 75 codis actuals sense duplicats; 21 identificadors d’esdeveniment únics; 10 centres amb fites; referències de fonts comprovades per codi; CSV i GeoJSON coherents; JavaScript comprovat sintàcticament. El visor no s’ha sotmès a una prova visual de navegador en aquesta fase.

Fonts recuperades en línia; la majoria són històries institucionals, amb el BOE com a font normativa primària. La interpretació dels antecedents, els canvis de codi i la vigència dels edificis continua requerint contrast. Picasoques segueix pendent d’una coordenada exacta. No s’ha modificat cap web pública ni repositori amb aquesta ampliació.
