# Revisió dels 17 camps d’origen — V22

Resultat: 17 casos revisats; 5 camps informats amb dates qualificades i 12 encara buits. No s’han completat els 17 orígens. Les dates administratives i les inauguracions no equivalen a obertures inicials.

## CFA Can Noè · 08061658
informat: inici declarat. Camp canònic: 1979.

PEC propi, pp. 3–4: servei des de 1979. 1979 data el servei històric, no l’alta del codi; 2001–02 data titularitat.

Document necessari: Expedient de creació i primera matrícula, si es vol verificar primer curs i continuïtat registral. Fons: CFA Can Noè / arxiu municipal. Fonts: H122.

## Col·legi Salesià · 08065123
pendent: continuïtat de codis. Camp canònic: buit.

Història pròpia, pp. 10–11: cursos, CFA i unificació; directori de 2007 amb 08065123 localitzat. 1992 és origen declarat d’un CFA de l’obra; no s’ha provat la continuïtat amb el codi actual.

Document necessari: Expedient d’alta 08065123 i relació amb 08021089; actes de 1992 i unificació 2005. Fons: Registre de centres / arxiu Salesians. Fonts: H128; H118.

## EB privada Peques · 08062547
pendent: autorització inicial. Camp canònic: buit.

ENS/2170/2013 amplia i ENS/2711/2018 canvia titular i nom. Cap acte inicial localitzat; cap data deduïda del número de codi.

Document necessari: Resolució d’autorització prèvia a ENS/2170/2013 i primera matrícula; noms Peques i Acuarella Mataró. Fons: Registre de centres / arxiu municipal d’activitats. Fonts: H120; H84.

## EB privada Picasoques · 08078695
pendent: autorització inicial. Camp canònic: buit.

Web pròpia identifica codi i Ronda República 27; cerques per Picasoques, Pica-soques i Pica Soques. No heretar dates de revistes homònimes de Castellbisbal ni del projecte web de 2013.

Document necessari: Expedient d’autorització 08078695, llicència d’activitat a República 27 i primer curs. Fons: Registre de centres / arxiu municipal d’activitats. Fonts: H117.

## Escola Angeleta Ferrer · 08020905
pendent: origen de primària. Camp canònic: buit.

Història pròpia i acord de canvi de nom de 2001 localitzats. 1892 és edifici; 1934 i 1958 són ensenyament secundari. No es daten orígens de primària amb aquests fets.

Document necessari: Expedient de creació de les Escuelas Nacionales Femeninas Nuestra Señora del Pilar a plaça de Cuba; continuïtat amb 08020905. Fons: Arxiu municipal / Registre de centres. Fonts: https://agora.xtec.cat/esc-angeletaferrer/lescola/historia/.

## Escola Bressol Cerdanyola · 08046402
pendent: discrepància d’origen. Camp canònic: buit.

MASMM atribueix creació a 1979; un arxiu geganter registra un vuitè aniversari el 1989. No convertir la resta 1989−8 en any fundacional; cal distingir municipalització i obertura.

Document necessari: Actes de creació, municipalització i primer curs de Cerdanyola; consultar Una escola avançada (2007). Fons: Arxiu municipal / Servei d’Educació. Fonts: H98; H99; H102.

## Escola de Dansa Heidi Consegal · 08056948
pendent: origen sota nom Dúnia. Camp canònic: buit.

Fullet oficial de Dansa 2007: Dúnia 08056948, Concepció 11; coincideix amb el codi actual Heidi Consegal. 2007 és presència al directori, no obertura; es descarta 2001 del directori que la qualifica erròniament de primària.

Document necessari: Autorització original de Dúnia i expedient del canvi de denominació a Heidi Consegal; primer curs. Fons: Registre de centres / arxiu del centre. Fonts: H129.

## Escola Josep Manuel Peramàs · 08020917
informat parcial: inauguració. Camp canònic: 1972.

Premsa contemporània de 02-02-1972: inauguració i funcionament des de setmanes abans. No data el primer dia de classe ni la creació legal; no es deriva 1971 d’un aniversari.

Document necessari: Ordre de creació i primer llibre de matrícula del grup Peramas. Fons: Arxiu municipal / arxiu del centre. Fonts: H126.

## Escola Josep Montserrat · 08021041
informat parcial: constitució administrativa. Camp canònic: 1975-07-24.

Ordre de 24-07-1975: transformació del patronat de Caixa Laietana a règim ordinari. No data l’obertura del centre anterior; 1962, 1963 i 1964 continuen requerint conciliació.

Document necessari: Expedient del patronat i notícia Escuela Josep Montserrat en Peramas, Diari de Mataró, 21-09-1962, p. 1. Fons: Arxiu municipal / fons de Caixa Laietana. Fonts: H127; H106.

## Institut Damià Campeny · 08021302
informat: creació administrativa. Camp canònic: 1975-07-24.

Decret de 1969: secció; Decret 2165/1975: institut; Ordre de 1977: nom Damiá Campeny. No heretar la data del COPEM ni la construcció de 1966; primer dia de classe pendent.

Document necessari: Primera matrícula de l’institut 1975–1976, si es vol precisar l’inici efectiu. Fons: Arxiu de l’institut / Registre de centres. Fonts: H123; H124; H125.

## Llar d'infants La Llàntia · 08046414
pendent: obertura anterior al trasllat. Camp canònic: buit.

Fent camí documenta trasllat el 1995–1996; gegants daten nous locals el 27-01-1996. 1996 no és fundació; no heretar 1978 de l’escola de primària homònima.

Document necessari: Creació i primer curs al carrer Boixa; consultar Una escola avançada (2007). Fons: Arxiu municipal / Servei d’Educació. Fonts: H100; H99; H102.

## Llar d'infants La Riereta · 08057515
pendent: obertura i conveni. Camp canònic: buit.

La Iaia es crea el 1996–1997 quan feia poc que s’havia inaugurat l’escola; conveni de 15-10-1997. No equivaler la geganta ni el conveni al primer dia de classe.

Document necessari: Acta d’obertura, primer curs i conveni de creació de 15-10-1997; consultar Una escola avançada (2007). Fons: Arxiu municipal / Servei d’Educació. Fonts: H101; H50; H102.

## Llar d'infants Rocafonda · 08046426
pendent: obertura institucional. Camp canònic: buit.

Edifici educatiu 1985–1987 i conveni de 16-10-1992 documentats. Construcció i conveni no són origen; la memòria d’una inauguració un Primer de Maig no n’indica l’any.

Document necessari: Acta d’inauguració i primer curs de la bressol; continuïtat amb guarderies veïnals si existeix. Fons: Arxiu municipal / Servei d’Educació. Fonts: H112; H50; H102.

## Llar d'infants Tabalet · 08046451
pendent: centres anteriors. Camp canònic: buit.

Trasllat dels dos Tabalet al nou edifici el 8 i 9 de gener de 2004 documentat; conveni de 1992. 2004 és trasllat i ampliació; no s’adopta com a fundació dels dos centres anteriors.

Document necessari: Creació dels Tabalet I i II, primers cursos i unificació; consultar Una escola avançada (2007). Fons: Arxiu municipal / Servei d’Educació. Fonts: H113; H50; H102.

## LLI privada Nemomarlin Maresme · 08076790
pendent: obertura inicial. Camp canònic: buit.

Xarxa Nemomarlin: incorporació el 2019–2020; cessament efectiu final 2025–2026. No prendre una previsió d’apertura 2018–2019 ni l’adhesió a la franquícia com a obertura real.

Document necessari: Autorització original 08076790, titulars i noms anteriors, primera matrícula al carrer Vallespir 2. Fons: Registre de centres / arxiu municipal d’activitats. Fonts: H59; H60.

## Sant Josep · 08021181
pendent: discrepància 1968/1970. Camp canònic: buit.

Història pròpia declara 1968; Caràcter propi 1970; URC separa classes i comunitat de 1970; benedicció 04-01-1970. No es construeix un interval 1968–1970 com si fos una incertesa sobre un mateix fet; són afirmacions i esdeveniments a separar.

Document necessari: Acta fundacional, primera matrícula i autorització; aclariment explícit dels anys 1968 i 1970. Fons: Arxiu del centre / congregació / Registre de centres. Fonts: H69; H70; H86.

## Sol-Ixent · 08035374
informat: fundació declarada. Camp canònic: 1970.

MASMM declara fundació per la família Sancho i Caballé el 1970. No és data d’autorització; no confondre amb ampliació BUP de 1980 ni societat mercantil de 2002.

Document necessari: Autorització inicial i primera matrícula, si es vol passar de fundació declarada a primer curs verificat. Fons: Arxiu del centre / Registre de centres. Fonts: H121.

Les cerques web i CIDO són consultes de descoberta, no una revisió exhaustiva dels registres. No localitzar un acte no prova que no existeixi. Els esborranys no s’han enviat. El llibre Una escola avançada (IME, 2007) està documentat per una notícia municipal, però no se n’ha pogut consultar el text complet. El paquet conserva les discrepàncies D06 i D15.
