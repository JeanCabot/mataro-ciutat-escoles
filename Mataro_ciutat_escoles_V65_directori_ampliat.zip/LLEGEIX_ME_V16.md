# Mataró, ciutat d’escoles — V16, 18-11-2026
Paquet acumulatiu. Obre index.html. Sense publicació en línia.
134 fites de 73/75 codis (97,3% amb qualsevol fita). 56 camps amb data relacionada amb l’origen; 19 buits. No són 56 fundacions verificades.

Tres fites noves i tres fonts:
- HIST-132 / H103: autorització de funcionament del predecessor de primària Àngela Bransuela, Ordre de 15-06-1976, publicada el 30-06-1976, BOE 156, p. 12803. No és primer dia de classes.
- HIST-133 / H104: inauguració d’Àngela Bransuela durant 1977–1978 segons la cronologia escolar publicada el 2002, p. 5. Es manté separada de l’autorització; no se selecciona una data única de fundació.
- HIST-134 / H105: creació de Tomàs Viñas el 1976 segons la història institucional de Mar Mediterrània. L’institut escola actual neix el curs 2018–2019; aquesta transformació ja estava documentada.
Els camps canònics dels dos IE daten explícitament els predecessors. fundacio_any es manté buit per evitar presentar aquestes dates com la fundació dels codis actuals. Cap geometria modificada.

Fitxers vigents: base CSV/GeoJSON, esdeveniments_historics_v16.csv, fonts_historiques_v16.csv, auditoria_origens_v16.csv, pistes_origen_per_revisar_v16.csv, revisio_origens_v16.csv, registre_recerca_v16.csv i resum_auditoria.json. Historial de versions conservat, sense sumar-lo. D15 i la pista bibliogràfica V15 continuen vigents.

Pendents: 19 camps d’origen buits; dos codis sense cap fita (Col·legi Salesià 08065123 i Picasoques 08078695). Les consultes de V12 no s’han enviat. Els 75 codis no equivalen a centres actius confirmats. El mapa conserva els avisos de vigència.

Validació automatitzada de codis, fonts, dates, CSV/GeoJSON/visor, 134 articles de cronologia, 75 files d’auditoria i de cobertura, sintaxi JavaScript, enllaços locals, manifest SHA256 i ZIP. Sense inspecció visual en navegador.
