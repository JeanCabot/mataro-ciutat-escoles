# Mataró, ciutat d’escoles — V21, 19-11-2026
Paquet acumulatiu. Obre index.html. Sense publicació en línia.
153 fites de 75/75 codis (100% amb almenys una fita). Es mantenen 58 camps amb alguna data relacionada amb l’origen i 17 buits. No s’ha resolt cap obertura inicial en aquesta fase.
Dues fites noves del mateix acte de Peques, codi 08062547: ampliació de locals i de capacitat el 07-10-2013 i efectes de la composició ampliada des de l’inici del curs 2013–2014. 5 a 7 unitats, 66 a 87 places. Resolució ENS/2170/2013 llegida íntegrament; PDF inclòs a evidencies_v21. No es confon modificació amb primera autorització ni data de publicació amb efectes.
Les cerques d’autorització inicial de Nemomarlin i Picasoques no han aportat cap nou acte atribuïble. No se’n dedueix inexistència ni any fundacional. Vegeu pistes_documentals_v21.md i registre_recerca_v21.csv.
Fitxers vigents: base CSV/GeoJSON, esdeveniments_historics_v21.csv, fonts_historiques_v21.csv, auditoria_origens_v21.csv, pistes_origen_per_revisar_v21.csv, registre_recerca_v21.csv i resum_auditoria.json. Versions anteriors són checkpoints; no sumar files. 153 són registres de fites, no 153 actes jurídics diferents.
Mapa, cronologia, auditoria i cobertura sincronitzats; geometries no modificades, 73 punts. Els 75 codis no són tots actius confirmats ni un cens històric complet. Consultes documentals no enviades.
Validació automatitzada: codis, fonts, intervals, 153 articles, 75 files d’auditoria i cobertura, CSV/GeoJSON/visor, JavaScript, enllaços locals, SHA256 i ZIP. Sense inspecció visual en navegador.
