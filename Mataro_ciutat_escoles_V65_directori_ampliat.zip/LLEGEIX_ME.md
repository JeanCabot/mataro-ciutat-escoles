# Mataró, ciutat d’escoles — versió 2

18-11-2026. Continuació de la base V1. 75 centres, 74 centres representables; 76 seus documentades en total, 75 amb coordenades utilitzables. La llista no constitueix encara una relació exhaustiva de seus de tots els centres.

## Canvis
- GiEscola: adreça completada a Camí del Mig 71, baixos; coordenada corregida amb portal ICGC després de comprovar carrer, número i municipi. Es preserven coordenades i adreça originals al CSV.
- Picasoques: web i codi confirmats. Es manté sense punt: la cerca ICGC retorna el número 29 en lloc del 27. No s’ha acceptat una coincidència aproximada com a porta exacta.
- Joan Coromines: documentades les seus de primària (Sant Pere 4) i infantil (Pascual Madoz 22); afegida la segona al CSV/GeoJSON de seus i com a capa opcional al visor.
- Puig i Cadafalch: Roques Albes al carrer Galícia documentat al directori municipal. Es conserva a la cua, pendent de vigència i portal.
- Germanes Bertomeu: no s’ha donat per provada una seu addicional només perquè hi hagi dues entrades de directori.
- Miquel Biada: candidat de continuïtat entre dos codis oficials amb el mateix nom. No es fusionen sense font administrativa.

## Fitxers principals
`index.html`: obrir amb connexió per carregar Leaflet i el mapa base. Filtra centres; la capa addicional de Coromines s’activa al control de capes i és independent del filtre de centres.
`mataro_centres_2026_2027.csv` i `.geojson`: cens per codi, 75 files i 74 punts.
`mataro_seus_observades.csv` i `mataro_seus_v2.geojson`: 76 seus, 75 punts, amb dates d’ocupació desconegudes en blanc.
`fonts_verificacio_v2.csv`: fonts i afirmacions associades.
`evidencies_icgc/`: respostes originals; a GiEscola s’ha seleccionat el resultat de Camí del Mig 71, no altres vies retornades.
`cua_seus_per_verificar.csv`, `conciliacio_codis_candidata.csv`: recerca pendent.
La sèrie de 532 registres i l’auditoria V1 es conserven.

La informació no documenta encara l’any fundacional de cada centre, concerts per ensenyament ni tots els centres desapareguts. Un canvi de codi no prova un tancament. Coordenades EPSG:4326, ordre longitud/latitud al GeoJSON. Un portal geocodificat no equival a accés escolar verificat sobre el terreny.

El script prepara_base.py és el generador de la V1, conservat com a antecedent; no regenera les ampliacions V2. El script actualitza_mataro_v2.py acompanya el paquet com a registre del procés, i requereix les carpetes V1 i mataro_recerca_v2 de l’entorn original.
