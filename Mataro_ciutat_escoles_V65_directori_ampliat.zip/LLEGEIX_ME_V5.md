# Mataró, ciutat d’escoles — V5 · Tres seus, una escola
Guia vigent. 18-11-2026. Paquet acumulatiu: 75 centres actuals, 23 fites de 10 centres i primer cas cartogràfic de seus successives.

Obriu index.html, cronologia.html o angeleta-ferrer.html. Internet necessari per al mapa base i Leaflet, dades incorporades. No hi ha publicació web en aquesta fase.

## Cas Angeleta Ferrer
Tres ocupacions documentals: plaça de Cuba 10, Torre Llauder (Ciutat Freta 31) i Can Fàbregas del paper (Ventura Ametller 1–3).
- Plaça de Cuba: observació datada el 02-02-2007 a la fitxa 49 del Pla d’accessibilitat. És evidència d’ús, no data d’obertura. Tancament de la seu el 08-11-2012. La finca també figura com 9–10 en actes municipals. Sense coordenada: l’ICGC ha retornat 503 en la consulta i en un segon intent limitat.
- Torre Llauder: inici lectiu exacte el 12-11-2012, segons notícia municipal del mateix dia; final abans de l’ocupació de la nova seu el curs 2017/2018, sense dia concret verificat.
- Can Fàbregas: ús lectiu el curs 2017/2018 i inauguració oficial el 27-02-2019, dues fites diferents.

Els dos punts representats reutilitzen coordenades del registre 2026/2027 perquè la identitat de les adreces està documentada. No són aixecaments de les portes històriques ni permeten inferir tot l’interval d’activitat sense excepcions. No s’han dibuixat rutes de desplaçament.

Els fitxers nous són angeleta_ferrer_seus_v5.csv/.geojson, angeleta-ferrer.html, fonts_historiques_v5.csv i esdeveniments_historics_v5.csv. La taula d’ocupacions V4 es conserva com a antecedent, però V5 n’és l’actualització. V1–V4 conserven documentació i scripts previs amb els seus límits originals.

Validació: 75 codis actuals, 23 identificadors d’esdeveniment únics, 3 ocupacions i 2 geometries coherents amb les seus del registre; HTML i JavaScript verificats sintàcticament, sense prova visual de navegador. No s’ha incrementat el nombre d’escoles actuals pel fet d’afegir ocupacions històriques.

Següent fase: completar el punt de plaça de Cuba i estendre el model a altres trasllats. La cronologia continua parcial i el mapa general és contemporani.
