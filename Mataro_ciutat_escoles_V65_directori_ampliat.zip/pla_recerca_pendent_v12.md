# Consultes documentals preparades — 18-11-2026
Esborranys; no s’han enviat missatges ni sol·licituds.

## 1. Serveis Territorials d’Educació al Maresme–Vallès Oriental
Assumpte: consulta documental dels centres 08065123 i 08078695

Estic elaborant una cartografia històrica dels centres educatius de Mataró. Voldria localitzar les resolucions d’autorització inicial, les dates d’efectes i, si n’hi ha, els canvis de codi o denominació dels centres següents:
- Col·legi Salesià, codi 08065123, avinguda de Puig i Cadafalch 80. La Resolució EDC/2410/2004 descriu formació de persones adultes però l’annex porta el codi 08021089; la correcció posterior només esmena la comarca. Hi ha un acte que expliqui l’assignació o la separació dels dos codis?
- Escola bressol Picasoques, codi 08078695, ronda de la República 27, baixos. Quina és l’autorització inicial i des de quin curs té efectes?

Agrairia la referència de publicació o una còpia dels actes administratius públics corresponents, sense dades personals d’alumnat ni expedients particulars.

## 2. Col·legi Salesià / arxiu del centre
Assumpte: origen de la formació de persones adultes i codi 08065123

Per a una cartografia històrica educativa de Mataró, voldria distingir la fundació del col·legi de 1905 de l’inici del centre de persones adultes amb codi 08065123. Disposeu d’una memòria, resolució o document que indiqui el primer curs d’aquesta oferta i expliqui la relació administrativa amb el codi 08021089 que apareix a la resolució de 2004? Em seria útil també distingir activitat prèvia i autorització formal.

## 3. Picasoques / documentació del centre
Assumpte: primer curs i autorització de Picasoques

Estic documentant la història dels centres educatius de Mataró. Em podríeu indicar el primer curs en què Picasoques va acollir infants a ronda de la República 27 i la referència de l’autorització del codi 08078695? Si hi havia una denominació o un projecte anterior al mateix local, voldria poder separar les etapes. Una memòria, anunci d’obertura o resolució permetria citar la dada amb precisió.

## Regla d’incorporació
Registrar per separat data de resolució, publicació, efectes legals, primeres classes i ocupació de seu. Conservar l’original de cada resposta i indicar si és relat retrospectiu o document contemporani. No modificar els comptadors fins a disposar d’una fita atribuïble. No cal cap dada d’infants ni famílies.
