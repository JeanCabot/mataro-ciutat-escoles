from pathlib import Path
import csv,json,shutil,re,hashlib,zipfile
B=Path('/workspace/scratch/d94958db76f2'); old=B/'mataro_escoles_v1'; out=B/'mataro_escoles_v2';out.mkdir(exist_ok=True)
for f in old.iterdir():
 if f.is_file():shutil.copy2(f,out/f.name)
raw=out/'evidencies_icgc';raw.mkdir(exist_ok=True)
for p in (B/'mataro_recerca_v2').glob('*.json'):shutil.copy2(p,raw/p.name)
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(name,a,keys=None):
 with (out/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=keys or list(a[0]));w.writeheader();w.writerows(a)
a=read(out/'mataro_centres_2026_2027.csv')
evidence=[{'id':'F01','url':'https://www.giescola.com/giescola','afirmacio':'Codi 08078877; Camí del Mig 71, baixos, Mataró','estat':'adreça confirmada pel centre'}, {'id':'F02','url':'https://sompicasoques.com/escola-bressol','afirmacio':'Codi 08078695; Ronda República 27, Mataró','estat':'adreça confirmada; coordenada pendent'}, {'id':'F03','url':'https://www.coromines.cat/contacte','afirmacio':'Infantil a Pascual Madoz 22; primària a Sant Pere 4','estat':'dues seus confirmades pel centre'}, {'id':'F04','url':'https://agora.xtec.cat/escolagermanesbertomeu/lescola/','afirmacio':'Centre al carrer Colòmbia 15; no confirma ubicació diferenciada del parvulari','estat':'segona seu pendent de contrast'}, {'id':'F05','url':'https://www.mataro.cat/ca/temes/educacio/e-obligatoria-3-16-anys/directori-de-centres','afirmacio':'Institut Puig i Cadafalch amb seu principal i edifici Roques Albes al carrer Galícia','estat':'segona seu documentada en directori municipal; vigència i portal pendents'}, {'id':'F06','url':'https://www.icgc.cat/ca/Eines-i-visors/Eines/Geocodificador-ICGC','afirmacio':'Servei de geocodificació; respostes guardades a evidencies_icgc','estat':'control de carrer, portal i municipi'}]
for e in evidence:e['data_consulta']='2026-11-18'
write('fonts_verificacio_v2.csv',evidence)
gi=json.loads((raw/'giescola.json').read_text())['features'];gi=next(f for f in gi if f['properties']['nom']=='Camí del Mig' and f['properties']['portal']=='71' and f['properties']['municipi']=='Mataró')
for r in a:
 r['longitud_original']=r['longitud'];r['latitud_original']=r['latitud'];r['adreca_original']=r['adreca'];r['font_verificacio']='';r['precisio_coordenada']='registre original; pendent contrast'
 if r['codi_centre']=='08078877':
  r.update(adreca='Camí del Mig, 71, baixos',web='https://www.giescola.com/',longitud=gi['geometry']['coordinates'][0],latitud=gi['geometry']['coordinates'][1],control_coordenades='adreça confirmada + portal ICGC; no comprovació sobre el terreny',font_verificacio='F01 | F06',precisio_coordenada='portal geocodificat')
 if r['codi_centre']=='08078695':r.update(web='https://sompicasoques.com/',font_verificacio='F02 | F06',precisio_coordenada='pendent: ICGC retorna portal 29, no 27')
 if r['codi_centre']=='08067661':r['font_verificacio']='F03'
write('mataro_centres_2026_2027.csv',a)
seats=read(out/'mataro_seus_observades.csv')
for s in seats:
 r=next(r for r in a if r['codi_centre']==s['codi_centre'])
 s.update(adreca=r['adreca'],longitud=r['longitud'],latitud=r['latitud'],nom_centre=r['nom'],etapa_seu='primària' if s['codi_centre']=='08067661' else '',font_verificacio=r['font_verificacio'],control_coordenades=r['control_coordenades'])
co=json.loads((raw/'coromines_infantil.json').read_text())['features'][0]
assert co['properties']['portal']=='22' and co['properties']['nom']=='Carrer de Pascual Madoz'
seat=dict.fromkeys(seats[0],'');seat.update(id_seu_observada='SEU-08067661-INF',codi_centre='08067661',nom_centre='Escola Joan Coromines',etapa_seu='infantil',adreca='Carrer de Pascual Madoz, 22',longitud=co['geometry']['coordinates'][0],latitud=co['geometry']['coordinates'][1],curs_observacio='2026/2027',estat='seu diferenciada confirmada; dates d’ocupació pendents',font='Web del centre i ICGC consultats el 18-11-2026; vinculació al curs com a referència de la versió',font_verificacio='F03 | F06',control_coordenades='portal geocodificat; no comprovació sobre el terreny')
seats.append(seat);write('mataro_seus_observades.csv',seats)
features=[]
for s in seats:
 if s['control_coordenades'].startswith('FORA'):continue
 features.append({'type':'Feature','geometry':{'type':'Point','coordinates':[float(s['longitud']),float(s['latitud'])]},'properties':s})
(out/'mataro_seus_v2.geojson').write_text(json.dumps({'type':'FeatureCollection','features':features},ensure_ascii=False,indent=2))
cf=[{'type':'Feature','geometry':{'type':'Point','coordinates':[float(r['longitud']),float(r['latitud'])]},'properties':r} for r in a if not r['control_coordenades'].startswith('FORA')]
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps({'type':'FeatureCollection','features':cf},ensure_ascii=False,indent=2))
write('cua_seus_per_verificar.csv',[{'codi_centre':'08052979','nom':'Institut Josep Puig i Cadafalch — Roques Albes','adreca_documentada':'carrer Galícia, sense número confirmat','font':'F05','pendent':'Confirmar vigència, número, etapa i coordenades; no afegit al mapa'}, {'codi_centre':'08020929','nom':'Germanes Bertomeu — infantil','adreca_documentada':'per contrastar','font':'F04 i text municipal aportat','pendent':'El directori separa infantil i primària, però no és prova suficient de dues seus diferenciades'}])
write('conciliacio_codis_candidata.csv',[{'codi_anterior':'08021259','codi_actual':'08077976','nom_compartit':'Institut Miquel Biada','evidencia':'Mateixa denominació al CSV de diferents cursos','estat':'continuïtat candidata; no fusionada','pendent':'Localitzar acte administratiu o font institucional que expliqui el canvi de codi i titularitat'}])
stats=json.loads((out/'resum_auditoria.json').read_text());stats.update(versio=2,punts_centres=74,seus_documentades=76,punts_seus=75,coordenades_pendents=['08078695'],nota='La seu d’infantil de Coromines s’afegeix només a la capa de seus. La capa de centres manté un punt per codi.')
stats['punts_al_visor']=74
stats['coordenades_a_revisar']=[{'codi':'08078695','nom':'EB privada Picasoques'}]
(out/'resum_auditoria.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2))
page=(old/'index.html').read_text().replace('versió 1','versió 2')
page=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',page,count=1,flags=re.S)
page=page.replace('<a href="mataro_centres_2026_2027.geojson">GeoJSON</a>','<a href="mataro_centres_2026_2027.geojson">GeoJSON centres</a><a href="mataro_seus_v2.geojson">GeoJSON seus</a>')
page=page.replace("+'<br>Fundació: pendent de documentar'", "+'<br>Fundació: pendent de documentar'")
# Incorporar una capa de seus separada, no augmentar el recompte de centres.
insert='const seusExtra='+json.dumps([seat],ensure_ascii=False)+';'
page=page.replace('let map,layer;',insert+'let map,layer,extra;')
page=page.replace('layer=L.featureGroup().addTo(map);','layer=L.featureGroup().addTo(map);extra=L.featureGroup();seusExtra.forEach(s=>L.circleMarker([s.latitud,s.longitud],{radius:9,color:"#6d4c91",fillOpacity:.75}).bindPopup("<b>"+esc(s.nom_centre)+" · infantil</b><br>"+esc(s.adreca)+"<br>Seu addicional documentada · portal ICGC").addTo(extra));L.control.layers(null,{"Seu addicional Joan Coromines":extra}).addTo(map);')
page=page.replace('La reconstrucció històrica des de 1737 està pendent.','La reconstrucció històrica des de 1737 està pendent. La seu addicional de Joan Coromines es pot activar al selector de capes.')
(out/'index.html').write_text(page)
(out/'LLEGEIX_ME.md').write_text('''# Mataró, ciutat d’escoles — versió 2

18-11-2026. Continuació de la base V1. 75 centres, 74 centres representables; 76 seus documentades en total, 75 amb coordenades utilitzables. La llista no constitueix encara una relació exhaustiva de seus de tots els centres.

## Canvis
- GiEscola: adreça completada a Camí del Mig 71, baixos; coordenada corregida amb portal ICGC després de comprovar carrer, número i municipi. Es preserven coordenades i adreça originals al CSV.
- Picasoques: web i codi confirmats. Es manté sense punt: la cerca ICGC retorna el número 29 en lloc del 27. No s’ha acceptat una coincidència aproximada com a porta exacta.
- Joan Coromines: documentades les seus de primària (Sant Pere 4) i infantil (Pascual Madoz 22); afegida la segona al CSV/GeoJSON de seus i com a capa opcional al visor.
- Puig i Cadafalch: Roques Albes al carrer Galícia documentat al directori municipal. Es conserva a la cua, pendent de vigència i portal.
- Germanes Bertomeu: no s’ha donat per provada una seu addicional només perquè hi hagi dues entrades de directori.
- Miquel Biada: candidat de continuïtat entre dos codis oficials amb el mateix nom. No es fusionen sense font administrativa.

## Fitxers principals
`index.html`: obrir amb connexió per carregar Leaflet i el mapa base. Filtra centres; la capa addicional de Coromines s’activa al control de capes i és independent del filtre de centres.
`mataro_centres_2026_2027.csv` i `.geojson`: cens per codi, 75 files i 74 punts.
`mataro_seus_observades.csv` i `mataro_seus_v2.geojson`: 76 seus, 75 punts, amb dates d’ocupació desconegudes en blanc.
`fonts_verificacio_v2.csv`: fonts i afirmacions associades.
`evidencies_icgc/`: respostes originals; a GiEscola s’ha seleccionat el resultat de Camí del Mig 71, no altres vies retornades.
`cua_seus_per_verificar.csv`, `conciliacio_codis_candidata.csv`: recerca pendent.
La sèrie de 532 registres i l’auditoria V1 es conserven.

La informació no documenta encara l’any fundacional de cada centre, concerts per ensenyament ni tots els centres desapareguts. Un canvi de codi no prova un tancament. Coordenades EPSG:4326, ordre longitud/latitud al GeoJSON. Un portal geocodificat no equival a accés escolar verificat sobre el terreny.

El script prepara_base.py és el generador de la V1, conservat com a antecedent; no regenera les ampliacions V2. El script actualitza_mataro_v2.py acompanya el paquet com a registre del procés, i requereix les carpetes V1 i mataro_recerca_v2 de l’entorn original.
''')
shutil.copy2(__file__,out/'actualitza_mataro_v2.py')
# Validació de dades i geometries
assert len(a)==75 and len(cf)==74 and len(seats)==76 and len(features)==75
assert len({r['codi_centre'] for r in a})==75
for f in features:
 x,y=f['geometry']['coordinates'];assert 2.3<x<2.6 and 41.4<y<41.7
Path('/tmp/mataro_v2_check.js').write_text(re.findall(r'<script>(.*?)</script>',page,re.S)[0])
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'}
(out/'SHA256.json').write_text(json.dumps(manifest,indent=2))
zp=B/'Mataro_ciutat_escoles_V2_verificacio_seus_2026-11-18.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v2/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(zp);print(json.dumps(stats,ensure_ascii=False))
