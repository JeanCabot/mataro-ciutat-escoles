from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile,collections
B=Path(__file__).parent; out=B/'mataro_escoles_v8';shutil.copytree(B/'mataro_escoles_v7',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,a):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(a[0]));w.writeheader();w.writerows(a)
F=read('fonts_historiques_v7.csv')
sources=[
('H30','Ajuntament — inici de curs 2007–2008','https://www.mataro.cat/ca/actualitat/noticies/2007/el-curs-escolar-2007-2008-comenca-amb-la-posada-en'),
('H31','Ajuntament — inici de curs 2009–2010','https://www.mataro.cat/ca/actualitat/noticies/2009/mataro-comenca-el-curs-escolar-2009-2010-amb'),
('H32','Institut Damià Campeny — Presentació','https://www.idc.cat/sec-Presentacini-10932.html'),
('H33','Institut Laia l’Arquera — Història','https://institutlaialarquera.cat/linstitut/'),
('H34','Institut Thos i Codina — Història','https://www.iesthosicodina.cat/el-centre/'),
('H35','Escola Cirera — La nostra història','https://escolacirera.cat/historia/'),
('H36','Ajuntament — inici dels dos instituts escola, 2018–2019','https://www.mataro.cat/ca/actualitat/noticies/2018/el-curs-2018-2019-comenca-amb-l2019entrada-en'),
('H37','Ajuntament / IME — 25 anys d’escola pública, 1978–2003','https://www.mataro.cat/ca/actualitat/publicacions/ensenyament/25-anys-descola-publica-1978-2003'),
('H38','Escola Josep Manuel Peramàs — novembre de 2021','https://agora.xtec.cat/ceipjmperamas/2021/11/'),
('H39','Fundació el Maresme — Escola l’Arboç','https://www.fundaciomaresme.cat/centres/escola-arboc/'),
('H40','Fundació el Maresme — Memòria 2011','https://www.fundaciomaresme.cat/wp-content/uploads/2014/07/2011.pdf')]
for i,t,u in sources:F.append(dict(id_font=i,titol=t,url=u,consulta='2026-11-18',tipus='institucional',abast='Fita educativa o espacial; la precisió i les limitacions consten a cada esdeveniment'))
write('fonts_historiques_v8.csv',F);fm={r['id_font']:r for r in F}
a=read('mataro_centres_2026_2027.csv');am={r['codi_centre']:r for r in a};E=read('esdeveniments_historics_v7.csv');oldcodes={e['codi_actual_referencia'] for e in E}
def ev(c,k,d,f,claim,loc,notes='',end=None):
 assert c in am
 E.append(dict(id_esdeveniment='HIST-'+str(len(E)+1).zfill(3),id_entitat='ENT-'+c,codi_actual_referencia=c,centre=am[c]['nom'],tipus=k,data_min=d,data_max=end or d,precisio='curs' if end else ('mes' if len(d)==7 else 'any'),afirmacio=claim,id_font=f,font_url=fm[f]['url'],localitzador=loc,estat='documentat en font institucional',notes=notes))
ev('08065287','inici_escola','2007','H30','Inici del curs 2007–2008 en espais compartits amb Antonio Machado.','Nous centres; educació primària','Curs escolar, no dia exacte.',end='2008')
ev('08067430','inici_escola','2007','H30','Inici del curs 2007–2008 a l’antic Anxaneta, compartint edifici amb Can Marfà.','Nous centres','La font indica Camí Ral 257; altres documents indiquen 247. Seu històrica sense nova geometria.',end='2008')
ev('08068938','obertura_classes','2007-09','H30','Entrada en funcionament de l’escola bressol Elna el setembre de 2007.','Educació infantil de primer cicle','La nota anuncia el 10 de setembre; es conserva precisió de mes.')
ev('08068082','obertura_classes','2007-01','H30','Inici d’activitat de l’escola bressol Els Menuts el gener de 2007.','Educació infantil de primer cicle')
ev('08063874','trasllat_seu','2007-04','H30','Ocupació de la ubicació definitiva d’Antonio Machado des d’abril de 2007.','Educació infantil i primària','És un canvi d’ubicació; no prova la data de fundació del centre.')
ev('08064994','inici_escola','2006','H31','Inici d’activitat en mòduls provisionals el curs 2006–2007.','Educació infantil i primària',end='2007')
ev('08064994','nova_seu','2009-09','H31','Nou edifici de Maria Mercè Marçal acabat per al curs 2009–2010.','Educació infantil i primària','La nota preveu classes el 14 de setembre; no es confon amb inauguració oficial.')
ev('08071470','inici_escola','2009','H31','Inici de funcionament de l’Escola Municipal de Música el curs 2009–2010.','Escola Municipal de Música','Centre distribuït en seus; no s’infereix una única seu inicial.',end='2010')
for c in ['08021302','08060253']:
 ev(c,'cohabitacio_seu','2012','H32','Inici de la convivència del Damià Campeny i el CFA Can Marfà en un mateix edifici el curs 2012–2013.','Presentació, paràgraf sobre edificis','Un mateix fet es relaciona amb dos centres diferents; només compta una vegada per centre.',end='2013')
ev('08052931','us_compartit_seu','2016','H32','L’edifici seu de l’EOI i del centre de recursos acull també segon de batxillerat del Damià Campeny des del curs 2016–2017.','Presentació, paràgraf sobre edificis','Fita d’ús compartit documentada per l’institut; fundació de l’EOI pendent.',end='2017')
ev('08046797','inici_institut','1988','H33','Inici com a extensió de batxillerat compartint edifici amb l’escola Pla d’en Boet.','Història')
ev('08046797','inauguracio_edifici','1999','H33','Inauguració del nou edifici de l’institut.','Història')
ev('08046748','transformacio_centre','1989','H34','Transformació de l’antiga escola de primària Thos i Codina en institut de formació professional.','Història','La continuïtat del nom no implica que l’institut existís abans de 1989.')
ev('08046748','ensenyament','1996','H34','Incorporació dels estudis d’ESO el curs 1996–1997.','Història',end='1997')
ev('08056614','inici_escola','1997','H35','La història institucional situa el sorgiment de l’Escola Cirera l’any 1997.','La nostra història','La web descriu una fusió de tres centres. La seqüència dels antecedents necessita contrast i no s’ha codificat com una successió resolta.')
for c in ['08076145','08076157']:
 ev(c,'transformacio_institut_escola','2018','H36','Entrada en funcionament com a institut escola el curs 2018–2019.','Introducció i novetats','No és la data de fundació de l’escola precedent.',end='2019')
ev('08034333','inici_escola','1978','H37','Inici de La Llàntia en diversos espais provisionals.','p. 24, Hi havia una vegada')
ev('08034333','reagrupament_seu','1979','H37','A partir del curs 1979–1980 l’alumnat d’EGB es reagrupa a Sant Josep de Calassanç.','p. 24','El parvulari continuava en un altre espai.',end='1980')
ev('08034333','absorcio_centre','1995','H37','Absorció de l’escola Cerdanyola el curs 1995–1996.','p. 25',end='1996')
ev('08034321','inauguracio_escola','1978','H37','Inauguració de Torre Llauder el curs 1978–1979.','p. 30, Fets que marquen els 25 anys','La font esmenta alumnat de locals provisionals i de San Cucufate.',end='1979')
ev('08034321','fusio_centre','1994','H37','Fusió amb l’escola pública Pla d’en Boet.','p. 30, Fets que marquen els 25 anys','No es confon l’escola anterior amb l’actual institut Laia l’Arquera.')
ev('08042858','obertura_classes','1978-10','H37','Inici de l’escola de persones adultes avui coneguda com Els Tarongers, en baixos del carrer Marathón.','p. 33, moment 3')
ev('08042858','nova_seu','1985-09','H37','Inauguració de la seu d’Els Tarongers després de set cursos en locals.','p. 7','La font de 2003 l’anomena seu actual; no es generalitza automàticament a 2026.')
ev('08020917','commemoracio','2021','H38','Commemoració del cinquantenari durant el curs 2021–2022.','Entrades de 24 i 30 novembre 2021','No es calcula una data fundacional exacta restant cinquanta anys.',end='2022')
ev('08034308','creacio_servei_educatiu','1978','H39','Creació del servei educatiu l’Arboç.','Descripció inicial; codi administratiu 08034308')
ev('08034308','trasllat_seu','2011-09','H40','Inici de l’activitat escolar al nou edifici de Vallveric.','p. 12, Destacats 2011','La memòria confirma l’ocupació efectiva, més enllà de previsions d’obra.')
E.sort(key=lambda e:(e['data_min'],e['id_esdeveniment']));write('esdeveniments_historics_v8.csv',E)
counts=collections.Counter(e['codi_actual_referencia'] for e in E);newcodes=set(counts)-oldcodes
assert len(newcodes)==20 and len(counts)==38 and len(a)==75
# Only label origin where an origin is actually documented; otherwise retain pending origin.
origin_kinds={'inici_escola','obertura_classes','inici_institut','creacio_servei_educatiu'}
for r in a:
 c=r['codi_centre'];r['nombre_fites_documentades']=counts[c]
 if c in newcodes:
  es=[e for e in E if e['codi_actual_referencia']==c];orig=next((e for e in es if e['tipus'] in origin_kinds),None)
  r['estat_recerca_historica']='fites documentades; història parcial'
  if orig:r.update(fundacio_any='',fundacio_font=orig['font_url'],tipus_data_origen=orig['tipus'],origen_data_min=orig['data_min'],origen_data_max=orig['data_max'])
write('mataro_centres_2026_2027.csv',a)
g=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in g['features']:f['properties']=am[f['properties']['codi_centre']]
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(g,ensure_ascii=False,indent=2))
write('cobertura_recerca_v8.csv',[dict(codi_centre=r['codi_centre'],centre=r['nom'],naturalesa_actual=r['naturalesa'],fites_documentades=counts[r['codi_centre']],estat='iniciat' if counts[r['codi_centre']] else 'pendent',nota='Almenys una fita; no equival a història completa') for r in a])
write('centres_incorporats_v8.csv',[dict(codi_centre=c,centre=am[c]['nom'],fites=counts[c],fonts=' | '.join(sorted({e['id_font'] for e in E if e['codi_actual_referencia']==c}))) for c in sorted(newcodes)])
chron=(out/'cronologia.html').read_text();names=sorted({(e['codi_actual_referencia'],e['centre']) for e in E},key=lambda x:x[1])
opts='<option value="">Tots els centres documentats</option>'+''.join('<option value="'+c+'">'+html.escape(n)+'</option>' for c,n in names)
chron=re.sub(r'(<select id="centre">).*?(</select>)',lambda m:m[1]+opts+m[2],chron,count=1,flags=re.S)
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['data_min']+'–'+e['data_max'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(fm[e['id_font']]['titol'])+' · '+html.escape(e['localitzador'])+'</a></p></article>' for e in E)
chron=re.sub(r'<article.*?</article>(?:<article.*?</article>)*',lambda m:items,chron,count=1,flags=re.S).replace('36 fites documentades de 18 centres',f'{len(E)} fites documentades de 38 centres (50,7% de 75)').replace('V7','V8');(out/'cronologia.html').write_text(chron)
idx=(out/'index.html').read_text().replace('versió 7','versió 8').replace('36 fites',f'{len(E)} fites').replace('La reconstrucció històrica des de 1737 està pendent.', 'Recerca històrica parcial des de 1737: 38 centres amb alguna fita documentada.');idx=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',idx,count=1,flags=re.S)
idx=idx.replace('</header>','<p><a href="cobertura.html">Cobertura històrica: 38/75 centres · 50,7%</a></p></header>');(out/'index.html').write_text(idx)
rows=''.join('<tr><td>'+html.escape(r['nom'])+'</td><td>'+str(counts[r['codi_centre']])+'</td><td>'+('Iniciada' if counts[r['codi_centre']] else 'Pendent')+'</td></tr>' for r in sorted(a,key=lambda r:r['nom']))
(out/'cobertura.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Cobertura de recerca</title><style>body{font:17px system-ui;max-width:980px;margin:40px auto;padding:20px;color:#243b35;background:#f7f5ed}table{border-collapse:collapse;width:100%}td,th{text-align:left;padding:10px;border-bottom:1px solid #ccc}a{color:#25634e}</style><h1>38 de 75 centres: 50,7%</h1><p>Almenys una fita històrica documentada. La cobertura mesura recerca iniciada; no històries completes ni qualitat educativa. Denominador: 75 codis de centre del registre 2026–2027.</p><p><a href="index.html">Mapa</a> · <a href="cronologia.html">Cronologia</a> · <a href="cobertura_recerca_v8.csv">Descarrega la cobertura</a></p><table><thead><tr><th>Centre</th><th>Fites</th><th>Recerca</th></tr></thead><tbody>'+rows+'</tbody></table></html>')
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=8,fites_historiques=len(E),centres_amb_fites=38,centres_pendents=37,cobertura_percent=round(38/75*100,2),denominador_centres=75,centres_nous_v8=20,fites_noves_v8=len(E)-36);(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V8.md').write_text(f'''# Mataró, ciutat d’escoles — V8
Guia vigent del paquet acumulatiu, 18-11-2026.

Objectiu assolit: 38 dels 75 centres del registre 2026–2027 tenen almenys una fita documentada (50,7%). 37 pendents. {len(E)} fites, {len(E)-36} noves; 20 centres incorporats. No equival a 38 històries completes. Inclou obertures, trasllats, usos compartits, canvis de tipus de centre i una commemoració; no s’inventen fundacions.

Obrir index.html (mapa), cronologia.html (fites) o cobertura.html (llistat dels 75). Els mapes requereixen Internet. Aquesta fase no publica cap web.

## Fitxers vigents
esdeveniments_historics_v8.csv; fonts_historiques_v8.csv; cobertura_recerca_v8.csv; centres_incorporats_v8.csv; mataro_centres_2026_2027.csv/.geojson. Les versions anteriors són antecedents acumulatius i no s’han de sumar. Les taules de seus continuen en estat V7; no s’ha inferit nova geometria a partir de les fites d’aquesta fase.

## Criteri i limitacions
Denominador: codis de centre actuals, no edificis ni entitats històriques. Damià Campeny i CFA Can Marfà tenen codis diferents i comparteixen un fet espacial; es relaciona amb tots dos. EOI incorpora l’ús compartit amb batxillerat de Damià, sense atribuir-li una fundació. Antonio Machado incorpora seu definitiva d’abril de 2007. Peramàs incorpora la commemoració publicada de 2021–2022; no s’ha restat 50 per fabricar un dia d’obertura. Els instituts escola tenen canvi de tipologia de 2018–2019, no origen de les escoles anteriors. Cirera: origen 1997 segons el centre; antecedents de la fusió pendents de contrast. La Llàntia: la narració retrospectiva descriu diverses fases espacials; s’han conservat separades. Montserrat Solà: discrepància de número al Camí Ral pendent; no es fixa un punt històric.

Es mantenen els 75 centres, 74 punts de centre i 77 seus actuals conegudes (75 amb geometria) del paquet anterior. La cronologia filtra esdeveniments pel primer any del curs: no representa totes les escoles actives en cada any. Origen desconegut continua desconegut encara que hi hagi una altra fita.

Validats recomptes, codis, fonts, intervals, GeoJSON, dades del visor i integritat ZIP. Sintaxi JavaScript comprovada. Sense inspecció visual amb navegador ni verificació arxivística completa. Fonts institucionals amb URL i localitzador a cada fita.
''')
shutil.copy2(__file__,out/'amplia_mataro_v8.py')
assert len({e['id_esdeveniment'] for e in E})==len(E)
assert all(e['id_font'] in fm and e['codi_actual_referencia'] in am and e['data_min']<=e['data_max'] for e in E)
assert len(g['features'])==74 and len({f['properties']['codi_centre'] for f in g['features']})==74
assert len(re.findall('<article data-year=',chron))==len(E)
for n in ['index.html','cronologia.html']:
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',(out/n).read_text(),re.S)):Path('/tmp/v8_'+n+str(i)+'.js').write_text(s)
m={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(m,indent=2))
zp=B/'Mataro_ciutat_escoles_V8_50percent_2026-11-18.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v8/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(json.dumps({'zip':str(zp),'centres':len(counts),'total':len(a),'fites':len(E),'nous':len(newcodes)},ensure_ascii=False))
