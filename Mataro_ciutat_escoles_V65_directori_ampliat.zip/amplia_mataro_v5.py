from pathlib import Path
import csv,json,shutil,re,html,zipfile,hashlib
B=Path(__file__).parent;out=B/'mataro_escoles_v5';shutil.copytree(B/'mataro_escoles_v4',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,a):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(a[0]));w.writeheader();w.writerows(a)
F=read('fonts_historiques_v4.csv')
for id,title,url in [
('H15','Ajuntament — classes a Torre Llauder, 12-11-2012','https://www.mataro.cat/ca/actualitat/noticies/2012/l2019alumnat-de-l2019escola-angeleta-ferrer'),
('H16','Ajuntament — estintolament de plaça de Cuba 10','https://www.mataro.cat/ca/actualitat/noticies/2012/l2019ajuntament-estintolara-l2019edifici-de?set_language=ca'),
('H17','Ajuntament — Pla d’accessibilitat, fitxa 49, visita 02-02-2007','https://www.mataro.cat/ca/actualitat/publicacions/plans-pactes-i-convenis-municipals/pla-daccessibilitat-universal-de-mataro-1/pla_dxaccessibilitat_universal_de_matarx.pdf')]:F.append({'id_font':id,'titol':title,'url':url,'consulta':'2026-11-18','tipus':'institucional','abast':'adreça i ús documentats; no data de fundació'})
write('fonts_historiques_v5.csv',F);fm={r['id_font']:r for r in F}
E=read('esdeveniments_historics_v4.csv')
for id,d,kind,claim,f,n in [('HIST-022','2007-02-02','observacio_seu','Visita d’accessibilitat al CEIP Angeleta Ferrer, plaça de Cuba 10.','H17','És una observació datada de la seu, no el seu primer dia de funcionament.'),('HIST-023','2012-11-12','inici_us_seu','Represa de les classes d’Angeleta Ferrer a Torre Llauder, Ciutat Freta 31.','H15','Data lectiva explícita. Seu compartida amb Torre Llauder; no fusió de centres.')]:
 E.append({'id_esdeveniment':id,'id_entitat':'ENT-08020905','codi_actual_referencia':'08020905','centre':'Escola Angeleta Ferrer','tipus':kind,'data_min':d,'data_max':d,'precisio':'dia','afirmacio':claim,'id_font':f,'font_url':fm[f]['url'],'localitzador':'Fitxa 49' if f=='H17' else 'primer paràgraf','estat':'documentat en font municipal','notes':n})
E.sort(key=lambda r:r['data_min']);write('esdeveniments_historics_v5.csv',E)
a=read('mataro_centres_2026_2027.csv');by={r['codi_centre']:r for r in a}
for r in a:r['nombre_fites_documentades']=len([e for e in E if e['codi_actual_referencia']==r['codi_centre']])
write('mataro_centres_2026_2027.csv',a)
geo=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in geo['features']:f['properties']=by[f['properties']['codi_centre']]
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(geo,ensure_ascii=False,indent=2))
S=[]
def seat(id,name,adr,first,last,precision,refs,code=None,note=''):
 r=by.get(code) if code else None
 S.append({'id_ocupacio':id,'codi_centre_ocupant':'08020905','nom_seu':name,'adreca':adr,'inici_documentat':first,'final_documentat':last,'precisio_temporal':precision,'fonts':' | '.join(refs),'longitud':r['longitud'] if r else '', 'latitud':r['latitud'] if r else '', 'font_coordenada':'Registre Generalitat 2026/2027; adreça conciliada amb font municipal' if r else '', 'estat_coordenada':'punt registral contemporani del mateix emplaçament; no porta històrica verificada' if r else 'pendent; ICGC 503 el 18-11-2026', 'notes':note})
seat('AF-CUBA','Seu de plaça de Cuba','Plaça de Cuba, 10 (finca 9–10 en documentació municipal)','observada 2007-02-02; inici desconegut','tancament 2012-11-08','observació i final d’ús; no interval exhaustiu',['H17','H16','H11'],note='La fitxa d’accessibilitat documenta el número 10; no s’ha assignat una coordenada estimada.')
seat('AF-TORRE','Seu provisional a Torre Llauder','Carrer de Ciutat Freta, 31','2012-11-12','abans de l’activitat del curs 2017/2018 a Can Fàbregas','inici exacte; final sense dia verificat',['H15','H12'],'08034321','Mateix edifici, dos centres; el punt reutilitza la coordenada actual de Torre Llauder.')
seat('AF-FABREGAS','Seu de Can Fàbregas del paper','Plaça de Ventura Ametller, 1–3','curs 2017/2018','observada 2026/2027; no tancament','inici per curs; darrera observació registral',['H12','H11'],'08020905','Inauguració oficial el 27-02-2019, posterior a l’ús lectiu.')
write('angeleta_ferrer_seus_v5.csv',S)
sg={'type':'FeatureCollection','features':[{'type':'Feature','geometry':{'type':'Point','coordinates':[float(s['longitud']),float(s['latitud'])]},'properties':s} for s in S if s['longitud']]}
(out/'angeleta_ferrer_seus_v5.geojson').write_text(json.dumps(sg,ensure_ascii=False,indent=2))
# Cas cartogràfic amb tres localitzacions documentals, dues geometries i sense ruta inventada.
page='''<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Angeleta Ferrer · Tres seus, una escola</title><link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"><style>body{margin:0;background:#f5f1e8;color:#223b39;font:16px system-ui}header{padding:22px 28px;border-bottom:1px solid #ccd5cc}h1{font:34px Georgia;margin:12px 0}a{color:#216c5a}main{display:grid;grid-template-columns:minmax(280px,380px) 1fr}#map{height:75vh;min-height:400px}aside{padding:20px;overflow:auto;max-height:70vh}button{display:block;text-align:left;width:100%;padding:17px;background:white;color:inherit;border:1px solid #ccd5cc;border-radius:6px;margin-bottom:12px;font:inherit;cursor:pointer}button[aria-pressed=true]{border:2px solid #216c5a;background:#e7efe4}button b{display:block;margin-bottom:8px}small{display:block;line-height:1.5}.note{font-size:14px;line-height:1.6}#detail{padding:20px 28px;border-top:1px solid #ccd5cc}@media(max-width:700px){main{display:flex;flex-direction:column}aside{max-height:none}#map{height:50vh}}</style><header><a href="index.html">← Cens actual</a> · <a href="cronologia.html">Cronologia general</a><h1>Tres seus, una escola</h1><p>Escola Angeleta Ferrer · Primer cas de cartografia documental dels trasllats.</p><small>Hi ha tres seus documentades i dos punts representats. Plaça de Cuba continua pendent de coordenada. Les dates d’ús i d’inauguració es mostren separadament.</small></header><main><aside id="steps"></aside><div id="map" aria-label="Mapa de les seus d’Angeleta Ferrer"></div></main><section id="detail" role="status"></section><script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script><script>const seats=__SEATS__,fonts=__FONTS__;const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));let map,marks={};if(window.L){map=L.map('map').setView([41.536,2.44],15);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(map);seats.filter(s=>s.longitud).forEach(s=>{marks[s.id_ocupacio]=L.circleMarker([+s.latitud,+s.longitud],{radius:10,color:s.id_ocupacio==='AF-TORRE'?'#bc713c':'#216c5a',fillOpacity:.8}).addTo(map).bindPopup(esc(s.nom_seu)+'<br>'+esc(s.adreca));});}else document.getElementById('map').textContent='Mapa no disponible; consulta les fitxes documentals.';document.getElementById('steps').innerHTML=seats.map((s,i)=>'<button type="button" data-i="'+i+'" aria-pressed="false"><b>'+esc(s.nom_seu)+'</b><small>'+esc(s.inici_documentat)+' → '+esc(s.final_documentat)+'</small></button>').join('')+'<p class="note">Els punts provenen del registre contemporani, amb adreces històriques contrastades. No representen el traçat del desplaçament ni una comprovació de l’accés històric.</p>';function choose(i){const s=seats[i];document.querySelectorAll('[data-i]').forEach(b=>b.setAttribute('aria-pressed',String(+b.dataset.i===i)));const ids=s.fonts.split(' | ');document.getElementById('detail').innerHTML='<h2>'+esc(s.nom_seu)+'</h2><p>'+esc(s.adreca)+'</p><p>'+esc(s.notes)+'</p><p><b>Precisió:</b> '+esc(s.precisio_temporal)+'<br><b>Ubicació:</b> '+esc(s.estat_coordenada)+'</p><p>'+ids.map(id=>'<a target="_blank" rel="noopener" href="'+esc(fonts[id].url)+'">'+esc(fonts[id].titol)+'</a>').join(' · ')+'</p>';if(map&&marks[s.id_ocupacio]){map.flyTo([+s.latitud,+s.longitud],16);marks[s.id_ocupacio].openPopup();}}document.querySelectorAll('[data-i]').forEach(b=>b.onclick=()=>choose(+b.dataset.i));choose(0);</script></html>'''
(out/'angeleta-ferrer.html').write_text(page.replace('__SEATS__',json.dumps(S,ensure_ascii=False).replace('</','<\\/')).replace('__FONTS__',json.dumps(fm,ensure_ascii=False).replace('</','<\\/')))
# Actualitzar cronologia amb les dues noves observacions mantenint controls.
chron=(out/'cronologia.html').read_text()
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['precisio'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(fm[e['id_font']]['titol'])+'</a></p></article>' for e in E)
chron=re.sub(r'<article.*?</article>(?:<article.*?</article>)*',lambda _:items,chron,count=1,flags=re.S).replace('21 fites','23 fites').replace('V4','V5')
chron=chron.replace('<h1>','<p><a href="angeleta-ferrer.html">Cas cartogràfic: Angeleta Ferrer</a></p><h1>',1)
(out/'cronologia.html').write_text(chron)
idx=(out/'index.html').read_text().replace('versió 4','versió 5').replace('21 fites','23 fites')
idx=idx.replace('<nav>','<nav><a href="angeleta-ferrer.html">Tres seus, una escola</a>',1)
idx=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',idx,count=1,flags=re.S)
(out/'index.html').write_text(idx)
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=5,fites_historiques=23,cas_cartografic_angeleta={'ocupacions_documentades':3,'geometries':2,'pendent':'Plaça de Cuba 10; ICGC 503'})
(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V5.md').write_text('''# Mataró, ciutat d’escoles — V5 · Tres seus, una escola
Guia vigent. 18-11-2026. Paquet acumulatiu: 75 centres actuals, 23 fites de 10 centres i primer cas cartogràfic de seus successives.

Obriu index.html, cronologia.html o angeleta-ferrer.html. Internet necessari per al mapa base i Leaflet, dades incorporades. No hi ha publicació web en aquesta fase.

## Cas Angeleta Ferrer
Tres ocupacions documentals: plaça de Cuba 10, Torre Llauder (Ciutat Freta 31) i Can Fàbregas del paper (Ventura Ametller 1–3).
- Plaça de Cuba: observació datada el 02-02-2007 a la fitxa 49 del Pla d’accessibilitat. És evidència d’ús, no data d’obertura. Tancament de la seu el 08-11-2012. La finca també figura com 9–10 en actes municipals. Sense coordenada: l’ICGC ha retornat 503 en la consulta i en un segon intent limitat.
- Torre Llauder: inici lectiu exacte el 12-11-2012, segons notícia municipal del mateix dia; final abans de l’ocupació de la nova seu el curs 2017/2018, sense dia concret verificat.
- Can Fàbregas: ús lectiu el curs 2017/2018 i inauguració oficial el 27-02-2019, dues fites diferents.

Els dos punts representats reutilitzen coordenades del registre 2026/2027 perquè la identitat de les adreces està documentada. No són aixecaments de les portes històriques ni permeten inferir tot l’interval d’activitat sense excepcions. No s’han dibuixat rutes de desplaçament.

Els fitxers nous són angeleta_ferrer_seus_v5.csv/.geojson, angeleta-ferrer.html, fonts_historiques_v5.csv i esdeveniments_historics_v5.csv. La taula d’ocupacions V4 es conserva com a antecedent, però V5 n’és l’actualització. V1–V4 conserven documentació i scripts previs amb els seus límits originals.

Validació: 75 codis actuals, 23 identificadors d’esdeveniment únics, 3 ocupacions i 2 geometries coherents amb les seus del registre; HTML i JavaScript verificats sintàcticament, sense prova visual de navegador. No s’ha incrementat el nombre d’escoles actuals pel fet d’afegir ocupacions històriques.

Següent fase: completar el punt de plaça de Cuba i estendre el model a altres trasllats. La cronologia continua parcial i el mapa general és contemporani.
''')
shutil.copy2(__file__,out/'amplia_mataro_v5.py')
assert len(E)==23 and len({e['id_esdeveniment'] for e in E})==23 and len(a)==75 and len(S)==3 and len(sg['features'])==2
assert len(re.findall('<article ',chron))==23
for n in ['index.html','cronologia.html','angeleta-ferrer.html']:
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',(out/n).read_text(),re.S)):Path('/tmp/v5_'+n+str(i)+'.js').write_text(s)
m={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(m,indent=2))
zp=B/'Mataro_ciutat_escoles_V5_seus_historiques_2026-11-18.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v5/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(zp)
