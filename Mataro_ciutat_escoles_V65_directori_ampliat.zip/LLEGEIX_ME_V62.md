# V62 · Instagram

La fitxa de l’Escola Germanes Bertomeu incorpora el compte indicat al web de l’associació de famílies.

- Instagram publicat per l’AFA de l’Escola Germanes Bertomeu · [@germanesbertomeu](https://www.instagram.com/germanesbertomeu/) · [Font](https://sites.google.com/xtec.cat/afagermanesbertomeu/p%C3%A0gina-principal)
