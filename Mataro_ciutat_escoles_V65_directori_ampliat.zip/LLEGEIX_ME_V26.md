# V26 · Fitxes educatives

Obre index.html. Les fitxes dels centres inclouen les etapes del directori. Les edats que es mostren són orientatives. Les miniatures són pictogrames genèrics.
