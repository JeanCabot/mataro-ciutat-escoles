from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile,collections,subprocess
B=Path(__file__).parent;out=B/'mataro_escoles_v10';shutil.copytree(B/'mataro_escoles_v9',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,rows,fields=None):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields or list(rows[0]));w.writeheader();w.writerows(rows)
a=read('mataro_centres_2026_2027.csv');am={r['codi_centre']:r for r in a};E=read('esdeveniments_historics_v9.csv');F=read('fonts_historiques_v9.csv');fm={r['id_font']:r for r in F};old={e['codi_actual_referencia'] for e in E}
candidates=json.load(open('/tmp/cido_candidates.json'))
def cido(n):return next('https://cido.diba.cat'+p for term,ls in candidates for p,t in ls if p.split('/')[2]==str(n))
def src(i,t,u,typ='document oficial'):
 r=dict(id_font=i,titol=t,url=u,consulta='2026-11-18',tipus=typ,abast='Fets i límits indicats a la fita o revisió');F.append(r);fm[i]=r
src('H82','DOGC — ENS/838/2011, obertura La Caseta',cido(1442053))
src('H83','DOGC — ENS/1141/2014, obertura Petit Somni','https://portaldogc.gencat.cat/utilsEADOP/AppJava/PdfProviderServlet?documentId=663185&type=01&language=ca_ES')
src('H84','DOGC — ENS/2711/2018, Peques passa a Acuarella Mataró','https://portaldogc.gencat.cat/utilsEADOP/AppJava/PdfProviderServlet?documentId=834760&type=01&language=ca_ES')
src('H85','CIDO — fitxa ENS/21/2014, obertura La Fada',cido(1753670),'metadades institucionals; text íntegre pendent')
src('H86','Horeb 598 — Inmaculada Campo, Sant Josep, 18 maig 2023','https://urc.cat/wp-content/uploads/2023/05/Horeb_-598_18_05_2023.pdf','testimoni de la congregació, publicació URC')
src('H87','DOGC — EDC/2410/2004, formació de persones adultes salesiana',cido(550028))
src('H88','DOGC — correcció geogràfica EDC/2410/2004',cido(557401))
def ev(c,k,d,f,claim,loc='',notes='',end=None,prec=None):
 E.append(dict(id_esdeveniment='HIST-'+str(max(int(x['id_esdeveniment'].split('-')[1]) for x in E)+1).zfill(3),id_entitat='ENT-'+c,codi_actual_referencia=c,centre=am[c]['nom'],tipus=k,data_min=d,data_max=end or d,precisio=prec or ('curs' if end else {4:'any',7:'mes',10:'dia'}[len(d)]),afirmacio=claim,id_font=f,font_url=fm[f]['url'],localitzador=loc,estat='documentat; contrast parcial',notes=notes))
ev('08070209','autoritzacio_obertura','2011-03-28','H82','Resolució ENS/838/2011 que autoritza La Caseta, codi 08070209, a Bonaire 14.','DOGC 5854, 07-04-2011, p. 21010','Data de resolució; els efectes es retrotrauen al curs 2010–2011. No prova el primer dia de classe.')
ev('08070209','efectes_autoritzacio_obertura','2010','H82','Inici del curs 2010–2011: efectes de l’autorització de La Caseta.','Apartat 1, després del titular','Efectes legals declarats el 2011; no s’inventa un dia concret ni es dona per provat el primer curs real.',end='2011')
ev('08074291','autoritzacio_obertura','2014-05-14','H83','Resolució ENS/1141/2014 que autoritza Petit Somni, codi 08074291, al Camí Ral 371–373.','DOGC 6631, 27-05-2014, p. 1, apartat 1','Centre de Mataró; no El Petit Somni de Vilassar de Mar.')
ev('08074291','efectes_autoritzacio_obertura','2014','H83','Inici del curs 2014–2015: efectes de l’autorització de Petit Somni.','Apartat 1','No equival a constatació del primer dia de classes. El blog té preparatius el 2013, sense provar l’obertura.',end='2015')
ev('08062547','canvi_titular_i_denominacio','2018-11-08','H84','La resolució autoritza que Peques, codi 08062547, passi a denominar-se Acuarella Mataró i a tenir Acuarella llars d’infants, SL, com a titular.','DOGC 7751, 20-11-2018, p. 1, apartat 1','Conciliació explícita per codi; la relació amb el nom Misha continua pendent. Es conserva el nom del CSV original.')
ev('08073946','autoritzacio_obertura','2014-01-02','H85','Resolució ENS/21/2014 d’autorització d’obertura del centre infantil privat La Fada, de Mataró.','Títol de la fitxa CIDO','Metadades institucionals consultades; PDF original retornava 503. Associació per nom i municipi; codi, adreça i data d’efectes del text íntegre pendents. No s’atribueix cap data al nom Pinotxo.')
ev('08021181','constitucio_comunitat_religiosa','1970','H86','Constitució oficial de la primera comunitat religiosa per dirigir Sant Josep.','p. 2, darrer paràgraf','Acte institucional diferent de les classes inicials. La discrepància 1968/1970 de les fonts de fundació continua oberta; no s’escull una fundació única.')
ev('08021181','commemoracio','2023-05-06','H86','Missa commemorativa de més de cinquanta anys del Col·legi Sant Josep al barri.','p. 2, primer paràgraf','Data de l’acte explicada per Inmaculada Campo; no es calcula la fundació restant cinquanta anys.')
ev('08021089','autoritzacio_ensenyaments_adults','2004-09-07','H87','La resolució EDC/2410/2004 autoritza formació instrumental i secundària per a persones adultes al Col·legi Salesià de Puig i Cadafalch 80, amb el codi 08021089.','DOGC 4219, 15-09-2004, p. 16942, annex','L’annex usa 08021089, no 08065123. No es trasllada aquesta fita al codi actual de persones adultes. La correcció H88 només esmena la comarca; els efectes dels ensenyaments són des de l’endemà de publicació.')
E.sort(key=lambda e:(e['data_min'],e['id_esdeveniment']));counts=collections.Counter(e['codi_actual_referencia'] for e in E);new=set(counts)-old;assert len(new)==5 and len(counts)==71 and len(E)==113
write('esdeveniments_historics_v10.csv',E);write('fonts_historiques_v10.csv',F)
for r in a:
 c=r['codi_centre'];r['nombre_fites_documentades']=counts[c]
 if c in new:r['estat_recerca_historica']='fites documentades; història parcial'+('; atribució per nom i municipi, codi DOGC pendent' if c=='08073946' else '')
# Keep original registered names; disclose documented later names without erasing source provenance.
for r in a:
 r['nota_denominacio_documentada']='ENS/2711/2018: Peques passa a Acuarella Mataró. Nom del CSV conservat; vigència posterior pendent.' if r['codi_centre']=='08062547' else ''
write('mataro_centres_2026_2027.csv',a)
g=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in g['features']:f['properties']=am[f['properties']['codi_centre']]
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(g,ensure_ascii=False,indent=2))
obs=read('evidencies_sense_fita_v9.csv');remaining=[r for r in obs if r['codi_centre'] not in counts]
for r in remaining:
 if r['codi_centre']=='08065123':r.update(fonts='H71 | H87 | H88',pendent='La resolució de 2004 usa 08021089. Trobar acte que vinculi o separi 08065123 i 08021089; no heretar 1905 ni 2004 sense prova.')
write('evidencies_sense_fita_v10.csv',remaining)
review=[]
for r in obs:
 c=r['codi_centre'];es=[e for e in E if e['codi_actual_referencia']==c and int(e['id_esdeveniment'].split('-')[1])>104]
 review.append(dict(codi_centre=c,centre=r['centre'],fites_noves=len(es),resultat='fites incorporades; història parcial' if es else 'pendent',fonts=' | '.join(sorted({e['id_font'] for e in es})) if es else next(x['fonts'] for x in remaining if x['codi_centre']==c),pendent=('Text íntegre, codi i efectes legals pendents.' if c=='08073946' else 'Fundació 1968/1970 pendent de conciliació.' if c=='08021181' else 'Origen, seus i contrast arxivístic pendents.') if es else next(x['pendent'] for x in remaining if x['codi_centre']==c)))
write('revisio_9_centres_v10.csv',review)
d=read('discrepancies_i_pistes_v9.csv')
for r in d:
 if r['id']=='D06':r.update(font=r['font']+' | H86',decisio='Conservar origen 1968/1970 sense data única; H86 separa classes inicials i comunitat religiosa formal de 1970, incorporada com a fita pròpia.')
d += [dict(id='D12',centre='Col·legi Salesià',tema='conciliació de codis',dada_a='CSV adult actual: 08065123',dada_b='Resolució EDC/2410/2004: 08021089',font='CSV | H71 | H87 | H88',decisio='No transferir la fita de 2004 al codi 08065123; correcció de 2004 només canvia la comarca.'),dict(id='D13',centre='Peques',tema='denominació',dada_a='CSV: Peques; inventari: Peques-Misha',dada_b='DOGC 2018: Acuarella Mataró, mateix codi 08062547',font='CSV | H72 | H84',decisio='Conservar nom del CSV i documentar canvi legal de 2018. Misha i nom efectivament vigent pendents.')];write('discrepancies_i_pistes_v10.csv',d)
cover=[dict(codi_centre=r['codi_centre'],centre=r['nom'],naturalesa_actual=r['naturalesa'],fites_documentades=counts[r['codi_centre']],estat='fites; història parcial' if counts[r['codi_centre']] else 'revisat; fita pendent',nota='75 codis del CSV; no tots actius. La Fada: atribució parcial, text íntegre pendent.' if r['codi_centre']=='08073946' else '75 codis del CSV; no tots actius confirmats') for r in a];write('cobertura_recerca_v10.csv',cover)
chron=(out/'cronologia.html').read_text();opts='<option value="">Tots els centres documentats</option>'+''.join('<option value="'+c+'">'+html.escape(n)+'</option>' for c,n in sorted({(e['codi_actual_referencia'],e['centre']) for e in E},key=lambda x:x[1]));chron=re.sub(r'(<select id="centre">).*?(</select>)',lambda m:m[1]+opts+m[2],chron,count=1,flags=re.S)
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['data_min']+'–'+e['data_max'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(fm[e['id_font']]['titol'])+' · '+html.escape(e['localitzador'])+'</a></p></article>' for e in E)
chron=re.sub(r'<article.*?</article>(?:<article.*?</article>)*',lambda m:items,chron,count=1,flags=re.S).replace('104 fites documentades de 66 dels 75 registres de base (88%)','113 fites documentades de 71 dels 75 registres de base (94,7%)').replace('V9','V10');(out/'cronologia.html').write_text(chron)
idx=(out/'index.html').read_text().replace('versió 9','versió 10').replace('104 fites','113 fites').replace('66 centres amb alguna fita documentada','71 centres amb alguna fita documentada').replace('66/75 registres · 88%','71/75 registres · 94,7%');idx=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',idx,count=1,flags=re.S)
idx=idx.replace("esc(r.nota_seu_actual)+'</small>","esc(r.nota_seu_actual)+'<br>'+esc(r.nota_denominacio_documentada)+'</small>")
(out/'index.html').write_text(idx)
rows=''.join('<tr><td>'+html.escape(r['nom'])+'</td><td>'+str(counts[r['codi_centre']])+'</td><td>'+('Fites; història parcial' if counts[r['codi_centre']] else 'Fita pendent')+'</td></tr>' for r in sorted(a,key=lambda r:r['nom']))
(out/'cobertura.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Cobertura V10</title><style>body{font:17px system-ui;max-width:980px;margin:40px auto;padding:20px;color:#243b35;background:#f7f5ed}table{border-collapse:collapse;width:100%}td,th{text-align:left;padding:10px;border-bottom:1px solid #ccc}a{color:#25634e}</style><h1>71 de 75 registres: 94,7%</h1><p>113 fites; històries parcials. Cinc dels nou casos pendents de V9 incorporen fites. La Fada té autorització documentada en metadades CIDO; el codi i els efectes del text íntegre resten pendents. Cobertura amb text íntegre o font narrativa dels altres casos: 70/75 (93,3%). El denominador és el CSV, no 75 centres actius confirmats.</p><p><a href="index.html">Mapa</a> · <a href="cronologia.html">Cronologia</a> · <a href="revisio_9_centres_v10.csv">Revisió dels nou</a> · <a href="evidencies_sense_fita_v10.csv">Quatre casos pendents</a></p><table><tr><th>Centre</th><th>Fites</th><th>Recerca</th></tr>'+rows+'</table></html>')
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=10,fites_historiques=len(E),centres_amb_fites=len(counts),centres_pendents=len(remaining),cobertura_percent=round(100*len(counts)/75,2),centres_amb_fites_text_integre_o_narrativa=70,centres_amb_fites_nomes_metadades=1,centres_nous_v10=5,fites_noves_v10=9,punts_al_visor=73,punts_centres=73,punts_centre=73,seus_documentades=78,observacions_seus=78,coordenades_pendents=['08078695','08046438'],nota='75 codis de base; vigència parcial. Seu provisional Figueretes sense punt. 71 codis amb fites inclou La Fada per metadades CIDO amb atribució parcial.');(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
D=out/'documents_v10';D.mkdir(exist_ok=True)
for n in ['1442053','1778149','8259215','550028','557401']:
 for ext in ['pdf','txt']:
  p=Path('/tmp/cido_details')/(n+'.'+ext)
  if p.exists() and (ext!='pdf' or p.read_bytes().startswith(b'%PDF')):shutil.copy2(p,D/p.name)
# Preserve institutional metadata used for the limited La Fada attribution.
shutil.copy2('/tmp/cido_details/1753670.html',D/'1753670_cido.html')
(out/'LLEGEIX_ME_V10.md').write_text('''# Mataró, ciutat d’escoles — V10, 18-11-2026
Paquet acumulatiu. Obre index.html per al mapa, cronologia.html per a les fites i cobertura.html per al progrés. No s’ha publicat en línia.

113 fites de 71 dels 75 codis de base (94,7%); són històries parcials, no 71 fundacions verificades. La Fada s’incorpora amb les metadades institucionals d’autorització per nom i municipi: codi, adreça i efectes del text íntegre encara pendents. Sense aquest cas parcial, cobertura 70/75 (93,3%). Els 75 són els codis del CSV aportat; no tots són centres actius confirmats.

Novetats: La Caseta, resolució 28-03-2011 amb efectes des de l’inici del curs 2010–2011; Petit Somni, resolució 14-05-2014 amb efectes des del curs 2014–2015; Peques, canvi explícit a Acuarella Mataró el 08-11-2018; La Fada, autorització ENS/21/2014 de 02-01-2014 segons CIDO. Sant Josep: comunitat religiosa formal de 1970 i commemoració de 06-05-2023; fundació única 1968/1970 pendent. Resolució, publicació, efectes legals i primer dia de classes són conceptes separats.

Quatre codis sense fita atribuïble: Col·legi Salesià 08065123, Picasoques 08078695, Heidi Consegal 08056948 i GiEscola 08078877. La resolució salesiana de 2004 porta 08021089 i s’ha incorporat a aquest codi, sense transferir-la al codi adult 08065123. La correcció posterior només esmena la comarca. Cal acte de conciliació de codis.

Fitxers vigents: esdeveniments_historics_v10.csv, fonts_historiques_v10.csv, revisio_9_centres_v10.csv, evidencies_sense_fita_v10.csv, discrepancies_i_pistes_v10.csv, cobertura_recerca_v10.csv, mataro_centres_2026_2027.csv/.geojson i inventari de seus. Els fitxers V1–V9 es mantenen com a checkpoints: no s’han de sumar. Documents oficials consultats de V10 i text extret a documents_v10; La Fada conserva la fitxa CIDO i no un PDF que no s’ha pogut obtenir.

El nom Peques del CSV es conserva, amb nota de denominació legal de 2018; Misha i vigència posterior encara pendents. Es mantenen les correccions V9: Nemomarlin cessat, seu antiga del Liceu tancada, Figueretes provisional a Isern 18 sense geometria inventada. Mapa amb 73 punts i 78 observacions de seu (no 78 seus actives). El filtre temporal representa fites, no un cens complet d’escoles actives per any.

Validació: codis i fonts íntegres, intervals coherents, 113 articles a cronologia, propietats GeoJSON i dades del visor sincronitzades, sintaxi JavaScript correcta, enllaços locals, SHA256 i integritat ZIP. Sense inspecció visual en navegador ni comprovació arxivística exhaustiva.
''')
shutil.copy2(__file__,out/'amplia_mataro_v10.py')
assert len(a)==75 and len(am)==75 and len({e['id_esdeveniment'] for e in E})==len(E)
assert all(e['id_font'] in fm and e['codi_actual_referencia'] in am and e['data_min']<=e['data_max'] for e in E)
assert {r['codi_centre'] for r in remaining}==set(am)-set(counts)
assert chron.count('<article data-year=')==len(E)
for name in ['index.html','cronologia.html','cobertura.html']:
 text=(out/name).read_text()
 for link in re.findall(r'href="([^"#]+)"',text):
  if not link.startswith(('http:','https:',chr(39))):assert (out/link).exists(),link
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',text,re.S)):
  p=Path('/tmp')/('v10_'+name+str(i)+'.js');p.write_text(s);subprocess.run(['node','--check',str(p)],check=True,capture_output=True)
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(manifest,indent=2))
zp=B/'Mataro_ciutat_escoles_V10_autoritzacions_2026-11-18.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v10/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(json.dumps(dict(zip=str(zp),fites=len(E),centres=len(counts),pendents=len(remaining),bytes=zp.stat().st_size)))
