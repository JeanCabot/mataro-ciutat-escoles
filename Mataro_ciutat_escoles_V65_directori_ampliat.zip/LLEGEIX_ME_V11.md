# Mataró, ciutat d’escoles — V11, 18-11-2026
Paquet acumulatiu: obre index.html, cronologia.html i cobertura.html. Sense publicació en línia.

116 fites, 73 dels 75 codis amb almenys una fita (97,3%). Cobertura de fites heterogènies, no de fundacions ni d’històries completes. Gi entra per consolidació de projecte el 2012 segons relat de la directora, no per autorització dels cicles. Heidi entra per una actuació escolar de gener de 2015, no per fundació. Aquest criteri inclou activitat cultural igual que les fites de patrimoni escolar i commemoracions ja presents; no s’han convertit llistats de mera presència en dates d’origen.

La Fada: recuperat el text íntegre ENS/21/2014. Confirma codi 08073946 i adreça ronda Alfons X el Savi 131, baixos. Resolució 02-01-2014, publicació 16-01-2014, efectes des de l’inici del curs 2013–2014. HIST-110 manté identificador però ara cita H89; H85 conserva les metadades del pas anterior. S’afegeix la fita d’efectes legals. Primer dia de classes i relació amb Pinotxo pendents.

Gi: la biografia d’Inma Garcia al web del centre diu que el projecte es consolida el 2012. No es data l’alta del codi 08078877, l’obertura del local ni l’autorització de cicles amb aquesta afirmació. Els antecedents Shoot 1996/1999 i idea de 2005 no s’hereten com a fundació del centre actual.
Heidi: la crònica municipal de 16-01-2015 documenta l’actuació de l’alumnat a la gala Mataró ciutat de valors. La fundació i l’autorització continuen pendents; no s’utilitza la data de 2001 del directori que la confon amb un centre de primària.

Dos codis sense fita atribuïble: Col·legi Salesià 08065123 i Picasoques 08078695. Col·legi Salesià té oferta oficial documentada 2008 i PFI 2024–2025; no es presenta el llistat PFI com a autorització inicial. Continua pendent la conciliació amb 08021089 de la resolució de 2004. Picasoques té activitat documentada i web amb codi i adreça, sense data inicial confirmada; cap relació provada amb una societat mercantil homònima. No s’han incorporat aquestes coincidències com a fundacions.

Fitxers vigents: esdeveniments_historics_v11.csv, fonts_historiques_v11.csv, cobertura_recerca_v11.csv, evidencies_sense_fita_v11.csv, revisio_pendents_v11.csv, discrepancies_i_pistes_v11.csv i base CSV/GeoJSON principal. Documents oficials consultats a documents_v11. Versions anteriors: checkpoints; no sumar-ne les files.
Es mantenen les correccions de vigència i de seus de V9–V10. 75 codis no significa 75 centres actius confirmats. 73 punts al mapa i 78 observacions de seu; el filtre temporal representa fites i no escoles actives a cada any.

Validació de codis, fonts, intervals, enllaços locals, propietats GeoJSON, dades del visor, sintaxi JavaScript, integritat ZIP i SHA256. Sense comprovació visual amb navegador ni auditoria arxivística exhaustiva.
