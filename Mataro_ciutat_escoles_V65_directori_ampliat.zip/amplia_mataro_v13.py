from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile,collections,subprocess
B=Path(__file__).parent;out=B/'mataro_escoles_v13';shutil.copytree(B/'mataro_escoles_v12',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,rows):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
a=read('mataro_centres_2026_2027.csv');am={r['codi_centre']:r for r in a};E=read('esdeveniments_historics_v11.csv');F=read('fonts_historiques_v11.csv');fm={r['id_font']:r for r in F}
def src(i,t,u,typ):
 r=dict(id_font=i,titol=t,url=u,consulta='2026-11-18',tipus=typ,abast='Fets i límits indicats en les fites i la revisió');F.append(r);fm[i]=r
src('H93','EOI del Maresme — Projecte educatiu, aprovat novembre 2019','https://www.eoimaresme.cat/wp-eoimaresme/wp-content/uploads/2020/02/PEC_2019_2.pdf','document del centre; relat retrospectiu')
src('H94','Antonio Machado — definició institucional','https://agora.xtec.cat/esc-antoniomachado/lescola/qui-som-i-com-som/','història institucional del centre')
def ev(c,k,d,f,claim,loc,notes,end=None):
 E.append(dict(id_esdeveniment='HIST-'+str(max(int(x['id_esdeveniment'].split('-')[1]) for x in E)+1).zfill(3),id_entitat='ENT-'+c,codi_actual_referencia=c,centre=am[c]['nom'],tipus=k,data_min=d,data_max=end or d,precisio='curs' if end else 'any' if len(d)==4 else 'dia',afirmacio=claim,id_font=f,font_url=fm[f]['url'],localitzador=loc,estat='documentat; contrast parcial',notes=notes))

ev('08054113','fundacio','1965-10-04','H10','Fundació de l’escola Anxaneta per iniciativa de famílies, segons la història institucional del centre.','Història, paràgraf de fundació','Origen del projecte escolar predecessor; no és la data d’alta del codi públic actual. Pas a la xarxa pública el 1987 ja documentat; la història del centre afirma continuïtat.')
ev('08052931','inici_escola','2002','H93','Naixement de l’EOI del Maresme, amb primera ubicació a l’Institut Damià Campeny.','PEC 2019, p. 4, apartat 2.1','Data del relat institucional; no s’ha localitzat encara l’acte administratiu de creació ni el primer dia exacte de classes.')
ev('08052931','trasllat_seu','2004','H93','El PEC situa des del curs 2004 la seu de l’EOI al carrer Onofre Arnau 32.','PEC 2019, p. 4, apartat 2.1','La font diu «des del curs 2004» sense donar dia ni segon any. Es conserva precisió d’any; no es converteix en data exacta d’ocupació.')
ev('08063874','creacio_escola','2005','H94','Creació de l’Escola Antonio Machado segons la definició institucional del centre.','Primer paràgraf de definició institucional','No es confon l’origen de 2005 amb el trasllat a l’edifici definitiu d’abril de 2007 ja documentat.')
E.sort(key=lambda e:(e['data_min'],e['id_esdeveniment']));counts=collections.Counter(e['codi_actual_referencia'] for e in E);assert len(E)==120 and len(counts)==73
write('esdeveniments_historics_v13.csv',E);write('fonts_historiques_v13.csv',F)
origin_ids={'08054113':'HIST-117','08052931':'HIST-118','08063874':'HIST-120','08020929':'HIST-073','08034321':'HIST-058','08046748':'HIST-050'}
changes=[]
for r in a:
 c=r['codi_centre'];r['nombre_fites_documentades']=counts[c]
 if c in origin_ids:
  e=next(x for x in E if x['id_esdeveniment']==origin_ids[c]);assert e['codi_actual_referencia']==c
  changes.append(dict(codi_centre=c,centre=r['nom'],tipus_anterior=r['tipus_data_origen'],data_anterior=r['origen_data_min'],nou_tipus=e['tipus'],nova_data_min=e['data_min'],nova_data_max=e['data_max'],id_esdeveniment=e['id_esdeveniment'],id_font=e['id_font'],limit=e['notes']))
  r.update(tipus_data_origen=e['tipus'],origen_data_min=e['data_min'],origen_data_max=e['data_max'],fundacio_any='',fundacio_font=e['font_url'],estat_recerca_historica='origen institucional documentat; història parcial')
  if c=='08054113':r['tipus_data_origen']='fundació del projecte predecessor; codi públic posterior'
  if c=='08046748':r['tipus_data_origen']='transformació de primària en institut'
write('revisio_sis_origens_v13.csv',changes);write('mataro_centres_2026_2027.csv',a)
g=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in g['features']:f['properties']=am[f['properties']['codi_centre']]
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(g,ensure_ascii=False,indent=2))
# Audit is rebuilt from the updated canonical data and events.
by=collections.defaultdict(list)
for e in E:by[e['codi_actual_referencia']].append(e)
audit=[]
for r in a:
 c=r['codi_centre'];es=sorted(by[c],key=lambda e:(e['data_min'],e['id_esdeveniment']));first=es[0] if es else {};typ=r['tipus_data_origen'];d=r['origen_data_min']
 if not d:cat='camp d’origen buit; recerca pendent'
 elif 'antecedent' in typ or 'patronat' in typ or 'predecessor' in typ:cat='antecedent; no obertura del centre actual'
 elif 'administrativa' in typ or 'creació' in typ or 'transformació' in typ or typ=='creacio_escola':cat='constitució o creació; classes pendents de distingir'
 elif 'projecte' in typ:cat='inici de projecte; no autorització del codi'
 else:cat='data d’origen declarada; contrast segons font'
 specific={
 '08065123':'Conciliar codis 08065123 i 08021089 i trobar autorització pròpia. No heretar 1905 ni 2004.',
 '08078695':'Autorització i primer curs pendents. Corregir coordenada del CSV només amb portal 27 documentat.',
 '08073946':'Autorització i efectes legals confirmats; primer curs real i relació amb Pinotxo pendents.',
 '08078877':'2012 és consolidació del projecte segons la directora; alta del codi i autorització de cicles pendents.',
 '08056948':'2015 és actuació escolar; no és fundació ni autorització.',
 '08021181':'Conciliar 1968/1970: classes inicials, comunitat religiosa i actes d’inauguració.',
 }
 audit.append(dict(codi_centre=c,centre=r['nom'],fites_documentades=len(es),categoria_origen=cat,tipus_data_origen=typ,origen_data_min=d,origen_data_max=r['origen_data_max'],font_origen=r['fundacio_font'],primera_fita_id=first.get('id_esdeveniment',''),primera_fita_data=first.get('data_min',''),primera_fita_tipus=first.get('tipus',''),primera_fita_font=first.get('font_url',''),control='Primera fita cronològica no equival a fundació.',tasca_prioritaria=specific.get(c,'Precisar què data la font d’origen i contrastar-la.' if d else 'Cercar origen del centre; no adoptar la primera fita com a fundació.')))
write('auditoria_origens_v13.csv',audit);stats=collections.Counter(x['categoria_origen'] for x in audit);norigin=sum(bool(x['origen_data_min']) for x in audit);assert norigin==46
# Candidates are extracted from documented events but do not silently overwrite canonical origins.
missing=[e for e in E if not next(r for r in a if r['codi_centre']==e['codi_actual_referencia'])['origen_data_min'] and e['tipus'] in {'origen_declarat','inauguracio_escola','antecedent_aulari','consolidacio_projecte_escolar','autoritzacio_obertura'}]
write('pistes_origen_per_revisar_v13.csv',[dict(codi_centre=e['codi_actual_referencia'],centre=e['centre'],id_esdeveniment=e['id_esdeveniment'],tipus=e['tipus'],data=e['data_min'],id_font=e['id_font'],afirmacio=e['afirmacio'],decisio='Candidat de revisió; no afegit al camp canònic d’origen automàticament.') for e in missing])
queries=[('CIDO','soques; Pica-Soques; Salesia; Salesians; Salesià','Sense nou acte atribuïble inequívocament als dos codis.','No prova que l’acte no existeixi; cercador de títols i indexació incompleta.'),('Web pública','08065123 autorització; Col·legi Salesià formació d’adults resolució','Retorna resolució de 2004 amb altre codi i llistats d’oferta ja coneguts.','No es converteix l’oferta en autorització inicial.'),('Web pública','Picasoques Mataró obertura; Pica-soques Mataró inauguració','Web del centre, directori i resultats homònims, sense data d’origen contrastada.','No s’atribueixen societats, revistes o escoles d’altres municipis.'),('Web oficial Picasoques','Contacte, ronda República 27','El mapa incrustat és una cerca textual de l’adreça.','No aporta una coordenada de portal verificada; no es corregeix geometria per inferència.')]
write('registre_recerca_v13.csv',[dict(data_consulta='2026-11-18',via=v,consulta=q,resultat=r,limit=l) for v,q,r,l in queries])
chron=(out/'cronologia.html').read_text();opts='<option value="">Tots els centres documentats</option>'+''.join('<option value="'+c+'">'+html.escape(n)+'</option>' for c,n in sorted({(e['codi_actual_referencia'],e['centre']) for e in E},key=lambda x:x[1]));chron=re.sub(r'(<select id="centre">).*?(</select>)',lambda m:m[1]+opts+m[2],chron,count=1,flags=re.S)
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['data_min']+'–'+e['data_max'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(fm[e['id_font']]['titol'])+' · '+html.escape(e['localitzador'])+'</a></p></article>' for e in E)
chron=re.sub(r'<article.*?</article>(?:<article.*?</article>)*',lambda m:items,chron,count=1,flags=re.S).replace('116 fites documentades de 73 dels 75 registres de base (97,3%)','120 fites documentades de 73 dels 75 registres de base (97,3%)').replace('V12','V13');(out/'cronologia.html').write_text(chron)
idx=(out/'index.html').read_text().replace('versió 12','versió 13').replace('116 fites','120 fites').replace('71 centres amb alguna fita documentada','73 centres amb alguna fita documentada').replace('71/75 registres · 94,7%','73/75 registres · 97,3%');idx=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',idx,count=1,flags=re.S);(out/'index.html').write_text(idx)
rows=''.join('<tr><td>'+html.escape(r['nom'])+'</td><td>'+str(counts[r['codi_centre']])+'</td><td>'+html.escape(r['estat_recerca_historica'])+'</td></tr>' for r in sorted(a,key=lambda r:r['nom']))
(out/'cobertura.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Cobertura V11</title><style>body{font:17px system-ui;max-width:980px;margin:40px auto;padding:20px;color:#243b35;background:#f7f5ed}table{border-collapse:collapse;width:100%}td,th{text-align:left;padding:10px;border-bottom:1px solid #ccc}a{color:#25634e}</style><h1>73 de 75 registres: 97,3%</h1><p>116 fites; històries parcials. Cobertura d’almenys una fita, de naturalesa diversa: no són 73 fundacions verificades. Gi: consolidació del projecte, sense data d’autorització del codi. Heidi: participació cultural, fundació pendent. La Fada: text íntegre i codi confirmats. Dos codis sense fita: Col·legi Salesià 08065123 i Picasoques. El denominador continua sent els 75 codis del CSV; no tots actius.</p><p><a href="index.html">Mapa</a> · <a href="cronologia.html">Cronologia</a> · <a href="revisio_pendents_v11.csv">Revisió</a> · <a href="evidencies_sense_fita_v11.csv">Dos casos sense fita</a></p><table><tr><th>Centre</th><th>Fites</th><th>Recerca</th></tr>'+rows+'</table></html>')
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=13,fites_historiques=120,centres_amb_fites=73,centres_pendents=2,cobertura_percent=97.33,centres_amb_fites_text_integre_o_narrativa=73,centres_amb_fites_nomes_metadades=0,centres_nous_v13=0,fites_noves_v13=4,camps_origen_nous_v13=6,nota='75 codis de base; vigència parcial. La Fada confirmada pel text íntegre. Cobertura de qualsevol fita; Gi consolidació de projecte i Heidi activitat cultural, sense fundació o autorització completa.');(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
style='<style>body{max-width:1200px;margin:32px auto;padding:20px;font:16px system-ui;color:#223b39;background:#f5f1e8}h1{font:32px Georgia}table{border-collapse:collapse;width:100%;background:white}td,th{text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid #ccd5ce}small{display:block;line-height:1.5}a{color:#16665c}input,select{padding:10px;margin:8px 8px 16px 0;max-width:100%;font:inherit}.scroll{overflow:auto}</style>'
rows=''.join('<tr data-search="'+html.escape(x['centre'].lower()+' '+x['codi_centre'],quote=True)+'" data-cat="'+html.escape(x['categoria_origen'],quote=True)+'"><td><b>'+html.escape(x['centre'])+'</b><small>'+x['codi_centre']+'</small></td><td>'+str(x['fites_documentades'])+'</td><td>'+html.escape(x['categoria_origen'])+'<small>'+html.escape(x['origen_data_min']+' '+x['tipus_data_origen'])+'</small></td><td>'+html.escape(x['primera_fita_data']+' '+x['primera_fita_tipus'])+'</td><td>'+html.escape(x['tasca_prioritaria'])+'</td></tr>' for x in sorted(audit,key=lambda x:x['centre']))
opts='<option value="">Totes les categories</option>'+''.join('<option>'+html.escape(c)+'</option>' for c in sorted(stats))
script="""const q=document.querySelector('#q'),cat=document.querySelector('#cat'),rows=[...document.querySelectorAll('tbody tr')];function filter(){let n=0;for(const r of rows){const show=r.dataset.search.includes(q.value.toLowerCase().trim())&&(!cat.value||r.dataset.cat===cat.value);r.hidden=!show;if(show)n++;}document.querySelector('#n').textContent=n+' registres';}q.addEventListener('input',filter);cat.addEventListener('change',filter);filter();"""
(out/'auditoria-origens.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Mataró · Auditoria d’orígens V13</title>'+style+'<a href="index.html">← Mapa</a> · <a href="cronologia.html">Cronologia</a><h1>Què sabem dels orígens?</h1><p><b>73/75 codis amb alguna fita · 120 fites. 46/75 tenen una data al camp d’origen; 29 el tenen buit.</b> Les 46 dates inclouen fundacions declarades, antecedents, constitucions administratives i inicis de projectes: no són 46 primers dies de classe verificats. El 97,3% mesura qualsevol fita, no la cobertura de fundacions.</p><p>La primera fita conservada és només la més antiga de les documentades al conjunt actual. No s’utilitza automàticament com a fundació ni com a inici d’ocupació de la seu del mapa. Els 75 són codis de la base registral; no tots actius confirmats.</p><p><a href="auditoria_origens_v13.csv">Dades de l’auditoria</a> · <a href="pistes_origen_per_revisar_v13.csv">Pistes d’origen</a> · <a href="registre_recerca_v13.csv">Registre de recerca</a> · <a href="pla_recerca_pendent_v12.md">Consultes documentals preparades</a></p><label for="q">Centre o codi </label><input id="q" type="search"><label for="cat"> Categoria </label><select id="cat">'+opts+'</select><p id="n"></p><div class="scroll"><table><thead><tr><th>Centre</th><th>Fites</th><th>Camp d’origen</th><th>Primera fita documentada</th><th>Tasca pendent</th></tr></thead><tbody>'+rows+'</tbody></table></div><script>'+script+'</script></html>')

# Replace the coverage template text with the current six-origin research result.
s=(out/'cobertura.html').read_text();start=s.index('<p>');end=s.index('<table>');s=s[:start]+'<p>120 fites de 73 codis. Sis camps d’origen completats: Anxaneta, EOI del Maresme, Antonio Machado, Germanes Bertomeu, Torre Llauder i Thos i Codina. Ara hi ha 46 dates als camps d’origen i 29 camps buits; les dates són de naturalesa diversa, no fundacions totes verificades. Els 75 codis no són un cens de centres actius confirmats.</p><p><a href="index.html">Mapa</a> · <a href="cronologia.html">Cronologia</a> · <a href="auditoria-origens.html">Auditoria d’orígens</a> · <a href="revisio_sis_origens_v13.csv">Sis casos revisats</a></p>'+s[end:];s=s.replace('Cobertura V11','Cobertura V13');(out/'cobertura.html').write_text(s)
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=13,codis_amb_camp_origen_informat=46,codis_sense_camp_origen=29,categories_auditoria_origen=dict(stats),nota_v13='Quatre noves fites i sis camps d’origen completats amb tipus explícit. 73/75 és cobertura de qualsevol fita, no de fundacions.');(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V13.md').write_text("""# Mataró, ciutat d’escoles — V13, 18-11-2026
Paquet acumulatiu. Obre index.html per al mapa, cronologia.html per a les fites i auditoria-origens.html per als límits de la recerca. Sense publicació en línia.

120 fites de 73 dels 75 codis (97,3% amb qualsevol fita). Sis camps d’origen completats: passen de 40 a 46, amb 29 encara buits. No són 46 fundacions ni primeres classes verificades: es distingeixen fundació de projecte predecessor, creació, inauguració i transformació en institut.

Anxaneta: 04-10-1965 segons història del mateix centre, que també explica el pas a la xarxa pública el 1987. Es registra la fundació del projecte predecessor, sense afirmar que el codi públic actual existís el 1965. EOI: origen el 2002 i seu d’Onofre Arnau 32 des del «curs 2004», segons PEC aprovat el 2019. No s’inventa dia ni interval escolar complet a partir d’aquella expressió. Antonio Machado: creació el 2005 segons la definició institucional, diferenciada del trasllat de 2007.
Germanes Bertomeu: es completa el camp amb la inauguració de 15-09-1969 ja documentada, sense heretar dates de centres precedents. Torre Llauder: camp d’inauguració per curs 1978–1979 segons la fita existent; no es fixa un dia nou. Thos i Codina: transformació de primària en institut de FP el 1989; no data la fundació de l’escola predecessora.

Fitxers històrics vigents: esdeveniments_historics_v13.csv i fonts_historiques_v13.csv. Base canònica CSV/GeoJSON, auditoria_origens_v13.csv, pistes_origen_per_revisar_v13.csv i revisio_sis_origens_v13.csv actualitzats. Els fitxers anteriors són checkpoints i no s’han de sumar. La cronologia i les propietats del mapa estan sincronitzades. Les geometries i l’inventari de seus no s’amplien per inferència.

Continuen sense fita atribuïble Col·legi Salesià 08065123 i Picasoques 08078695. Les consultes documentals preparades a V12 es conserven sense enviar. Els 75 codis no equivalen a 75 centres actius confirmats. Les correccions de vigència i els 73 punts es mantenen.

Validació de recomptes, codis, fonts, intervals, propietats GeoJSON, dades del mapa, articles de cronologia, auditoria, sintaxi JavaScript, enllaços locals, integritat ZIP i SHA256. Sense comprovació visual en navegador ni contrast arxivístic exhaustiu.
""")
shutil.copy2(__file__,out/'amplia_mataro_v13.py')
assert len(audit)==75 and sum(x['fites_documentades'] for x in audit)==120 and len(counts)==73 and norigin==46
assert len({e['id_esdeveniment'] for e in E})==120
assert chron.count('<article data-year=')==120
assert all(e['id_font'] in fm and e['data_min']<=e['data_max'] for e in E)
for name in ['index.html','cronologia.html','cobertura.html','auditoria-origens.html']:
 text=(out/name).read_text()
 for link in re.findall(r'href="([^"#]+)"',text):
  if not link.startswith(('http:','https:',chr(39))):assert (out/link).exists(),link
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',text,re.S)):
  p=Path('/tmp')/('v13_'+name+str(i)+'.js');p.write_text(s);subprocess.run(['node','--check',str(p)],check=True,capture_output=True)
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(manifest,indent=2))
zp=B/'Mataro_ciutat_escoles_V13_sis_origens_2026-11-18.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v13/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(json.dumps(dict(zip=str(zp),fites=len(E),codis=len(counts),camps_origen=norigin,pendents=75-norigin)))
