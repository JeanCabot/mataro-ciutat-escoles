import csv,json,collections,re,hashlib,zipfile,html
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'upload/export(1).csv'
with SRC.open(encoding='utf-8-sig',newline='') as f:
    reader=csv.DictReader(f); fields=reader.fieldnames; rows=[r for r in reader if r['Codi municipi']=='08121']
latest=max(r['Curs'] for r in rows)
current=sorted([r for r in rows if r['Curs']==latest],key=lambda r:r['Denominació completa'].casefold())
def writecsv(name,records,keys):
    with (ROOT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(records)
def coord(s):return float(s.replace(',','.')) if s else None
writecsv('mataro_serie_2020_2026_original.csv',rows,fields)
normal=[];features=[]
for r in current:
    x,y=coord(r['Coordenades GEO X']),coord(r['Coordenades GEO Y'])
    valid=x is not None and y is not None and 2.3<x<2.6 and 41.4<y<41.7
    p={'codi_centre':r['Codi centre'],'nom':r['Denominació completa'],'curs':r['Curs'],'naturalesa':r['Nom naturalesa'],'titularitat':r['Nom titularitat'],'concert':'pendent de verificar' if r['Nom naturalesa']=='Privat' else 'no aplicable','adreca':r['Adreça'],'municipi':r['Nom municipi'],'longitud':x,'latitud':y,'web':r['URL'],'ensenyaments_codis':' | '.join(k for k in fields[29:-1] if r[k]),'font':'Directori de centres docents de la Generalitat; CSV aportat','data_processament':'2026-11-18','fundacio_any':'','fundacio_font':'','estat_recerca_historica':'pendent'}
    p['control_coordenades']='interval local plausible; pendent contrast' if valid else 'FORA DE L’ENTORN DE MATARÓ: revisar; exclòs del mapa'
    normal.append(p)
    if valid:features.append({'type':'Feature','geometry':{'type':'Point','coordinates':[x,y]},'properties':p})
assert len(normal)==len({r['codi_centre'] for r in normal})==75
writecsv('mataro_centres_2026_2027.csv',normal,list(normal[0]))
(ROOT/'mataro_centres_2026_2027.geojson').write_text(json.dumps({'type':'FeatureCollection','features':features},ensure_ascii=False,indent=2))
# Una observació de localització actual no determina quan va començar a ocupar-la.
seus=[{'id_seu_observada':'OBS-'+r['codi_centre']+'-2026','codi_centre':r['codi_centre'],'adreca':r['adreca'],'longitud':r['longitud'],'latitud':r['latitud'],'curs_observacio':latest,'inici_ocupacio':'','final_ocupacio':'','estat':'localització del registre; seus addicionals pendents','font':r['font']} for r in normal]
writecsv('mataro_seus_observades.csv',seus,list(seus[0]))
bycode=collections.defaultdict(list)
for r in rows:bycode[r['Codi centre']].append(r)
audit=[]
for code,rr in sorted(bycode.items()):
    rr=sorted(rr,key=lambda r:r['Curs']); reasons=[]
    if code not in {r['codi_centre'] for r in normal}:reasons.append('Codi absent al curs més recent: comprovar baixa, canvi de codi o reorganització; no implica tancament')
    if len({r['Denominació completa'] for r in rr})>1:reasons.append('Canvi de denominació al registre')
    if len({r['Adreça'] for r in rr})>1:reasons.append('Adreces diferents: comprovar trasllat o normalització')
    if len({r['Nom titularitat'] for r in rr})>1:reasons.append('Titularitats diferents: comprovar canvi real o denominació administrativa')
    if reasons:audit.append({'codi_centre':code,'nom_mes_recent':rr[-1]['Denominació completa'],'primer_curs_observat':rr[0]['Curs'],'darrer_curs_observat':rr[-1]['Curs'],'alertes':' | '.join(reasons),'noms_observats':' | '.join(dict.fromkeys(r['Denominació completa'] for r in rr)),'adreces_observades':' | '.join(dict.fromkeys(r['Adreça'] for r in rr))})
writecsv('mataro_auditoria_canvis.csv',audit,list(audit[0]))
# Extreure el text municipal sense atribuir-lo automàticament a codis.
txt=(ROOT.parent/'upload/Texto pegado(9).txt').read_text()
start=txt.find('Ensenyament públic infantil i primària')
(ROOT/'text_municipal_per_conciliar.txt').write_text(txt[start:] if start>=0 else txt)
writecsv('plantilla_esdeveniments_historics.csv',[],['id_esdeveniment','id_entitat','id_seu','tipus_esdeveniment','data_inici','data_final','precisio_data','afirmacio','font_url','pagina','cita_evidencia','estat_verificacio','notes'])
stats={'curs_actual':latest,'registres_mataro':len(rows),'codis_distints':len(bycode),'centres_actuals':len(normal),'naturalesa':dict(collections.Counter(r['naturalesa'] for r in normal)),'registres_per_curs':dict(sorted(collections.Counter(r['Curs'] for r in rows).items())),'punts_al_visor':len(features),'coordenades_a_revisar':[{'codi':r['codi_centre'],'nom':r['nom']} for r in normal if r['control_coordenades'].startswith('FORA')],'alertes_per_codi':len(audit),'codis_absents_al_darrer_curs':len(set(bycode)-{r['codi_centre'] for r in normal}),'font_csv_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest()}
(ROOT/'resum_auditoria.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2))
readme='''# Mataró, ciutat d’escoles — base inicial v1

Data de preparació: 18-11-2026. Cens contemporani per iniciar una cartografia històrica. No és encara un cens complet des de 1737.

## Contingut
- `index.html`: visor del curs 2026/2027, amb dades incorporades; obrir amb connexió a Internet per carregar Leaflet i el mapa base. No cal servidor. No està publicat al web.
- `mataro_centres_2026_2027.csv`: 75 codis actuals, 43 públics i 32 privats. Concert pendent de verificar.
- `mataro_centres_2026_2027.geojson`: punts amb coordenades dins de l’interval local de control, en longitud/latitud WGS84, EPSG:4326. Els punts fora d’aquest interval es conserven al CSV amb alerta i no es representen.
- `mataro_serie_2020_2026_original.csv`: 532 registres de Mataró, sense alterar els camps originals, distribuïts en set cursos (2020/2021–2026/2027), amb 81 codis diferents.
- `mataro_seus_observades.csv`: una localització registral actual per codi; no pressuposa que sigui l’única seu física.
- `mataro_auditoria_canvis.csv`: excepcions per revisar: denominacions, adreces, titularitats o absència al darrer curs.
- `text_municipal_per_conciliar.txt`: extracte aportat del directori municipal, encara sense vincular automàticament a codis.
- `plantilla_esdeveniments_historics.csv`: esquema buit per documentar fundacions, obertures de seus, trasllats i tancaments amb fonts.
- `prepara_base.py`: procés reproduïble; espera els dos originals a ../upload/.

## Criteris
El codi oficial identifica una unitat administrativa en el registre, no necessàriament una institució històrica immutable. No fusionar codis ni deduir tancaments sense evidència. Un centre pot tenir diverses seus i diversos ensenyaments. La concertació es verificarà per ensenyament i període. Cap any del CSV s’ha emprat com a any de fundació.

Les coordenades numèriques s’han obtingut de GEO X (longitud) i GEO Y (latitud), convertint les comes decimals. S’ha descartat per al visor el camp Georeferència, que en el fitxer aportat mostra decimals mal formats. S’ha comprovat l’interval geogràfic municipal aproximat, però encara no s’han contrastat totes les portes d’accés ni la precisió de cada punt.

El camp d’ensenyaments conserva els codis originals; consultar el diccionari oficial abans d’assignar etiquetes. Les dades inclouen centres d’altres ensenyaments, no només escoles i instituts.

## Pròxima fase
1. Conciliar el cens amb el directori municipal i revisar les seus múltiples (Germanes Bertomeu, Joan Coromines, Puig i Cadafalch i altres que es detectin).
2. Investigar els sis codis que no apareixen al curs 2026/2027, sense donar-los per tancats.
3. Verificar concerts per etapa, dates de fundació i primera ocupació de cada seu.
4. Incorporar centres desapareguts des de 1737 amb evidències d’arxiu, bibliografia i hemeroteca. Diferenciar antecedents anteriors a 1737.
5. Activar la línia temporal només amb intervals documentats; representar la incertesa i la cobertura desigual.

## Fonts
CSV i text municipal aportats per Joan; no s’han substituït per noves descàrregues.
Directori Generalitat: https://educacio.gencat.cat/ca/serveis-tramits/directoris-centres/
Conjunt de dades: https://analisi.transparenciacatalunya.cat/d/kvmv-ahh4
Directori municipal 3–16 anys: https://www.mataro.cat/ca/temes/educacio/e-obligatoria-3-16-anys/directori-de-centres
'''
(ROOT/'LLEGEIX_ME.md').write_text(readme)
page='''<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Mataró · Ciutat d’escoles</title><link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"><style>body{margin:0;font:16px system-ui;color:#223b39;background:#f5f1e8}header{padding:20px 24px;border-bottom:1px solid #c7d2c6}h1{font:32px Georgia;margin:3px 0 8px}small{display:block;max-width:1000px;line-height:1.5}nav{display:flex;gap:10px;flex-wrap:wrap;padding-top:14px}input,select{padding:9px;border:1px solid #adbfb7;border-radius:5px;background:white;font:inherit}#map{height:64vh;min-height:360px}#list{padding:14px 24px;display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px}article{background:white;padding:15px;border-radius:7px;border:1px solid #d4dbd1}article b{display:block}a{color:#16665c}#count{padding:12px 24px;margin:0}.tag{font-size:12px;text-transform:uppercase;letter-spacing:1px;color:#64736b}.leaflet-popup-content{line-height:1.6}</style><header><div class="tag">Base documental · versió 1</div><h1>Mataró, ciutat d’escoles</h1><small>Cens registral 2026–2027 · La reconstrucció històrica des de 1737 està pendent. Un punt representa una localització registral; pot haver-hi altres seus. Públic / privat indica naturalesa: la concertació encara s’ha de verificar.</small><nav><input id="q" type="search" placeholder="Cerca centre o adreça…" aria-label="Cerca centre"><select id="nat" aria-label="Naturalesa"><option value="">Públics i privats</option><option>Públic</option><option>Privat</option></select><a href="mataro_centres_2026_2027.csv">CSV</a><a href="mataro_centres_2026_2027.geojson">GeoJSON</a></nav></header><p id="count" role="status"></p><div id="map" aria-label="Mapa dels centres educatius"></div><section id="list" aria-label="Llista de centres"></section><script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script><script>const centres=__DATA__;const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));let map,layer;if(window.L){map=L.map('map').setView([41.544,2.444],14);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap contributors',maxZoom:19}).addTo(map);layer=L.featureGroup().addTo(map);}else{document.getElementById('map').textContent='No s’ha pogut carregar el mapa. La llista es pot consultar a continuació.'}function render(){const q=document.getElementById('q').value.toLocaleLowerCase('ca');const nat=document.getElementById('nat').value;const a=centres.filter(r=>(!nat||r.naturalesa===nat)&&(r.nom+' '+r.adreca).toLocaleLowerCase('ca').includes(q));document.getElementById('count').textContent=a.length+' centres · '+a.filter(r=>r.control_coordenades.startsWith('FORA')).length+' ubicacions pendents, excloses del mapa · verd: públic · taronja: privat';document.getElementById('list').innerHTML=a.map(r=>'<article><b>'+esc(r.nom)+'</b>'+esc(r.adreca)+'<br><small>'+esc(r.naturalesa)+' · '+esc(r.codi_centre)+'</small></article>').join('');if(layer){layer.clearLayers();a.filter(r=>!r.control_coordenades.startsWith('FORA')).forEach(r=>L.circleMarker([r.latitud,r.longitud],{radius:7,color:r.naturalesa==='Públic'?'#216c5a':'#ac592e',fillOpacity:.8,weight:2}).bindPopup('<b>'+esc(r.nom)+'</b><br>'+esc(r.adreca)+'<br>'+esc(r.naturalesa)+' · '+esc(r.codi_centre)+'<br>Fundació: pendent de documentar').addTo(layer));if(layer.getLayers().length)map.fitBounds(layer.getBounds(),{padding:[25,25],maxZoom:15});}}document.getElementById('q').addEventListener('input',render);document.getElementById('nat').addEventListener('change',render);render();</script></html>'''
(ROOT/'index.html').write_text(page.replace('__DATA__',json.dumps(normal,ensure_ascii=False).replace('</','<\\/')))
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.iterdir() if p.is_file() and p.name!='SHA256.json'}
(ROOT/'SHA256.json').write_text(json.dumps(manifest,indent=2))
zip_path=ROOT.parent/'Mataro_ciutat_escoles_BASE_V1_2026-11-18.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(ROOT.iterdir()):
        if p.is_file():z.write(p,ROOT.name+'/'+p.name)
with zipfile.ZipFile(zip_path) as z:assert z.testzip() is None
print(json.dumps(stats,ensure_ascii=False));print(zip_path)
