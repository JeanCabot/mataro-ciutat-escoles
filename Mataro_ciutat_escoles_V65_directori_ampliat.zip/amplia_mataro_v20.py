from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile,collections,subprocess
B=Path(__file__).parent;out=B/'mataro_escoles_v20';shutil.copytree(B/'mataro_escoles_v19',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,rows):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['codi_centre','centre','id_esdeveniment','tipus','data','id_font','afirmacio','decisio']);w.writeheader();w.writerows(rows)
a=read('mataro_centres_2026_2027.csv');am={r['codi_centre']:r for r in a};E=read('esdeveniments_historics_v19.csv');F=read('fonts_historiques_v19.csv');fm={r['id_font']:r for r in F}
def src(i,t,u,typ):
 r=dict(id_font=i,titol=t,url=u,consulta='2026-11-19',tipus=typ,abast='Fets i límits indicats en les fites i la revisió');F.append(r);fm[i]=r
src('H118','DOGC — Resolució EDU/1763/2009, de 12 de juny, proves d’accés 2009–2010','https://cido.diba.cat/legislacio/1200706/resolucio-edu17632009-de-12-de-juny-per-la-qual-es-fa-publica-la-relacio-de-centres-que-imparteixen-la-formacio-per-a-les-proves-dacces-als-cicles-formatius-durant-el-curs-de-2009-2010-i-sobre-la-convocatoria-del-proces-dautoritzacio-daquesta-formacio-per-a-centres-que-no-depenen-del-departament-deducacio-departament-deducacio','text íntegre DOGC consultat en PDF servit per CIDO/Diputació; còpia inclosa')
src('H119','Educació — Relació actualitzada de centres i programes PFI 2025–2026','https://documents.espai.educacio.gencat.cat/IPCNormativa/DisposicionsInternes/20260205_resolucio_llista_pfi_2025_2026.pdf','resolució i annex oficial consultats; publicitat d’oferta per curs')
def ev(c,k,d,f,claim,loc,notes,end=None):
 E.append(dict(id_esdeveniment='HIST-'+str(max(int(x['id_esdeveniment'].split('-')[1]) for x in E)+1).zfill(3),id_entitat='ENT-'+c,codi_actual_referencia=c,centre=am[c]['nom'],tipus=k,data_min=d,data_max=end or d,precisio='curs' if end else 'any' if len(d)==4 else 'dia',afirmacio=claim,id_font=f,font_url=fm[f]['url'],localitzador=loc,estat='documentat; contrast parcial',notes=notes))








ev('08065123','publicitat_normativa_formacio_acces','2009-06-12','H118','La Resolució EDU/1763/2009 inclou el Col·legi Salesià, codi 08065123, amb dos grups de formació per a proves d’accés a cicles de grau mitjà per al curs 2009–2010.','DOGC 5408, 26-06-2009, p. 51227, annex 3.a, Maresme–Vallès Oriental','Acte de publicitat de formació reconeguda, no autorització inicial d’obertura ni primer curs. La correcció publicada el 27-08-2009 s’ha consultat i no modifica l’entrada del Salesià. No s’hereta 1905 ni el codi 08021089 de la resolució de 2004.')
ev('08065123','oferta_pfi_documentada','2025','H119','La relació oficial PFI 2025–2026 inclou el Col·legi Salesià, codi 08065123, amb un grup de comerç i atenció al públic i un d’activitats esportives.','Annex 2, p. 33/66, municipi Mataró','Publicitat oficial de l’oferta d’aquest curs; no prova que els perfils comencessin aleshores ni que s’executessin totes les places. No és fundació del centre. Es data pel curs del document, sense convertir el nom del fitxer en data de signatura.',end='2026')
E.sort(key=lambda e:(e['data_min'],e['id_esdeveniment']));counts=collections.Counter(e['codi_actual_referencia'] for e in E)
assert len(E)==151 and len(counts)==75
write('esdeveniments_historics_v20.csv',E);write('fonts_historiques_v20.csv',F)
am['08065123']['estat_recerca_historica']='publicitat normativa de formació el 2009 i oferta PFI 2025–2026; origen i autorització inicial pendents'
for r in a:r['nombre_fites_documentades']=counts[r['codi_centre']]
write('mataro_centres_2026_2027.csv',a)
g=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in g['features']:f['properties']=am[f['properties']['codi_centre']]
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(g,ensure_ascii=False,indent=2))
write('registre_recerca_v20.csv',[dict(data_consulta='2026-11-19',via='DOGC/CIDO i Educació',consulta=f['titol'],resultat='Text consultat; codi 08065123 explícit. HIST-150–151.',limit='Publicitat de formació, no autorització inicial del centre.') for f in F if f['id_font'] in {'H118','H119'}])
(out/'pistes_documentals_v20.md').write_text("""# Salesià: fita documentada i origen pendent
EDU/1763/2009, de 12-06, DOGC 5408 de 26-06, annex 3.a, p. 51227, inclou explícitament 08065123, Col·legi Salesià de Mataró, dos grups per a proves d’accés a grau mitjà el curs 2009–2010. És una relació normativa d’oferta reconeguda; no creació ni primera autorització. La correcció d’errades del DOGC 5452 de 27-08-2009 afecta altres entrades; comprovada, sense canvi a l’entrada del Salesià.
Relació PFI 2025–2026: annex 2, p. 33/66, codi 08065123, av. Puig i Cadafalch 80, un grup CM02 i un AE01. Es documenta l’oferta, no l’inici d’aquests perfils. No es data la resolució només amb el nom del fitxer.
La resolució EDC/2410/2004 s’ha rellegit al Full 1019: l’annex continua indicant 08021089. No s’equiparen codis sense acte de canvi o conciliació registral. L’origen de 08065123 continua buit.
PDF de 2009 i correcció consultats i inclosos a evidencies_v20. Còpia de 2004 rellegida, però no afegida com a fita al codi actual.
La cobertura de 75/75 significa que cada codi de la base disposa d’almenys una fita de qualsevol naturalesa. No és un cens històric complet de totes les escoles de Mataró, ni 75 orígens, ni 75 centres actius confirmats. Es mantenen 17 camps d’origen buits.
""")
(out/'evidencies_v20').mkdir(exist_ok=True)
shutil.copy2('/tmp/salesia2009.pdf',out/'evidencies_v20/EDU_1763_2009.pdf')
shutil.copy2('/tmp/salesia2009cor.pdf',out/'evidencies_v20/EDU_1763_2009_correccio.pdf')
# Audit is rebuilt from the updated canonical data and events.
by=collections.defaultdict(list)
for e in E:by[e['codi_actual_referencia']].append(e)
audit=[]
for r in a:
 c=r['codi_centre'];es=sorted(by[c],key=lambda e:(e['data_min'],e['id_esdeveniment']));first=es[0] if es else {};typ=r['tipus_data_origen'];d=r['origen_data_min']
 if not d:cat='camp d’origen buit; recerca pendent'
 elif 'antecedent' in typ or 'patronat' in typ or 'predecessor' in typ:cat='antecedent; no obertura del centre actual'
 elif 'autorització' in typ:cat='autorització d’obertura; no primeres classes'
 elif 'administrativa' in typ or 'creació' in typ or 'transformació' in typ or typ=='creacio_escola':cat='constitució o creació; classes pendents de distingir'
 elif 'projecte' in typ:cat='inici de projecte; no autorització del codi'
 else:cat='data d’origen declarada; contrast segons font'
 specific={
 '08065123':'Conciliar codis 08065123 i 08021089 i trobar autorització pròpia. No heretar 1905 ni 2004.',
 '08078695':'Autorització i primer curs pendents. Corregir coordenada del CSV només amb portal 27 documentat.',
 '08073946':'Autorització i efectes legals confirmats; primer curs real i relació amb Pinotxo pendents.',
 '08078877':'2012 és consolidació del projecte segons la directora; alta del codi i autorització de cicles pendents.',
 '08056948':'2015 és actuació escolar; no és fundació ni autorització.',
 '08021181':'Conciliar 1968/1970: classes inicials, comunitat religiosa i actes d’inauguració.',
 }
 audit.append(dict(codi_centre=c,centre=r['nom'],fites_documentades=len(es),categoria_origen=cat,tipus_data_origen=typ,origen_data_min=d,origen_data_max=r['origen_data_max'],font_origen=r['fundacio_font'],primera_fita_id=first.get('id_esdeveniment',''),primera_fita_data=first.get('data_min',''),primera_fita_tipus=first.get('tipus',''),primera_fita_font=first.get('font_url',''),control='Primera fita cronològica no equival a fundació.',tasca_prioritaria=specific.get(c,'Precisar què data la font d’origen i contrastar-la.' if d else 'Cercar origen del centre; no adoptar la primera fita com a fundació.')))
write('auditoria_origens_v20.csv',audit);stats=collections.Counter(x['categoria_origen'] for x in audit);norigin=sum(bool(x['origen_data_min']) for x in audit);assert norigin==58
# Candidates are extracted from documented events but do not silently overwrite canonical origins.
missing=[e for e in E if not next(r for r in a if r['codi_centre']==e['codi_actual_referencia'])['origen_data_min'] and e['tipus'] in {'origen_declarat','inauguracio_escola','antecedent_aulari','consolidacio_projecte_escolar','autoritzacio_obertura'}]
write('pistes_origen_per_revisar_v20.csv',[dict(codi_centre=e['codi_actual_referencia'],centre=e['centre'],id_esdeveniment=e['id_esdeveniment'],tipus=e['tipus'],data=e['data_min'],id_font=e['id_font'],afirmacio=e['afirmacio'],decisio='Candidat de revisió; no afegit al camp canònic d’origen automàticament.') for e in missing])
chron=(out/'cronologia.html').read_text();opts='<option value="">Tots els centres documentats</option>'+''.join('<option value="'+c+'">'+html.escape(n)+'</option>' for c,n in sorted({(e['codi_actual_referencia'],e['centre']) for e in E},key=lambda x:x[1]));chron=re.sub(r'(<select id="centre">).*?(</select>)',lambda m:m[1]+opts+m[2],chron,count=1,flags=re.S)
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['data_min']+'–'+e['data_max'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(fm[e['id_font']]['titol'])+' · '+html.escape(e['localitzador'])+'</a></p></article>' for e in E)
chron=re.sub(r'<article.*?</article>(?:<article.*?</article>)*',lambda m:items,chron,count=1,flags=re.S).replace('149 fites documentades de 74 dels 75 registres de base (98,7%)','151 fites documentades de 75 dels 75 registres de base (100%)').replace('V19','V20');(out/'cronologia.html').write_text(chron)
idx=(out/'index.html').read_text().replace('versió 19','versió 20').replace('149 fites','151 fites').replace('71 centres amb alguna fita documentada','73 centres amb alguna fita documentada').replace('71/75 registres · 94,7%','73/75 registres · 97,3%');idx=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',idx,count=1,flags=re.S);idx=idx.replace('73 centres amb alguna fita documentada','74 centres amb alguna fita documentada').replace('73/75 registres · 97,3%','74/75 registres · 98,7%');idx=idx.replace('74 centres amb alguna fita documentada','75 centres amb alguna fita documentada').replace('74/75 registres · 98,7%','75/75 registres · 100%');(out/'index.html').write_text(idx)
style='<style>body{max-width:1200px;margin:32px auto;padding:20px;font:16px system-ui;color:#223b39;background:#f5f1e8}h1{font:32px Georgia}table{border-collapse:collapse;width:100%;background:white}td,th{text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid #ccd5ce}small{display:block;line-height:1.5}a{color:#16665c}input,select{padding:10px;margin:8px 8px 16px 0;max-width:100%;font:inherit}.scroll{overflow:auto}</style>'
rows=''.join('<tr data-search="'+html.escape(x['centre'].lower()+' '+x['codi_centre'],quote=True)+'" data-cat="'+html.escape(x['categoria_origen'],quote=True)+'"><td><b>'+html.escape(x['centre'])+'</b><small>'+x['codi_centre']+'</small></td><td>'+str(x['fites_documentades'])+'</td><td>'+html.escape(x['categoria_origen'])+'<small>'+html.escape(x['origen_data_min']+' '+x['tipus_data_origen'])+'</small></td><td>'+html.escape(x['primera_fita_data']+' '+x['primera_fita_tipus'])+'</td><td>'+html.escape(x['tasca_prioritaria'])+'</td></tr>' for x in sorted(audit,key=lambda x:x['centre']))
opts='<option value="">Totes les categories</option>'+''.join('<option>'+html.escape(c)+'</option>' for c in sorted(stats))
script="""const q=document.querySelector('#q'),cat=document.querySelector('#cat'),rows=[...document.querySelectorAll('tbody tr')];function filter(){let n=0;for(const r of rows){const show=r.dataset.search.includes(q.value.toLowerCase().trim())&&(!cat.value||r.dataset.cat===cat.value);r.hidden=!show;if(show)n++;}document.querySelector('#n').textContent=n+' registres';}q.addEventListener('input',filter);cat.addEventListener('change',filter);filter();"""
(out/'auditoria-origens.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Mataró · Auditoria d’orígens V20</title>'+style+'<a href="index.html">← Mapa</a> · <a href="cronologia.html">Cronologia</a><h1>Què sabem dels orígens?</h1><p><b>75/75 codis amb alguna fita · 151 fites. 58/75 tenen una data al camp d’origen; 17 el tenen buit.</b> Les 58 dates inclouen fundacions declarades, antecedents, constitucions administratives i inicis de projectes: no són 58 primers dies de classe verificats. El 100% mesura qualsevol fita, no la cobertura de fundacions.</p><p>La primera fita conservada és només la més antiga de les documentades al conjunt actual. No s’utilitza automàticament com a fundació ni com a inici d’ocupació de la seu del mapa. Els 75 són codis de la base registral; no tots actius confirmats.</p><p><a href="auditoria_origens_v20.csv">Dades de l’auditoria</a> · <a href="pistes_origen_per_revisar_v20.csv">Pistes d’origen</a> · <a href="registre_recerca_v20.csv">Registre de recerca</a> · <a href="pla_recerca_pendent_v12.md">Consultes documentals preparades</a></p><label for="q">Centre o codi </label><input id="q" type="search"><label for="cat"> Categoria </label><select id="cat">'+opts+'</select><p id="n"></p><div class="scroll"><table><thead><tr><th>Centre</th><th>Fites</th><th>Camp d’origen</th><th>Primera fita documentada</th><th>Tasca pendent</th></tr></thead><tbody>'+rows+'</tbody></table></div><script>'+script+'</script></html>')




(out/'cobertura.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><title>Cobertura V20</title>'+style+'<h1>75/75 codis amb alguna fita · 151 fites</h1><p>58 camps amb una data relacionada amb l’origen; 17 buits. Salesià: publicitat normativa de formació documentada; origen pendent. Tots els codis tenen alguna fita, de naturalesa diversa. No són 58 fundacions verificades. Els 75 codis no són tots actius confirmats.</p><p><a href="index.html">Mapa</a> · <a href="cronologia.html">Cronologia</a> · <a href="auditoria-origens.html">Auditoria</a></p><table><tr><th>Centre</th><th>Fites</th><th>Recerca</th></tr>'+''.join('<tr><td>'+html.escape(r['nom'])+'</td><td>'+str(counts[r['codi_centre']])+'</td><td>'+html.escape(r['estat_recerca_historica'])+'</td></tr>' for r in sorted(a,key=lambda r:r['nom']))+'</table>')
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=20,fites_historiques=151,fites_noves_v20=2,camps_origen_nous_v20=0,codis_amb_camp_origen_informat=58,codis_sense_camp_origen=17,categories_auditoria_origen=dict(stats),nota='75 de 75 codis amb qualsevol fita; no equival a cobertura de fundacions. 58 camps daten orígens de naturalesa diversa, inclosos predecessors.',nota_v20='Salesià: publicitat normativa de 2009 amb codi actual i oferta PFI 2025–2026; origen pendent. 100% només d’alguna fita.',centres_amb_fites=75,centres_pendents=0,cobertura_percent=100,centres_amb_fites_text_integre_o_narrativa=75,centres_amb_fites_nomes_metadades=0);(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V20.md').write_text("""# Mataró, ciutat d’escoles — V20, 19-11-2026
Paquet acumulatiu. Obre index.html. Sense publicació en línia.
151 fites de 75/75 codis (100% amb almenys una fita). La cobertura és de fites de naturalesa diversa dins dels codis de partida; no és història completa de totes les escoles ni 75 fundacions verificades ni 75 centres actius. Es mantenen 58 camps amb alguna data relacionada amb l’origen i 17 buits.
Dues fites noves del Col·legi Salesià, codi 08065123: publicitat normativa de dos grups de formació per a proves d’accés a grau mitjà, Resolució EDU/1763/2009 de 12-06, DOGC 5408, p. 51227; i oferta PFI 2025–2026 amb un grup de comerç i atenció al públic i un d’activitats esportives. Cap data és l’autorització inicial del centre. La resolució de 2004 indica l’altre codi, 08021089, i no s’hereta. La correcció de 2009 s’ha comprovat; no modifica l’entrada del Salesià. Vegeu pistes_documentals_v20.md i els PDF a evidencies_v20.
Fitxers vigents: base CSV/GeoJSON, esdeveniments_historics_v20.csv, fonts_historiques_v20.csv, auditoria_origens_v20.csv, pistes_origen_per_revisar_v20.csv, registre_recerca_v20.csv i resum_auditoria.json. Les versions anteriors són checkpoints; no sumar files. Els documents antics que deien «sense fita» són antecedents de recerca, superats per aquesta versió.
Pendents: 17 camps d’origen buits, precisió dels camps ja informats, conciliació registral del Salesià, seus històriques, coordenades de Picasoques i Figueretes, vigència de registres, llibre íntegre de bressols i revisió visual abans de publicació. Consultes documentals encara no enviades.
Mapa, cronologia, auditoria i cobertura sincronitzats. Cap geometria modificada: 73 punts de centres.
Validació automatitzada: codis, fonts, intervals, 151 articles, 75 files d’auditoria i cobertura, CSV/GeoJSON/visor, JavaScript, enllaços locals, SHA256 i ZIP. Sense inspecció visual en navegador.
""")
shutil.copy2(__file__,out/'amplia_mataro_v20.py')
assert len(a)==75 and len(audit)==75 and norigin==58 and len(E)==151
assert len({e['id_esdeveniment'] for e in E})==151
assert all(e['id_font'] in fm and e['data_min']<=e['data_max'] for e in E)
assert chron.count('<article data-year=')==151
assert '151 fites' in chron and '151 fites' in idx
assert (out/'cobertura.html').read_text().count('<tr>')==76
payload=re.search(r'const centres=(.*?);const esc=',idx,re.S).group(1)
assert json.loads(payload)==a
assert all(f['properties']==am[f['properties']['codi_centre']] for f in g['features'])
assert len([f for f in g['features'] if f['geometry']])==73
for name in ['index.html','cronologia.html','cobertura.html','auditoria-origens.html']:
 text=(out/name).read_text()
 for link in re.findall(r'href="([^"#]+)"',text):
  if not link.startswith(('http:','https:',chr(39))):assert (out/link).exists(),link
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',text,re.S)):
  path=Path('/tmp')/('v16_'+name+str(i)+'.js');path.write_text(s);subprocess.run(['node','--check',str(path)],check=True,capture_output=True)
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(manifest,indent=2))
zp=B/'Mataro_ciutat_escoles_V20_cobertura_75_codis_2026-11-19.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v20/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(json.dumps(dict(zip=str(zp),fites=len(E),camps_origen=norigin,pendents=75-norigin)))
