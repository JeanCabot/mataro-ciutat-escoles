# Pista bibliogràfica pendent de consulta íntegra
**Una escola avançada. L’escola bressol municipal de Mataró 1979–2007.** Edició de l’Institut Municipal d’Educació, documentada a Més Mataró 20, juliol/agost de 2007 (H102).
S’ha consultat la notícia municipal, no el llibre íntegre. La notícia explica que tracta els orígens de la xarxa i el Patronat de 1979. No s’atribueix a cadascuna de les escoles l’any de creació del Patronat.
Cal localitzar un exemplar o facsímil amb paginació per contrastar Cerdanyola, Rocafonda, Tabalet, La Llàntia i La Riereta. Autor, ISBN i localització d’exemplar pendents: no s’inventen.
Per als centres de persones adultes, Can Marfà i Can Noè continuen sense origen inicial resolt. La titularitat municipal de Can Noè des de 2001–2002 no es converteix en fundació.
