# Autoritzacions inicials: contrast V21
Peques 08062547: llegida íntegrament ENS/2170/2013 de 07-10, DOGC 6486 de 23-10. Amplia de 5 a 7 unitats i de 66 a 87 places. Apartat 2 i annex: efectes des de l’inici de 2013–2014. No és obertura inicial: l’acte modifica una autorització prèvia, que cal recuperar. Seqüència documentada: ampliació 2013; canvi de titular i nom a Acuarella Mataró el 2018. Relació amb Misha encara pendent.
Nemomarlin 08076790: l’adhesió a la xarxa el 2019–2020 i el cessament de 2026 són fets ja conservats. Les notícies de creixement de la franquícia poden descriure previsions i no fixen primer dia de classes. Obertura inicial pendent.
Picasoques 08078695: la web confirma identitat i adreça, però no data inicial. Sense nou acte atribuïble inequívocament. Les referències a grups infantils homònims d’altres centres s’exclouen.
Les cerques negatives no acrediten inexistència d’actes. Cal consultar expedients del Registre de centres i, si escau, llicències municipals. Consultes documentals preparades, sense enviar.
Els 17 camps d’origen buits es mantenen. El 100% continua referint-se només a almenys una fita per cadascun dels 75 codis de partida.
