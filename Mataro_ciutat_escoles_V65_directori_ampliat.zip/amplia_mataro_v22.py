from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile,collections,subprocess
B=Path(__file__).parent;out=B/'mataro_escoles_v22';shutil.copytree(B/'mataro_escoles_v21',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,rows):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['codi_centre','centre','id_esdeveniment','tipus','data','id_font','afirmacio','decisio']);w.writeheader();w.writerows(rows)
a=read('mataro_centres_2026_2027.csv');am={r['codi_centre']:r for r in a};E=read('esdeveniments_historics_v21.csv');F=read('fonts_historiques_v21.csv');fm={r['id_font']:r for r in F}
def src(i,t,u,typ):
 r=dict(id_font=i,titol=t,url=u,consulta='2026-11-19',tipus=typ,abast='Fets i límits indicats en les fites i la revisió');F.append(r);fm[i]=r
def ev(c,k,d,f,claim,loc,notes,end=None):
 E.append(dict(id_esdeveniment='HIST-'+str(max(int(x['id_esdeveniment'].split('-')[1]) for x in E)+1).zfill(3),id_entitat='ENT-'+c,codi_actual_referencia=c,centre=am[c]['nom'],tipus=k,data_min=d,data_max=end or d,precisio='curs' if end else 'any' if len(d)==4 else 'dia',afirmacio=claim,id_font=f,font_url=fm[f]['url'],localitzador=loc,estat='documentat; contrast parcial',notes=notes))










initial_missing={r['codi_centre'] for r in a if not r['origen_data_min']}
src('H121','MASMM — Sol Ixent, escola','https://masmm.org/arxiu/llocs/03366.html','Síntesi històrica local; text complet consultat')
src('H122','CFA Can Noè — Projecte educatiu de centre','https://cannoe.cat/wp-content/uploads/2024/06/1-Projecte-Educatiu-de-Centre-PEC-v-20230411-logo.pdf','PDF del centre consultat, preàmbul i apartat 1.1, pp. 3–4 del PDF')
src('H123','BOE — Decret 1252/1969, creació de seccions delegades','https://www.boe.es/boe/dias/1969/06/24/pdfs/A09937-09937.pdf','PDF oficial consultat; article 1, fila 5, i article 3')
src('H124','BOE — Decret 2165/1975, creació de 27 instituts','https://www.boe.es/boe/dias/1975/09/12/pdfs/A19376-19378.pdf','PDF oficial consultat; articles 1.19, 2 i 3')
src('H125','BOE — Ordre de 10 de maig de 1977, denominació Damiá Campeny','https://www.boe.es/boe/dias/1977/07/04/pdfs/A14988-14988.pdf','PDF oficial consultat; disposició 15179')
src('H126','Diario de Barcelona, 2 de febrer de 1972 — inauguració Peramas','https://ahcbdigital.bcn.cat/es/hemeroteca/visualizador/ahcb-d103703','Exemplar digitalitzat consultat; pàgina impresa 13, columna Mataró')
src('H127','BOE — Ordre de 24 de juliol de 1975, constitució ordinària José Montserrat','https://www.boe.es/boe/dias/1975/09/04/pdfs/A18783-18788.pdf','PDF oficial complet consultat; apartat província de Barcelona, Mataró, p. 18783')
src('H128','Salesians Mataró — D’on venim? Història del centre','https://mataro.salesians.cat/wp-content/uploads/2024/12/Historia-Salesians-Mataro.pdf','PDF del centre consultat; pp. 10–11, formació d’adults i unificació de serveis')
src('H129','Generalitat — Dansa, fullet 2007, directori de centres','https://repositori.educacio.gencat.cat/bitstream/handle/20.500.12694/4828/dansa_fullet_2007.pdf?isAllowed=y&sequence=8','PDF oficial consultat; p. 16 impresa, 8 del PDF, Dúnia 08056948')
ev('08035374','fundacio_declarada','1970','H121','La síntesi històrica del MASMM atribueix a 1970 la fundació de Sol-Ixent per la família Sancho i Caballé.','Fitxa 03366, primer paràgraf','Any explícit en la síntesi local; no és una autorització administrativa ni acredita el primer dia de classes.')
ev('08061658','inici_servei_declarat','1979','H122','El projecte educatiu de Can Noè declara que el centre ofereix servei a Mataró des de 1979.','Preàmbul i apartat 1.1, pp. 3–4 del PDF','No confondre amb la construcció de Can Noè de 1985–1987 ni amb la titularitat municipal des de 2001–2002. El document descriu la història institucional, no l’alta del codi registral.')
ev('08021302','creacio_seccio_delegada_predecessora','1969-06-12','H123','El Decret 1252/1969 crea la secció delegada mixta de Mataró, dependent de l’institut de Mataró, que ha de funcionar a l’edifici del COPEM extingit.','Article 1, fila 5, i article 3; BOE 150, 24-06-1969, p. 9937','Predecessor administratiu de l’institut creat el 1975; l’acte no incorpora el codi actual. La seqüència es reconstrueix amb els decrets de 1969 i 1975 i la denominació de 1977; no és la fundació de Satorras.')
ev('08021302','creacio_administrativa_institut','1975-07-24','H124','El Decret 2165/1975 crea un institut nacional de batxillerat mixt a Mataró i extingeix la secció delegada creada pel Decret 1252/1969; disposa l’inici d’activitats des del curs 1975–1976 als seus locals.','Articles 1.19, 2 i 3, BOE 219, pp. 19376–19378','Data de l’acte de creació; no primer dia de classe. Identificació històrica per la seqüència amb la denominació de l’institut mixt número 2 de 1977.')
ev('08021302','denominacio_institut','1977-05-10','H125','Una ordre ministerial concedeix a l’Institut Nacional de Batxillerat mixt número 2 de Mataró el nom Damiá Campeny.','Disposició 15179, BOE 158, 04-07-1977, p. 14988','Canvi de nom d’un centre ja existent; no data de creació ni construcció.')
ev('08020917','inauguracio_escola','1972','H126','El Diario de Barcelona del 2 de febrer de 1972 informa de la inauguració del grup escolar Peramas, al carrer José Montserrat, amb 17 aules i 800 places; afegeix que feia algunes setmanes que funcionava.','Pàgina impresa 13 / PDF 13, Actualidad en Cataluña, notícia de Mataró','Any de la inauguració, no inici de classes ni creació legal. No es dedueix un dia exacte del programa de commemoració; el primer curs 1971–1972 continua pendent d’acreditació directa.')
ev('08021041','constitucio_administrativa_regim_ordinari','1975-07-24','H127','Una ordre constitueix el col·legi nacional masculí José Montserrat en règim ordinari, transformant les 10 unitats i la direcció del centre homònim dependent del patronat de la Caixa d’Estalvis Laietana.','Província de Barcelona, Mataró; BOE 212, p. 18783','És una transformació de règim d’un centre anterior, no l’obertura inicial. Els indicis de 1962, 1963 i 1964 queden separats i pendents de conciliació.')
ev('08021181','fundacio_declarada_amb_discrepancia','1968','H69','La història publicada pel Col·legi Sant Josep declara que es va fundar el 1968.','Història del centre, paràgraf inicial sobre la fundació','Afirmació conservada com a font, sense adoptar data única al camp canònic: el Caràcter propi H70 declara 1970. H86 distingeix classes inicials i comunitat religiosa formal. Discrepància D06 oberta.')
ev('08021181','benediccio_collegi','1970-01-04','H69','La història del Col·legi Sant Josep data el 4 de gener de 1970 la benedicció del col·legi i la primera eucaristia.','Història, paràgraf sobre el moment clau de la història del centre','Acte religiós; no prova el primer dia de classe ni tanca la discrepància 1968/1970.')
ev('08065123','antecedent_cfa_declarat_continuitat_pendent','1992','H128','La història de l’obra salesiana atribueix a 1992 el naixement del seu Centre de Formació d’Adults.','P. 11, primer paràgraf','Antecedent candidat: cal documentar la continuïtat registral amb 08065123 i conciliar l’annex de 2004 amb codi 08021089. No es transfereix 1992 al camp canònic. La p. 10 esmenta cursos de formació d’adults des de 1991–1992, fet diferent.')
ev('08065123','unificacio_serveis_educatius','2005','H128','La història de l’obra salesiana data el 2005 la unificació del Centre Obert i del Centre de Formació d’Adults, fins llavors gestionat per l’escola.','P. 11, primer paràgraf','No prova una alta o un canvi de codi registral; s’atribueix al context institucional del codi, amb continuïtat jurídica pendent.')
ev('08056948','presencia_nom_historic_registre','2007','H129','El fullet oficial de Dansa de 2007 relaciona a Mataró l’Escola de Dansa Dúnia, codi 08056948, al carrer Concepció 11.','P. 16 impresa / 8 del PDF, columna Mataró','El mateix codi figura com a Escola de Dansa Heidi Consegal a la base actual. La identitat registral queda relacionada, però 2007 és presència al directori, no fundació ni data del canvi de nom.')
# Preserve the narrower meanings of origin fields; do not fill conflicted dates.
updates={
'08035374':('1970','1970','fundació declarada en síntesi històrica local; autorització pendent','H121'),
'08061658':('1979','1979','inici del servei declarat al PEC; alta del codi pendent','H122'),
'08021302':('1975-07-24','1975-07-24','creació administrativa de l’institut; secció prèvia de 1969','H124'),
'08020917':('1972','1972','inauguració del grup escolar; classes anteriors i creació pendents','H126'),
'08021041':('1975-07-24','1975-07-24','constitució administrativa en règim ordinari; centre anterior existent','H127')}
for c,(lo,hi,typ,f) in updates.items():
 r=am[c];r.update(origen_data_min=lo,origen_data_max=hi,tipus_data_origen=typ,fundacio_font=fm[f]['url'],estat_recerca_historica=typ+'; vegeu revisio_17_camps_v22.csv')
am['08056948']['nota_denominacio_documentada']='Dúnia figura al fullet oficial de 2007 amb el mateix codi 08056948 i adreça; data del canvi de nom pendent.'
E.sort(key=lambda e:(e['data_min'],e['id_esdeveniment']));counts=collections.Counter(e['codi_actual_referencia'] for e in E)
assert len(E)==165 and len(counts)==75
write('esdeveniments_historics_v22.csv',E);write('fonts_historiques_v22.csv',F)
for r in a:r['nombre_fites_documentades']=counts[r['codi_centre']]
write('mataro_centres_2026_2027.csv',a)
g=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in g['features']:f['properties']=am[f['properties']['codi_centre']]
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(g,ensure_ascii=False,indent=2))
(out/'evidencies_v22').mkdir(exist_ok=True)
for p,n in [('/tmp/cannoe_pec.pdf','CanNoe_PEC.pdf'),('/tmp/campeny1969.pdf','Campeny_seccio_1969.pdf'),('/tmp/boe_1975-19180.pdf','Campeny_creacio_1975.pdf'),('/tmp/boe_1977-15179.pdf','Campeny_nom_1977.pdf'),('/tmp/montserrat1975_complet.pdf','JosepMontserrat_regim_ordinari_1975.pdf'),('/tmp/salesianshistoria.pdf','Salesians_historia.pdf'),('/tmp/dunia2007.pdf','Dansa_directori_2007.pdf')]:shutil.copy2(p,out/'evidencies_v22'/n)
# Contemporary newspaper is public domain according to AHCB metadata. Retain only the cited page.
subprocess.run(['pdftoppm','-f','13','-singlefile','-scale-to','2200','-png','/tmp/peramas_premsa.pdf',str(out/'evidencies_v22/Peramas_DiarioBarcelona_1972_p13')],check=True,capture_output=True)
# Audit is rebuilt from the updated canonical data and events.
by=collections.defaultdict(list)
for e in E:by[e['codi_actual_referencia']].append(e)
audit=[]
for r in a:
 c=r['codi_centre'];es=sorted(by[c],key=lambda e:(e['data_min'],e['id_esdeveniment']));first=es[0] if es else {};typ=r['tipus_data_origen'];d=r['origen_data_min']
 if not d:cat='camp d’origen buit; recerca pendent'
 elif 'antecedent' in typ or 'patronat' in typ or 'predecessor' in typ:cat='antecedent; no obertura del centre actual'
 elif 'autorització' in typ:cat='autorització d’obertura; no primeres classes'
 elif 'administrativa' in typ or 'creació' in typ or 'transformació' in typ or typ=='creacio_escola':cat='constitució o creació; classes pendents de distingir'
 elif 'projecte' in typ:cat='inici de projecte; no autorització del codi'
 else:cat='data d’origen declarada; contrast segons font'
 specific={
 '08065123':'Conciliar codis 08065123 i 08021089 i trobar autorització pròpia. No heretar 1905 ni 2004.',
 '08078695':'Autorització i primer curs pendents. Corregir coordenada del CSV només amb portal 27 documentat.',
 '08073946':'Autorització i efectes legals confirmats; primer curs real i relació amb Pinotxo pendents.',
 '08078877':'2012 és consolidació del projecte segons la directora; alta del codi i autorització de cicles pendents.',
 '08056948':'2015 és actuació escolar; no és fundació ni autorització.',
 '08021181':'Conciliar 1968/1970: classes inicials, comunitat religiosa i actes d’inauguració.',
 }
 audit.append(dict(codi_centre=c,centre=r['nom'],fites_documentades=len(es),categoria_origen=cat,tipus_data_origen=typ,origen_data_min=d,origen_data_max=r['origen_data_max'],font_origen=r['fundacio_font'],primera_fita_id=first.get('id_esdeveniment',''),primera_fita_data=first.get('data_min',''),primera_fita_tipus=first.get('tipus',''),primera_fita_font=first.get('font_url',''),control='Primera fita cronològica no equival a fundació.',tasca_prioritaria=specific.get(c,'Precisar què data la font d’origen i contrastar-la.' if d else 'Cercar origen del centre; no adoptar la primera fita com a fundació.')))
write('auditoria_origens_v22.csv',audit);stats=collections.Counter(x['categoria_origen'] for x in audit);norigin=sum(bool(x['origen_data_min']) for x in audit);assert norigin==63
# Candidates are extracted from documented events but do not silently overwrite canonical origins.
missing=[e for e in E if not next(r for r in a if r['codi_centre']==e['codi_actual_referencia'])['origen_data_min'] and e['tipus'] in {'origen_declarat','inauguracio_escola','antecedent_aulari','consolidacio_projecte_escolar','autoritzacio_obertura'}]
write('pistes_origen_per_revisar_v22.csv',[dict(codi_centre=e['codi_actual_referencia'],centre=e['centre'],id_esdeveniment=e['id_esdeveniment'],tipus=e['tipus'],data=e['data_min'],id_font=e['id_font'],afirmacio=e['afirmacio'],decisio='Candidat de revisió; no afegit al camp canònic d’origen automàticament.') for e in missing])
chron=(out/'cronologia.html').read_text();opts='<option value="">Tots els centres documentats</option>'+''.join('<option value="'+c+'">'+html.escape(n)+'</option>' for c,n in sorted({(e['codi_actual_referencia'],e['centre']) for e in E},key=lambda x:x[1]));chron=re.sub(r'(<select id="centre">).*?(</select>)',lambda m:m[1]+opts+m[2],chron,count=1,flags=re.S)
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['data_min']+'–'+e['data_max'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(fm[e['id_font']]['titol'])+' · '+html.escape(e['localitzador'])+'</a></p></article>' for e in E)
chron=re.sub(r'<article.*?</article>(?:<article.*?</article>)*',lambda m:items,chron,count=1,flags=re.S).replace('151 fites documentades de 75 dels 75 registres de base (100%)','165 fites documentades de 75 dels 75 registres de base (100%)').replace('V21','V22').replace('153 fites','165 fites');(out/'cronologia.html').write_text(chron)
idx=(out/'index.html').read_text().replace('versió 21','versió 22').replace('153 fites','165 fites').replace('71 centres amb alguna fita documentada','73 centres amb alguna fita documentada').replace('71/75 registres · 94,7%','73/75 registres · 97,3%');idx=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',idx,count=1,flags=re.S);idx=idx.replace('73 centres amb alguna fita documentada','74 centres amb alguna fita documentada').replace('73/75 registres · 97,3%','74/75 registres · 98,7%');idx=idx.replace('74 centres amb alguna fita documentada','75 centres amb alguna fita documentada').replace('74/75 registres · 98,7%','75/75 registres · 100%');(out/'index.html').write_text(idx)
style='<style>body{max-width:1200px;margin:32px auto;padding:20px;font:16px system-ui;color:#223b39;background:#f5f1e8}h1{font:32px Georgia}table{border-collapse:collapse;width:100%;background:white}td,th{text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid #ccd5ce}small{display:block;line-height:1.5}a{color:#16665c}input,select{padding:10px;margin:8px 8px 16px 0;max-width:100%;font:inherit}.scroll{overflow:auto}</style>'
rows=''.join('<tr data-search="'+html.escape(x['centre'].lower()+' '+x['codi_centre'],quote=True)+'" data-cat="'+html.escape(x['categoria_origen'],quote=True)+'"><td><b>'+html.escape(x['centre'])+'</b><small>'+x['codi_centre']+'</small></td><td>'+str(x['fites_documentades'])+'</td><td>'+html.escape(x['categoria_origen'])+'<small>'+html.escape(x['origen_data_min']+' '+x['tipus_data_origen'])+'</small></td><td>'+html.escape(x['primera_fita_data']+' '+x['primera_fita_tipus'])+'</td><td>'+html.escape(x['tasca_prioritaria'])+'</td></tr>' for x in sorted(audit,key=lambda x:x['centre']))
opts='<option value="">Totes les categories</option>'+''.join('<option>'+html.escape(c)+'</option>' for c in sorted(stats))
script="""const q=document.querySelector('#q'),cat=document.querySelector('#cat'),rows=[...document.querySelectorAll('tbody tr')];function filter(){let n=0;for(const r of rows){const show=r.dataset.search.includes(q.value.toLowerCase().trim())&&(!cat.value||r.dataset.cat===cat.value);r.hidden=!show;if(show)n++;}document.querySelector('#n').textContent=n+' registres';}q.addEventListener('input',filter);cat.addEventListener('change',filter);filter();"""
(out/'auditoria-origens.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Mataró · Auditoria d’orígens V22</title>'+style+'<a href="index.html">← Mapa</a> · <a href="cronologia.html">Cronologia</a><h1>Què sabem dels orígens?</h1><p><b>75/75 codis amb alguna fita · 165 fites. 63/75 tenen una data al camp d’origen; 12 el tenen buit.</b> Les 63 dates inclouen fundacions declarades, antecedents, constitucions administratives i inicis de projectes: no són 63 primers dies de classe verificats. El 100% mesura qualsevol fita, no la cobertura de fundacions.</p><p>La primera fita conservada és només la més antiga de les documentades al conjunt actual. No s’utilitza automàticament com a fundació ni com a inici d’ocupació de la seu del mapa. Els 75 són codis de la base registral; no tots actius confirmats.</p><p><a href="auditoria_origens_v22.csv">Dades de l’auditoria</a> · <a href="pistes_origen_per_revisar_v22.csv">Pistes d’origen</a> · <a href="registre_recerca_v22.csv">Registre de recerca</a> · <a href="pla_recerca_pendent_v12.md">Consultes documentals preparades</a></p><label for="q">Centre o codi </label><input id="q" type="search"><label for="cat"> Categoria </label><select id="cat">'+opts+'</select><p id="n"></p><div class="scroll"><table><thead><tr><th>Centre</th><th>Fites</th><th>Camp d’origen</th><th>Primera fita documentada</th><th>Tasca pendent</th></tr></thead><tbody>'+rows+'</tbody></table></div><script>'+script+'</script></html>')




(out/'cobertura.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><title>Cobertura V22</title>'+style+'<h1>75/75 codis amb alguna fita · 165 fites</h1><p>63 camps amb una data relacionada amb l’origen; 12 buits. Peques: ampliació de 2013 documentada, autorització inicial pendent. Tots els codis tenen alguna fita, de naturalesa diversa. No són 63 fundacions verificades. Els 75 codis no són tots actius confirmats.</p><p><a href="index.html">Mapa</a> · <a href="cronologia.html">Cronologia</a> · <a href="auditoria-origens.html">Auditoria</a></p><table><tr><th>Centre</th><th>Fites</th><th>Recerca</th></tr>'+''.join('<tr><td>'+html.escape(r['nom'])+'</td><td>'+str(counts[r['codi_centre']])+'</td><td>'+html.escape(r['estat_recerca_historica'])+'</td></tr>' for r in sorted(a,key=lambda r:r['nom']))+'</table>')


# Every previously blank record has an explicit decision and a document request.
cases={
'08061658':('informat: inici declarat','1979','PEC propi, pp. 3–4: servei des de 1979.','1979 data el servei històric, no l’alta del codi; 2001–02 data titularitat.','Expedient de creació i primera matrícula, si es vol verificar primer curs i continuïtat registral.','CFA Can Noè / arxiu municipal','H122'),
'08065123':('pendent: continuïtat de codis','1991–1992 / 1992 / 2005','Història pròpia, pp. 10–11: cursos, CFA i unificació; directori de 2007 amb 08065123 localitzat.','1992 és origen declarat d’un CFA de l’obra; no s’ha provat la continuïtat amb el codi actual.','Expedient d’alta 08065123 i relació amb 08021089; actes de 1992 i unificació 2005.','Registre de centres / arxiu Salesians','H128; H118'),
'08062547':('pendent: autorització inicial','','ENS/2170/2013 amplia i ENS/2711/2018 canvia titular i nom.','Cap acte inicial localitzat; cap data deduïda del número de codi.','Resolució d’autorització prèvia a ENS/2170/2013 i primera matrícula; noms Peques i Acuarella Mataró.','Registre de centres / arxiu municipal d’activitats','H120; H84'),
'08078695':('pendent: autorització inicial','','Web pròpia identifica codi i Ronda República 27; cerques per Picasoques, Pica-soques i Pica Soques.','No heretar dates de revistes homònimes de Castellbisbal ni del projecte web de 2013.','Expedient d’autorització 08078695, llicència d’activitat a República 27 i primer curs.','Registre de centres / arxiu municipal d’activitats','H117'),
'08020905':('pendent: origen de primària','','Història pròpia i acord de canvi de nom de 2001 localitzats.','1892 és edifici; 1934 i 1958 són ensenyament secundari. No es daten orígens de primària amb aquests fets.','Expedient de creació de les Escuelas Nacionales Femeninas Nuestra Señora del Pilar a plaça de Cuba; continuïtat amb 08020905.','Arxiu municipal / Registre de centres','https://agora.xtec.cat/esc-angeletaferrer/lescola/historia/'),
'08046402':('pendent: discrepància d’origen','1979 / aniversari de 1989','MASMM atribueix creació a 1979; un arxiu geganter registra un vuitè aniversari el 1989.','No convertir la resta 1989−8 en any fundacional; cal distingir municipalització i obertura.','Actes de creació, municipalització i primer curs de Cerdanyola; consultar Una escola avançada (2007).','Arxiu municipal / Servei d’Educació','H98; H99; H102'),
'08056948':('pendent: origen sota nom Dúnia','','Fullet oficial de Dansa 2007: Dúnia 08056948, Concepció 11; coincideix amb el codi actual Heidi Consegal.','2007 és presència al directori, no obertura; es descarta 2001 del directori que la qualifica erròniament de primària.','Autorització original de Dúnia i expedient del canvi de denominació a Heidi Consegal; primer curs.','Registre de centres / arxiu del centre','H129'),
'08020917':('informat parcial: inauguració','1972','Premsa contemporània de 02-02-1972: inauguració i funcionament des de setmanes abans.','No data el primer dia de classe ni la creació legal; no es deriva 1971 d’un aniversari.','Ordre de creació i primer llibre de matrícula del grup Peramas.','Arxiu municipal / arxiu del centre','H126'),
'08021041':('informat parcial: constitució administrativa','1975-07-24','Ordre de 24-07-1975: transformació del patronat de Caixa Laietana a règim ordinari.','No data l’obertura del centre anterior; 1962, 1963 i 1964 continuen requerint conciliació.','Expedient del patronat i notícia Escuela Josep Montserrat en Peramas, Diari de Mataró, 21-09-1962, p. 1.','Arxiu municipal / fons de Caixa Laietana','H127; H106'),
'08021302':('informat: creació administrativa','1975-07-24','Decret de 1969: secció; Decret 2165/1975: institut; Ordre de 1977: nom Damiá Campeny.','No heretar la data del COPEM ni la construcció de 1966; primer dia de classe pendent.','Primera matrícula de l’institut 1975–1976, si es vol precisar l’inici efectiu.','Arxiu de l’institut / Registre de centres','H123; H124; H125'),
'08046414':('pendent: obertura anterior al trasllat','','Fent camí documenta trasllat el 1995–1996; gegants daten nous locals el 27-01-1996.','1996 no és fundació; no heretar 1978 de l’escola de primària homònima.','Creació i primer curs al carrer Boixa; consultar Una escola avançada (2007).','Arxiu municipal / Servei d’Educació','H100; H99; H102'),
'08057515':('pendent: obertura i conveni','','La Iaia es crea el 1996–1997 quan feia poc que s’havia inaugurat l’escola; conveni de 15-10-1997.','No equivaler la geganta ni el conveni al primer dia de classe.','Acta d’obertura, primer curs i conveni de creació de 15-10-1997; consultar Una escola avançada (2007).','Arxiu municipal / Servei d’Educació','H101; H50; H102'),
'08046426':('pendent: obertura institucional','','Edifici educatiu 1985–1987 i conveni de 16-10-1992 documentats.','Construcció i conveni no són origen; la memòria d’una inauguració un Primer de Maig no n’indica l’any.','Acta d’inauguració i primer curs de la bressol; continuïtat amb guarderies veïnals si existeix.','Arxiu municipal / Servei d’Educació','H112; H50; H102'),
'08046451':('pendent: centres anteriors','','Trasllat dels dos Tabalet al nou edifici el 8 i 9 de gener de 2004 documentat; conveni de 1992.','2004 és trasllat i ampliació; no s’adopta com a fundació dels dos centres anteriors.','Creació dels Tabalet I i II, primers cursos i unificació; consultar Una escola avançada (2007).','Arxiu municipal / Servei d’Educació','H113; H50; H102'),
'08076790':('pendent: obertura inicial','','Xarxa Nemomarlin: incorporació el 2019–2020; cessament efectiu final 2025–2026.','No prendre una previsió d’apertura 2018–2019 ni l’adhesió a la franquícia com a obertura real.','Autorització original 08076790, titulars i noms anteriors, primera matrícula al carrer Vallespir 2.','Registre de centres / arxiu municipal d’activitats','H59; H60'),
'08021181':('pendent: discrepància 1968/1970','1968 / 1970','Història pròpia declara 1968; Caràcter propi 1970; URC separa classes i comunitat de 1970; benedicció 04-01-1970.','No es construeix un interval 1968–1970 com si fos una incertesa sobre un mateix fet; són afirmacions i esdeveniments a separar.','Acta fundacional, primera matrícula i autorització; aclariment explícit dels anys 1968 i 1970.','Arxiu del centre / congregació / Registre de centres','H69; H70; H86'),
'08035374':('informat: fundació declarada','1970','MASMM declara fundació per la família Sancho i Caballé el 1970.','No és data d’autorització; no confondre amb ampliació BUP de 1980 ni societat mercantil de 2002.','Autorització inicial i primera matrícula, si es vol passar de fundació declarada a primer curs verificat.','Arxiu del centre / Registre de centres','H121')}
assert set(cases)==initial_missing and len(cases)==17
review=[]
for c,v in cases.items():
 status,candidate,evidence,limit,doc,holder,refs=v
 review.append(dict(codi_centre=c,centre=am[c]['nom'],estat_revisio=status,data_canonica=am[c]['origen_data_min'],tipus_data_canonica=am[c]['tipus_data_origen'],dates_candidates_no_equivalents=candidate,evidencia=evidence,limit=limit,document_necessari=doc,organisme_o_fons=holder,fonts=refs,data_consulta='2026-11-19'))
write('revisio_17_camps_v22.csv',review)
write('registre_recerca_v22.csv',review)
write('consultes_documentals_v22.csv',[dict(codi_centre=x['codi_centre'],centre=x['centre'],destinacio_documental=x['organisme_o_fons'],document=x['document_necessari'],text_consulta='En el marc de la cartografia històrica dels centres educatius de Mataró, sol·licito la referència i, si és possible, còpia de: '+x['document_necessari']+' Centre: '+x['centre']+', codi '+x['codi_centre']+'. Cal distingir la creació administrativa, l’inici de classes, els canvis de nom i els trasllats. Si no es conserva al vostre fons, agrairia la indicació del fons o organisme competent.',estat='ESBORRANY NO ENVIAT') for x in review if not x['data_canonica']])
report='# Revisió dels 17 camps d’origen — V22\n\nResultat: 17 casos revisats; 5 camps informats amb dates qualificades i 12 encara buits. No s’han completat els 17 orígens. Les dates administratives i les inauguracions no equivalen a obertures inicials.\n\n'
for x in review:
 report+='## '+x['centre']+' · '+x['codi_centre']+'\n'+x['estat_revisio']+'. Camp canònic: '+(x['data_canonica'] or 'buit')+'.\n\n'+x['evidencia']+' '+x['limit']+'\n\nDocument necessari: '+x['document_necessari']+' Fons: '+x['organisme_o_fons']+'. Fonts: '+x['fonts']+'.\n\n'
report+='Les cerques web i CIDO són consultes de descoberta, no una revisió exhaustiva dels registres. No localitzar un acte no prova que no existeixi. Els esborranys no s’han enviat. El llibre Una escola avançada (IME, 2007) està documentat per una notícia municipal, però no se n’ha pogut consultar el text complet. El paquet conserva les discrepàncies D06 i D15.\n'
(out/'revisio_17_camps_v22.md').write_text(report)
(out/'consultes_documentals_v22.md').write_text('# Consultes documentals preparades, no enviades\n\n'+''.join('## '+x['centre']+' · '+x['codi_centre']+'\nFons o organisme: '+x['organisme_o_fons']+'\n\n'+x['document_necessari']+'\n\n' for x in review if not x['data_canonica']))
(out/'pistes_documentals_v22.md').write_text(report)
# Add direct navigation to the decision dossier without changing the visual design.
for name in ['index.html','auditoria-origens.html','cobertura.html']:
 t=(out/name).read_text();t=t.replace('</body>','<p><a href="revisio_17_camps_v22.md">Revisió dels 17 camps i documents pendents</a></p></body>') if '</body>' in t else t.replace('</html>','<p><a href="revisio_17_camps_v22.md">Revisió dels 17 camps i documents pendents</a></p></html>');(out/name).write_text(t)
idx=(out/'index.html').read_text()
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=22,fites_historiques=165,fites_noves_v22=12,camps_origen_nous_v22=5,codis_amb_camp_origen_informat=63,codis_sense_camp_origen=12,categories_auditoria_origen=dict(stats),casos_revisats_v22=17,objectiu_17_camps_completat=False,nota='75 codis amb alguna fita; 63 camps amb dates de naturalesa diversa, no 63 fundacions verificades.',nota_v22='Cinc camps informats: dos inicis declarats, dues constitucions administratives i una inauguració. Dotze orígens continuen pendents; consultes documentals no enviades.');(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V22.md').write_text('# Mataró, ciutat d’escoles — V22, 19-11-2026\nPaquet acumulatiu. Obre index.html. No publicat en línia.\n165 fites de 75/75 codis. 63 camps tenen una data relacionada amb l’origen; 12 continuen buits. Objectiu dels 17 camps NO completat. S’han revisat els 17 i se n’han informat 5 amb qualificació explícita.\nNous camps: Sol-Ixent 1970 (fundació declarada per MASMM), Can Noè 1979 (inici del servei declarat al PEC), Damià Campeny 24-07-1975 (creació administrativa, amb secció prèvia de 1969), Peramàs 1972 (inauguració; ja funcionava setmanes abans), Josep Montserrat 24-07-1975 (constitució en règim ordinari d’un centre anterior). No són cinc obertures inicials verificades. El camp fundacio_any no s’omple amb dates administratives ni inauguracions.\n12 pendents: Salesià, Peques, Picasoques, Angeleta Ferrer, bressol Cerdanyola, Heidi Consegal/Dúnia, bressol La Llàntia, La Riereta, Rocafonda, Tabalet, Nemomarlin Maresme i Sant Josep.\nFitxers vigents: mataro_centres_2026_2027.csv i .geojson, esdeveniments_historics_v22.csv, fonts_historiques_v22.csv, auditoria_origens_v22.csv, revisio_17_camps_v22.csv i .md, registre_recerca_v22.csv, consultes_documentals_v22.csv i .md i resum_auditoria.json. Fitxers anteriors són checkpoints; no sumar files.\nEl dossier detalla per a cada cas evidència, límit, decisió i document necessari. Les consultes són esborranys NO enviats. Sant Josep conserva 1968/1970 com a discrepància oberta; Cerdanyola conserva 1979 i el testimoni d’un aniversari sense deduir un any. Salesià 1992 és candidat de continuïtat; 2007 a Dúnia només documenta nom i codi, no origen.\nEvidències oficials en PDF a evidencies_v22; imatge de la pàgina 13 del Diario de Barcelona de 02-02-1972 (domini públic segons les metadades AHCB). MASMM i història de Sant Josep tenen URL de font. No s’ha consultat el llibre Una escola avançada (2007), només la notícia de la seva edició.\nCSV, GeoJSON, mapa, cronologia, auditoria i cobertura sincronitzats. 73 punts de mapa; coordenades i estil conservats. Les dates no impliquen ocupació de la seu actual en aquell any. Els 75 són codis de partida i no un cens històric complet ni tots actius confirmats.\nValidació automatitzada de 75 codis, 165 fites, fonts, intervals, 17 decisions, 12 esborranys, coherència CSV/GeoJSON/JSON del mapa, JavaScript, enllaços locals, SHA256 i ZIP. Sense inspecció visual de navegador.\n')
assert len(review)==17 and sum(bool(x['data_canonica']) for x in review)==5
assert sum(not x['data_canonica'] for x in review)==12

shutil.copy2(__file__,out/'amplia_mataro_v22.py')
assert len(a)==75 and len(audit)==75 and norigin==63 and len(E)==165
assert len({e['id_esdeveniment'] for e in E})==165
assert all(e['id_font'] in fm and e['data_min']<=e['data_max'] for e in E)
assert chron.count('<article data-year=')==165
assert '165 fites' in chron and '165 fites' in idx
assert (out/'cobertura.html').read_text().count('<tr>')==76
payload=re.search(r'const centres=(.*?);const esc=',idx,re.S).group(1)
assert json.loads(payload)==a
assert all(f['properties']==am[f['properties']['codi_centre']] for f in g['features'])
assert len([f for f in g['features'] if f['geometry']])==73
for name in ['index.html','cronologia.html','cobertura.html','auditoria-origens.html']:
 text=(out/name).read_text()
 for link in re.findall(r'href="([^"#]+)"',text):
  if not link.startswith(('http:','https:',chr(39))):assert (out/link).exists(),link
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',text,re.S)):
  path=Path('/tmp')/('v16_'+name+str(i)+'.js');path.write_text(s);subprocess.run(['node','--check',str(path)],check=True,capture_output=True)
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(manifest,indent=2))
zp=B/'Mataro_ciutat_escoles_V22_revisio_17_camps_2026-11-19.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v22/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(json.dumps(dict(zip=str(zp),fites=len(E),camps_origen=norigin,pendents=75-norigin)))
