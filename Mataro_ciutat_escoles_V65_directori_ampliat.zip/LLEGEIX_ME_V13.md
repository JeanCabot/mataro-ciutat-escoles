# Mataró, ciutat d’escoles — V13, 18-11-2026
Paquet acumulatiu. Obre index.html per al mapa, cronologia.html per a les fites i auditoria-origens.html per als límits de la recerca. Sense publicació en línia.

120 fites de 73 dels 75 codis (97,3% amb qualsevol fita). Sis camps d’origen completats: passen de 40 a 46, amb 29 encara buits. No són 46 fundacions ni primeres classes verificades: es distingeixen fundació de projecte predecessor, creació, inauguració i transformació en institut.

Anxaneta: 04-10-1965 segons història del mateix centre, que també explica el pas a la xarxa pública el 1987. Es registra la fundació del projecte predecessor, sense afirmar que el codi públic actual existís el 1965. EOI: origen el 2002 i seu d’Onofre Arnau 32 des del «curs 2004», segons PEC aprovat el 2019. No s’inventa dia ni interval escolar complet a partir d’aquella expressió. Antonio Machado: creació el 2005 segons la definició institucional, diferenciada del trasllat de 2007.
Germanes Bertomeu: es completa el camp amb la inauguració de 15-09-1969 ja documentada, sense heretar dates de centres precedents. Torre Llauder: camp d’inauguració per curs 1978–1979 segons la fita existent; no es fixa un dia nou. Thos i Codina: transformació de primària en institut de FP el 1989; no data la fundació de l’escola predecessora.

Fitxers històrics vigents: esdeveniments_historics_v13.csv i fonts_historiques_v13.csv. Base canònica CSV/GeoJSON, auditoria_origens_v13.csv, pistes_origen_per_revisar_v13.csv i revisio_sis_origens_v13.csv actualitzats. Els fitxers anteriors són checkpoints i no s’han de sumar. La cronologia i les propietats del mapa estan sincronitzades. Les geometries i l’inventari de seus no s’amplien per inferència.

Continuen sense fita atribuïble Col·legi Salesià 08065123 i Picasoques 08078695. Les consultes documentals preparades a V12 es conserven sense enviar. Els 75 codis no equivalen a 75 centres actius confirmats. Les correccions de vigència i els 73 punts es mantenen.

Validació de recomptes, codis, fonts, intervals, propietats GeoJSON, dades del mapa, articles de cronologia, auditoria, sintaxi JavaScript, enllaços locals, integritat ZIP i SHA256. Sense comprovació visual en navegador ni contrast arxivístic exhaustiu.
