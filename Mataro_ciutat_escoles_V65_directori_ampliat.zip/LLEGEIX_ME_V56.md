# V56 · Fotografies i navegació

El títol del visor enllaça amb la pàgina inicial. Fitxes amb fotografia afegida:

- Teler quadrat del Museu del Gènere de Punt, a Can Marfà · Clemens Schmillen · CC BY-SA 4.0 · Redimensionada a WebP · https://commons.wikimedia.org/wiki/File:MataroMuseuGenereDePunt4.jpg
- Façana de Can Serra, seu del Museu de Mataró · Martinge636 · CC BY-SA 4.0 · Redimensionada a WebP · https://commons.wikimedia.org/wiki/File:Can_Serra_%28Matar%C3%B3%29.jpg
- Mènsula modernista amb un gat que juga amb un cabdell, a la Casa Coll i Regàs · Enric · CC BY-SA 4.0 · Redimensionada a WebP · https://commons.wikimedia.org/wiki/File:075_Casa_Coll_i_Reg%C3%A0s_%28Matar%C3%B3%29%2C_gat_jugant_amb_un_cabdell%2C_m%C3%A8nsula_d%27Eusebi_Arnau.jpg
- Façana de la Nau Gaudí, antiga nau de la Cooperativa Obrera Mataronina · ESM · CC BY-SA 4.0 · Redimensionada a WebP · https://commons.wikimedia.org/wiki/File:Matar%C3%B3_-_cooperativa_obrera_mataronina%2C_nau_Gaud%C3%AD_frontal.jpg
- Biblioteca Antoni Comas a l’antic Escorxador de Mataró · JordiGran · CC BY-SA 3.0 · Redimensionada a WebP · https://commons.wikimedia.org/wiki/File:Biblioteca_P%C3%BAblica_Antoni_Comas%2C_al_Pati_de_l%27Escorxador_de_Matar%C3%B3.jpg
- Edifici universitari TCM1 del TecnoCampus · Zarateman · CC0 1.0 · Redimensionada a WebP · https://commons.wikimedia.org/wiki/File:Matar%C3%B3_-_TecnoCampus_Matar%C3%B3-Maresme%2C_Edifici_Universitari_TCM1_%2807%29.jpg
- Façana del Foment Mataroní · Josep Ramis · CC BY-SA 3.0 · Redimensionada a WebP · https://commons.wikimedia.org/wiki/File:El_Foment_Mataroni.jpg
