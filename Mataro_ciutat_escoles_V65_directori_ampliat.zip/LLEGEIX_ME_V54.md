# Mataró, ciutat d’escoles · V54

49 fitxes noves. El directori passa de 114 a 163 fitxes, a banda de la capa de lleure i casals.

El lot inclou centres i espais formatius amb oferta documentada a Mataró. Els casals municipals de gent gran i les seus museístiques es compten com a punts d’aprenentatge amb programació pròpia. Les dues escoles d’atletisme són d’entitats diferents i comparteixen instal·lació.

Les incorporacions es consulten a «Altres centres, acadèmies i universitats» en mode Actualitat. El fitxer incorporacions_V54_fonts.csv recull el criteri individual, l’oferta i la referència geogràfica.

- Aprenentatge per a gent gran · 10
- Arts escèniques · 2
- Arts plàstiques i oficis · 5
- Dansa · 3
- Esport i activitat física · 7
- Formació per a l’ocupació · 1
- Formació viària · 6
- Idiomes · 3
- Música · 1
- Patrimoni i museus · 7
- Tecnologia i ciència · 4

## Candidatures pendents de localització

- Hwarang Mataró · Arts marcials · Passatge de Ca l’Ymbern, 2 · https://hwarangmataro.com/
