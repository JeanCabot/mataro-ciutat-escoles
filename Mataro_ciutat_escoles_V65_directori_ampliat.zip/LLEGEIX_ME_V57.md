# V57 · Fotografies

73 de 164 fitxes amb fotografia.

- Façana de l’antiga presó, seu del Mataró Art Contemporani · Enric · CC BY-SA 4.0 · Redimensionada a WebP · https://commons.wikimedia.org/wiki/File:331_Antiga_Pres%C3%B3_de_Matar%C3%B3%2C_muralla_de_la_Pres%C3%B3_2%2C_angle_sud-oest.jpg
- Masia de Can Boet, Centre de Patrimoni Arqueològic i Natural · Àlex · CC BY-SA 3.0 es · Redimensionada a WebP · https://commons.wikimedia.org/wiki/File:Can_Boet_%28Matar%C3%B3%29_2013-09-29_19-21-38.jpg
- Accés al Centre d’Art Ca l’Arenas · Kippelboy · CC BY-SA 3.0 · Redimensionada a WebP · https://commons.wikimedia.org/wiki/File:Ca_l%27Arenas_%284%29-_Entrance_sign.JPG
- Façana de la Biblioteca Pompeu Fabra de Mataró · Zarateman · CC0 · Redimensionada a WebP · https://commons.wikimedia.org/wiki/File:Matar%C3%B3_-_Biblioteca_Pompeu_Fabra_1.jpg
- Aparador de la Biblioteca Popular de Mataró al concurs de 2025 · La Setmana from Barcelona, Catalunya · CC BY-SA 4.0 · Redimensionada a WebP · https://commons.wikimedia.org/wiki/File:Concurs_d%27aparadors_de_biblioteques_2025_Biblioteca_Popular_-_MATAR%C3%93_%2854792995047%29.jpg
- Façana del Col·legi Sant Josep de Mataró · Zarateman · CC0 · Redimensionada a WebP · https://commons.wikimedia.org/wiki/File:Matar%C3%B3_-_Colegio_de_Sant_Josep.jpg
