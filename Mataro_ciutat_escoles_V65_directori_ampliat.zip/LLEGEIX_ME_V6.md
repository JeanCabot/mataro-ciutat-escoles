# Mataró, ciutat d’escoles — V6
Guia vigent, 18-11-2026. Paquet acumulatiu.

75 centres actuals; 77 localitzacions registrals o seus actuals conegudes, de les quals 75 tenen punt. 28 fites de 14 centres: 5 fites noves de 4 centres privats. GEM Petit s’afegeix al catàleg de seus sense coordenada; no incrementa el nombre de centres.

## Novetats
Balmes: origen el 1896, corroborat al directori municipal i web escolar. Cor de Maria: comunitat educativa a Mataró el 19-11-1861; la primera adreça és contradictòria al mateix web (Argentona 3/4), per tant sense punt històric. Salesians: inauguració del col·legi 24-04-1905 segons Ajuntament. GEM: inici del projecte 1966 i inscripció de l’associació abril 1967, segons presentació escolar i inventari UB.

No es presenta un concert educatiu actual com a situació històrica de 1861 o 1896. El camp concert continua pendent per ensenyament i període. Les dates d’inauguració o projecte mantenen la seva categoria, no es converteixen totes en fundacions.

Hi ha un fons GEM al CRAI Biblioteca del Pavelló de la República, amb inventari públic. És una pista arxivística per a més recerca; no s’han examinat encara els documents individuals del fons. GEM també publica una adreça a Cabanellas 23 (GEM Petit), sense data d’inici. Àvila figura 9–45 al CSV i 9–43 al web: rang conservat i discrepància registrada. Els dos iframes de mapes comparteixen centre de vista, que no s’ha confós amb coordenada del segon centre.

Fitxers vigents: fonts_historiques_v6.csv; esdeveniments_historics_v6.csv; mataro_centres_2026_2027.csv/.geojson; mataro_seus_observades.csv; cobertura_recerca_v6.csv; discrepancies_i_pistes_v6.csv. Els fitxers amb versions anteriors es conserven com a antecedents. El GeoJSON de seus V2 continua incloent només les 75 geometries disponibles (GEM Petit no té punt).

Obriu index.html (cens actual), cronologia.html (28 fites, 14 centres) o angeleta-ferrer.html (cas de tres seus). Mapes amb connexió a Internet. El mapa general no és un cens històric de centres actius per any. Cap publicació al web feta en aquesta fase.

Validació: 75 codis sense duplicats; 28 esdeveniments únics; 14 codis amb fites; 77 identificadors de seu; referències de fonts íntegres i GeoJSON sincronitzat amb el cens. Comprovació sintàctica JavaScript, sense inspecció visual de navegador.
