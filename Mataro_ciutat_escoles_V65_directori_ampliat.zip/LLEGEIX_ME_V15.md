# Mataró, ciutat d’escoles — V15, 18-11-2026
Paquet acumulatiu. Obre index.html, cronologia.html i auditoria-origens.html. Sense publicació en línia.

131 fites de 73/75 codis (97,3% amb qualsevol fita). 54 camps de data relacionada amb l’origen informats i 21 buits. Tres camps afegits reutilitzen autoritzacions de La Caseta, Petit Somni i La Fada, ja documentades a V10–V11; no són fundacions acabades de descobrir. Es tipifiquen com a autoritzacions, amb efectes legals i primeres classes separats. Els camps informats inclouen també antecedents, creacions, inauguracions i projectes.

Sis fites noves: atribució d’origen de Cerdanyola el 1979 al catàleg fotogràfic del MASMM; commemoració denominada vuitè aniversari el 17-06-1989 a l’arxiu de sortides del Sethomes; trasllat de La Llàntia de Boixa a Galícia el curs 1995–1996; acte d’inauguració dels nous locals de 27-01-1996; inici d’un canvi pedagògic a La Llàntia el curs 2015–2016; i creació de La Iaia de La Riereta el curs 1996–1997. Les fites festives s’identifiquen com a documentació comunitària retrospectiva. No daten automàticament la fundació.

Cerdanyola: discrepància conservada D15. No es calcula 1981 a partir d’un vuitè aniversari ni es fixa una data única de fundació. El catàleg és una descripció retrospectiva de fotografia de 1993, no una acta fundacional. El camp d’origen segueix buit.
La Llàntia: el trasllat i la inauguració són fets diferents. L’origen del centre encara pendent. La Riereta: la figura festiva és patrimoni escolar, no la fundació; expressions com «feia poc temps» no generen data exacta.

Pista prioritària: Una escola avançada. L’escola bressol municipal de Mataró 1979–2007, editat per l’IME. La notícia municipal de 2007 està localitzada, però el llibre íntegre no s’ha consultat; no s’atribueixen continguts ni pàgines no llegits. No es trasllada la data del Patronat a cadascuna de les escoles. Can Marfà i Can Noè continuen sense origen inicial resolt.

Fitxers vigents: esdeveniments_historics_v15.csv, fonts_historiques_v15.csv, auditoria_origens_v15.csv, pistes_origen_per_revisar_v15.csv, discrepancies_i_pistes_v15.csv, revisio_tres_autoritzacions_v15.csv, pistes_bibliografiques_v15.md i base canònica CSV/GeoJSON. Les versions anteriors són checkpoints; no sumar files. El mapa, la cronologia i l’auditoria estan sincronitzats. No s’han afegit geometries per inferència.

Dos codis continuen sense fita atribuïble: Col·legi Salesià 08065123 i Picasoques 08078695. Les consultes documentals de V12 es conserven sense enviar. 75 codis no són 75 centres actius confirmats. Es mantenen els 73 punts de centre i els avisos de vigència.

Validació: codis, fonts, intervals, 131 articles de cronologia, 75 files d’auditoria, dades del visor, GeoJSON, sintaxi JavaScript, enllaços locals, SHA256 i integritat ZIP. Sense inspecció visual amb navegador ni contrast arxivístic exhaustiu.
