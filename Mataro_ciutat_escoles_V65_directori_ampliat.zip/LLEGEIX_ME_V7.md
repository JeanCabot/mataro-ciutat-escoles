# Mataró, ciutat d’escoles — V7
Guia vigent. Paquet acumulatiu del 18-11-2026. 75 centres actuals, 77 seus actuals registrals/documentades (75 amb geometria), 36 fites de 18 centres. Les localitzacions històriques s’inventarien en taules separades i no incrementen el nombre de centres actuals.

## Ampliació
Meritxell: inici escolar 1969, segons Alumni institucional. Freta: inici 1964, adopció d’FP reglada 1972 i trasllat a Rocafonda 1987, segons PEC. Mare de Déu de Lourdes: compra de finca febrer 1906, obertura de classes setembre 1906 i canvi de titularitat 2006. Divina Providència: antecedent monàstic de 1849; no es tracta com una fundació escolar resolta.

## Precisió
Freta té dues narracions diferents sobre el primer local (Tereses/Amàlia), conservades a discrepancies_i_pistes_v7.csv. No s’ha geocodificat un lloc inicial ambigu. Els locals d’en Moles són documentals i amb número desconegut. La fitxa de seu actual té inici d’ocupació per any, no dia exacte. No s’han incorporat al mapa de Mataró les seus de Freta a Calella.
La data fundacional del monestir de Divina Providència no prova per si sola l’obertura escolar. El camp fundacio_any continua buit en aquest cas i altres d’origen tipificat. Tots els tipus de fita són consultables al CSV.

## Fitxers vigents
fonts_historiques_v7.csv, esdeveniments_historics_v7.csv, discrepancies_i_pistes_v7.csv, cobertura_recerca_v7.csv, freta_seus_documentals_v7.csv, mataro_centres_2026_2027.csv/.geojson, mataro_seus_observades.csv.
Els fitxers V1–V6 són antecedents; no sumar-ne registres als V7, que ja són acumulatius. El GeoJSON de seus conserva el nom V2 per compatibilitat però les propietats s’han actualitzat a partir de la taula vigent.
Obrir index.html, cronologia.html o angeleta-ferrer.html. Els mapes requereixen Internet. Sense publicació web en aquesta fase.

Validació de recompte, integritat de codis i fonts, geometries i sintaxi JavaScript. No s’ha fet inspecció visual amb navegador. La cronologia és parcial: 18 de 75 centres amb alguna fita, no 18 històries completes. Els 57 restants continuen pendents.
