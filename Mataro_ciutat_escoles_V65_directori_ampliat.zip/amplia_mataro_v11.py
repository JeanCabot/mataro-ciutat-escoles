from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile,collections,subprocess
B=Path(__file__).parent;out=B/'mataro_escoles_v11';shutil.copytree(B/'mataro_escoles_v10',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,rows):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
a=read('mataro_centres_2026_2027.csv');am={r['codi_centre']:r for r in a};E=read('esdeveniments_historics_v10.csv');F=read('fonts_historiques_v10.csv');fm={r['id_font']:r for r in F}
def src(i,t,u,typ):
 r=dict(id_font=i,titol=t,url=u,consulta='2026-11-18',tipus=typ,abast='Fets i límits indicats en les fites i la revisió');F.append(r);fm[i]=r
src('H89','DOGC — ENS/21/2014, text íntegre La Fada','https://portaldogc.gencat.cat/utilsEADOP/AppJava/PdfProviderServlet?documentId=652324&type=01&language=ca_ES','document oficial, text íntegre')
src('H90','Gi Escola — biografia d’Inma Garcia','https://www.giescola.com/inma-garcia','relat institucional de la directora; origen de projecte, no autorització')
src('H91','Ajuntament — gala Mataró ciutat de valors, gener 2015','https://www.mataro.cat/ca/actualitat/noticies/2015/dues-centes-persones-participen-al-teatre','crònica institucional d’acte celebrat')
src('H92','Generalitat — oferta PFI 2024–2025','https://documents.espai.educacio.gencat.cat/IPCNormativa/DisposicionsInternes/20230719-llista-pfi-2024-2025.pdf','llista oficial d’oferta; no autorització fundacional')
for e in E:
 if e['id_esdeveniment']=='HIST-110':
  assert e['codi_actual_referencia']=='08073946'
  e.update(id_font='H89',font_url=fm['H89']['url'],afirmacio='Resolució ENS/21/2014 d’autorització d’obertura de La Fada, codi 08073946, a ronda Alfons X el Savi 131, baixos.',localitzador='DOGC 6541, 16-01-2014, p. 1, apartat 1',notes='Text íntegre recuperat a V11: codi i adreça confirmats. Efectes des de l’inici del curs 2013–2014; no prova del primer dia de classe. Relació amb Pinotxo pendent.')
def ev(c,k,d,f,claim,loc,notes,end=None):
 E.append(dict(id_esdeveniment='HIST-'+str(max(int(x['id_esdeveniment'].split('-')[1]) for x in E)+1).zfill(3),id_entitat='ENT-'+c,codi_actual_referencia=c,centre=am[c]['nom'],tipus=k,data_min=d,data_max=end or d,precisio='curs' if end else 'any' if len(d)==4 else 'dia',afirmacio=claim,id_font=f,font_url=fm[f]['url'],localitzador=loc,estat='documentat; contrast parcial',notes=notes))
ev('08073946','efectes_autoritzacio_obertura','2013','H89','Inici del curs 2013–2014: efectes legals de l’autorització d’obertura de La Fada.','p. 1, apartat 1','La resolució és de 02-01-2014 i la publicació de 16-01-2014. No s’intercanvien aquestes dates ni s’inventa un dia d’obertura.',end='2014')
ev('08078877','consolidacio_projecte_escolar','2012','H90','La biografia d’Inma Garcia situa la consolidació del projecte Gi Escola d’Arts Escèniques el 2012.','Apartat «2012 Gi»','Relat institucional de la directora. No és la data d’autorització del codi 08078877 ni dels cicles oficials, que segueix pendent. La idea de 2005 i l’Acadèmia Shoot de 1996/1999 es mantenen com a antecedents sense heretar-ne la fundació.')
ev('08056948','participacio_cultural_escolar','2015-01-16','H91','Participació d’alumnat de l’Escola de Dansa Heidi Consegal a la gala de cloenda de Mataró, ciutat de valors, al Teatre Monumental.','Notícia de 16-01-2015, paràgraf d’actuacions','La crònica diu que la gala s’ha celebrat aquella nit. És una fita d’activitat cultural, no una fundació, inauguració ni autorització del centre.')
E.sort(key=lambda e:(e['data_min'],e['id_esdeveniment']));counts=collections.Counter(e['codi_actual_referencia'] for e in E);assert len(E)==116 and len(counts)==73
write('esdeveniments_historics_v11.csv',E);write('fonts_historiques_v11.csv',F)
for r in a:
 c=r['codi_centre'];r['nombre_fites_documentades']=counts[c]
 if c in ['08073946','08078877','08056948']:r['estat_recerca_historica']='fites documentades; història parcial'
 if c=='08078877':r['estat_recerca_historica']='consolidació de projecte documentada; autorització del codi pendent'
 if c=='08056948':r['estat_recerca_historica']='activitat cultural documentada; fundació i autorització pendents'
write('mataro_centres_2026_2027.csv',a)
g=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in g['features']:f['properties']=am[f['properties']['codi_centre']]
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(g,ensure_ascii=False,indent=2))
obs=read('evidencies_sense_fita_v10.csv');remaining=[r for r in obs if r['codi_centre'] not in counts]
for r in remaining:
 if r['codi_centre']=='08065123':r.update(fonts=r['fonts']+' | H92',data_document='2008 / curs 2024–2025',afirmacio=r['afirmacio']+' El llistat PFI 2024–2025 confirma el mateix codi amb perfils de comerç i activitats esportives.',pendent=r['pendent']+' El llistat d’oferta no es converteix en data d’origen ni d’autorització inicial.')
write('evidencies_sense_fita_v11.csv',remaining)
review=[dict(codi_centre=c,centre=am[c]['nom'],resultat=result,pendent=p) for c,result,p in [
('08073946','Text íntegre recuperat: codi, adreça i efectes 2013–2014 confirmats.','Primer dia de classes i relació amb Pinotxo pendents.'),
('08078877','Consolidació del projecte Gi el 2012, segons biografia de la directora.','Autorització del codi actual i cicles; seus i continuïtat jurídica pendents.'),
('08056948','Actuació escolar documentada el 16 gener 2015.','Fundació i autorització pendents. No s’usa 2001 del directori erroni.'),
('08065123','Oferta PFI 2024–2025 confirmada per codi; sense nova fita d’origen.','Conciliar codis 08065123 i 08021089 mitjançant acte administratiu.'),
('08078695','Web oficial confirma codi i adreça; recerca d’obertura sense resultat concloent.','Autorització, primer curs i coordenada de portal pendents. Cap relació provada amb la societat homònima Pica Soques SL.')]];write('revisio_pendents_v11.csv',review)
cover=[dict(codi_centre=r['codi_centre'],centre=r['nom'],naturalesa_actual=r['naturalesa'],fites_documentades=counts[r['codi_centre']],estat=r['estat_recerca_historica'],nota='Denominador fix: 75 codis del CSV, no tots actius. Cobertura de qualsevol fita, no de fundacions.') for r in a];write('cobertura_recerca_v11.csv',cover)
d=read('discrepancies_i_pistes_v10.csv');d.append(dict(id='D14',centre='Gi Escola',tema='projecte i codi',dada_a='Consolidació del projecte Gi: 2012',dada_b='Autorització del codi i cicles: data pendent',font='H90 | H73',decisio='Registrar consolidació institucional sense convertir-la en data d’autorització ni atribuir-hi l’Acadèmia Shoot.'));write('discrepancies_i_pistes_v11.csv',d)
chron=(out/'cronologia.html').read_text();opts='<option value="">Tots els centres documentats</option>'+''.join('<option value="'+c+'">'+html.escape(n)+'</option>' for c,n in sorted({(e['codi_actual_referencia'],e['centre']) for e in E},key=lambda x:x[1]));chron=re.sub(r'(<select id="centre">).*?(</select>)',lambda m:m[1]+opts+m[2],chron,count=1,flags=re.S)
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['data_min']+'–'+e['data_max'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(fm[e['id_font']]['titol'])+' · '+html.escape(e['localitzador'])+'</a></p></article>' for e in E)
chron=re.sub(r'<article.*?</article>(?:<article.*?</article>)*',lambda m:items,chron,count=1,flags=re.S).replace('113 fites documentades de 71 dels 75 registres de base (94,7%)','116 fites documentades de 73 dels 75 registres de base (97,3%)').replace('V10','V11');(out/'cronologia.html').write_text(chron)
idx=(out/'index.html').read_text().replace('versió 10','versió 11').replace('113 fites','116 fites').replace('71 centres amb alguna fita documentada','73 centres amb alguna fita documentada').replace('71/75 registres · 94,7%','73/75 registres · 97,3%');idx=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',idx,count=1,flags=re.S);(out/'index.html').write_text(idx)
rows=''.join('<tr><td>'+html.escape(r['nom'])+'</td><td>'+str(counts[r['codi_centre']])+'</td><td>'+html.escape(r['estat_recerca_historica'])+'</td></tr>' for r in sorted(a,key=lambda r:r['nom']))
(out/'cobertura.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Cobertura V11</title><style>body{font:17px system-ui;max-width:980px;margin:40px auto;padding:20px;color:#243b35;background:#f7f5ed}table{border-collapse:collapse;width:100%}td,th{text-align:left;padding:10px;border-bottom:1px solid #ccc}a{color:#25634e}</style><h1>73 de 75 registres: 97,3%</h1><p>116 fites; històries parcials. Cobertura d’almenys una fita, de naturalesa diversa: no són 73 fundacions verificades. Gi: consolidació del projecte, sense data d’autorització del codi. Heidi: participació cultural, fundació pendent. La Fada: text íntegre i codi confirmats. Dos codis sense fita: Col·legi Salesià 08065123 i Picasoques. El denominador continua sent els 75 codis del CSV; no tots actius.</p><p><a href="index.html">Mapa</a> · <a href="cronologia.html">Cronologia</a> · <a href="revisio_pendents_v11.csv">Revisió</a> · <a href="evidencies_sense_fita_v11.csv">Dos casos sense fita</a></p><table><tr><th>Centre</th><th>Fites</th><th>Recerca</th></tr>'+rows+'</table></html>')
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=11,fites_historiques=116,centres_amb_fites=73,centres_pendents=2,cobertura_percent=97.33,centres_amb_fites_text_integre_o_narrativa=73,centres_amb_fites_nomes_metadades=0,centres_nous_v11=2,fites_noves_v11=3,fites_revisades_v11=1,nota='75 codis de base; vigència parcial. La Fada confirmada pel text íntegre. Cobertura de qualsevol fita; Gi consolidació de projecte i Heidi activitat cultural, sense fundació o autorització completa.');(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
D=out/'documents_v11';D.mkdir(exist_ok=True)
for n in ['fada','pfi']:
 for ext in ['pdf','txt']:
  p=Path('/tmp/v11docs')/(n+'.'+ext)
  if p.exists():shutil.copy2(p,D/p.name)
# Do not redistribute entire copyrighted webpages: retain source URLs and short research notes.
(out/'LLEGEIX_ME_V11.md').write_text('''# Mataró, ciutat d’escoles — V11, 18-11-2026
Paquet acumulatiu: obre index.html, cronologia.html i cobertura.html. Sense publicació en línia.

116 fites, 73 dels 75 codis amb almenys una fita (97,3%). Cobertura de fites heterogènies, no de fundacions ni d’històries completes. Gi entra per consolidació de projecte el 2012 segons relat de la directora, no per autorització dels cicles. Heidi entra per una actuació escolar de gener de 2015, no per fundació. Aquest criteri inclou activitat cultural igual que les fites de patrimoni escolar i commemoracions ja presents; no s’han convertit llistats de mera presència en dates d’origen.

La Fada: recuperat el text íntegre ENS/21/2014. Confirma codi 08073946 i adreça ronda Alfons X el Savi 131, baixos. Resolució 02-01-2014, publicació 16-01-2014, efectes des de l’inici del curs 2013–2014. HIST-110 manté identificador però ara cita H89; H85 conserva les metadades del pas anterior. S’afegeix la fita d’efectes legals. Primer dia de classes i relació amb Pinotxo pendents.

Gi: la biografia d’Inma Garcia al web del centre diu que el projecte es consolida el 2012. No es data l’alta del codi 08078877, l’obertura del local ni l’autorització de cicles amb aquesta afirmació. Els antecedents Shoot 1996/1999 i idea de 2005 no s’hereten com a fundació del centre actual.
Heidi: la crònica municipal de 16-01-2015 documenta l’actuació de l’alumnat a la gala Mataró ciutat de valors. La fundació i l’autorització continuen pendents; no s’utilitza la data de 2001 del directori que la confon amb un centre de primària.

Dos codis sense fita atribuïble: Col·legi Salesià 08065123 i Picasoques 08078695. Col·legi Salesià té oferta oficial documentada 2008 i PFI 2024–2025; no es presenta el llistat PFI com a autorització inicial. Continua pendent la conciliació amb 08021089 de la resolució de 2004. Picasoques té activitat documentada i web amb codi i adreça, sense data inicial confirmada; cap relació provada amb una societat mercantil homònima. No s’han incorporat aquestes coincidències com a fundacions.

Fitxers vigents: esdeveniments_historics_v11.csv, fonts_historiques_v11.csv, cobertura_recerca_v11.csv, evidencies_sense_fita_v11.csv, revisio_pendents_v11.csv, discrepancies_i_pistes_v11.csv i base CSV/GeoJSON principal. Documents oficials consultats a documents_v11. Versions anteriors: checkpoints; no sumar-ne les files.
Es mantenen les correccions de vigència i de seus de V9–V10. 75 codis no significa 75 centres actius confirmats. 73 punts al mapa i 78 observacions de seu; el filtre temporal representa fites i no escoles actives a cada any.

Validació de codis, fonts, intervals, enllaços locals, propietats GeoJSON, dades del visor, sintaxi JavaScript, integritat ZIP i SHA256. Sense comprovació visual amb navegador ni auditoria arxivística exhaustiva.
''')
shutil.copy2(__file__,out/'amplia_mataro_v11.py')
assert len(a)==75 and len(am)==75 and len({e['id_esdeveniment'] for e in E})==len(E)
assert all(e['id_font'] in fm and e['codi_actual_referencia'] in am and e['data_min']<=e['data_max'] for e in E)
assert {r['codi_centre'] for r in remaining}==set(am)-set(counts)
assert chron.count('<article data-year=')==len(E)
for name in ['index.html','cronologia.html','cobertura.html']:
 text=(out/name).read_text()
 for link in re.findall(r'href="([^"#]+)"',text):
  if not link.startswith(('http:','https:',chr(39))):assert (out/link).exists(),link
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',text,re.S)):
  p=Path('/tmp')/('v11_'+name+str(i)+'.js');p.write_text(s);subprocess.run(['node','--check',str(p)],check=True,capture_output=True)
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(manifest,indent=2))
zp=B/'Mataro_ciutat_escoles_V11_contrast_pendents_2026-11-18.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v11/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(json.dumps(dict(zip=str(zp),fites=len(E),centres=len(counts),pendents=len(remaining),bytes=zp.stat().st_size)))
