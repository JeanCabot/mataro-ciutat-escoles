# Mataró, ciutat d’escoles — V18, 19-11-2026
Paquet acumulatiu. Obre index.html. Sense publicació en línia.
146 fites de 73/75 codis (97,3% amb qualsevol fita). 57 camps amb data relacionada amb l’origen i 18 buits. No són 57 fundacions verificades.

Novetat d’origen: creació administrativa del CFA Can Marfà, codi 08060253, pel Decret 213/2007 de 25 de setembre, per transformació de l’AFA Rocafonda. Text normatiu consultat al Full de disposicions 1156, p. 4679. El camp es tipifica com a creació administrativa; fundacio_any buit i origen de l’aula anterior pendent. El curs 2007–2008 és d’adequació normativa, no primer curs escolar observat. No s’uneixen Can Marfà i Can Noè per similitud de noms.

Sis fites noves: creació administrativa i adequació normativa del CFA Can Marfà; construcció de l’equipament educatiu de Can Noè entre 1985 i 1987, vinculada a adults i a la bressol Rocafonda (mateixa obra amb dues relacions); noves inscripcions del Tabalet el 09-01-2004 i inici de la seva cuina central el 19-01-2004. No s’afegeix de nou el trasllat del 08-01 ja documentat. Vegeu pistes_documentals_v18.md.

Fitxers vigents: base CSV/GeoJSON, esdeveniments_historics_v18.csv, fonts_historiques_v18.csv, auditoria_origens_v18.csv, pistes_origen_per_revisar_v18.csv, revisio_origens_v18.csv, registre_recerca_v18.csv i resum_auditoria.json. Historial de versions conservat; no sumar files. Les discrepàncies i pistes anteriors encara obertes es conserven.

Mapa, cronologia, cobertura i auditoria sincronitzats. Cap geometria modificada: les obres històriques no daten la seu actual. Dos codis sense fita: Col·legi Salesià 08065123 i Picasoques 08078695. Els 75 codis no equivalen a 75 centres actius confirmats. Consultes no enviades.

Validació automatitzada: codis, fonts, dates, CSV/GeoJSON/visor, 146 articles, 75 files d’auditoria i cobertura, JavaScript, enllaços locals, SHA256 i ZIP. Sense inspecció visual en navegador.
