# Contrast documental V24 — autorització inicial de Misha / Peques

168 fites, 75 codis, 131 fonts. 64 camps amb una data relacionada amb l’origen; 11 buits. Dels 17 casos revisats, 6 tenen una data qualificada i 11 continuen pendents. Les dates inclouen actes administratius: no equivalen a fundacions ni a primeres classes verificades.

## Nova evidència primària
La Resolució EDC/2102/2004, de 13 de juliol, autoritza l’obertura de Misha, a Mataró: codi 08062547, carrer Rierot 2–4, baixos. L’annex estableix efectes des de l’inici del curs 2004–2005, amb 5 unitats i 66 places. Font H131, Full de disposicions i actes administratius núm. 1014, pàgines impreses 1033–1034. El codi coincideix amb el registre actual de Peques i el mateix emplaçament consta en l’ampliació de 2013 (H120).

Es registra 13-07-2004 com a autorització d’obertura; no s’omple fundacio_any ni s’inventa la data de la primera classe. El canvi de nom a Acuarella de 2018 (H84) i la denominació actual Peques no determinen totes les dates intermèdies de nom i titularitat. Aquesta successió continua pendent de reconstrucció.

## Correcció del pendent
L’autorització inicial de Peques ja no és pendent. Es conserva la recerca anterior com a checkpoint, es retiren les peticions d’autorització inicial d’aquest codi de la cua vigent i s’actualitzen el mapa, la cronologia, l’auditoria i la revisió dels 17 casos. Les 11 consultes restants són esborranys no enviats.

## Fitxers vigents
CSV i GeoJSON canònics; esdeveniments_historics_v24.csv, fonts_historiques_v24.csv, auditoria_origens_v24.csv, revisio_17_camps_v24.csv, consultes_documentals_v24.csv, registre_recerca_v24.csv i resum_auditoria.json. Els fitxers V23 i anteriors són checkpoints; no sumar-los. Obre index.html. Aquest paquet no s’ha publicat en línia.


## CFA Can Noè · 08061658
informat: inici declarat

PEC propi, pp. 3–4: servei des de 1979. 1979 data el servei històric, no l’alta del codi; 2001–02 data titularitat.

Document necessari: Expedient de creació i primera matrícula, si es vol verificar primer curs i continuïtat registral.

## Col·legi Salesià · 08065123
pendent: continuïtat de codis

Història pròpia, pp. 10–11: cursos, CFA i unificació; directori de 2007 amb 08065123 localitzat. 1992 és origen declarat d’un CFA de l’obra; no s’ha provat la continuïtat amb el codi actual.

Document necessari: Expedient d’alta 08065123 i relació amb 08021089; actes de 1992 i unificació 2005.

## EB privada Peques · 08062547
informat: autorització inicial; primeres classes pendents

H131: EDC/2102/2004, de 13 de juliol. Obertura de Misha, mateix codi 08062547, Rierot 2–4; efectes curs 2004–2005, 5 unitats i 66 places. Data administrativa, no primer dia de classes. Cal reconstruir la successió completa Misha/Peques/Acuarella/Peques sense suposar-ne dates.

Document necessari: Primer curs efectiu i resolucions de canvi de nom i titularitat intermèdies; autorització inicial ja localitzada.

## EB privada Picasoques · 08078695
pendent: autorització inicial

Web pròpia identifica codi i Ronda República 27; cerques per Picasoques, Pica-soques i Pica Soques. No heretar dates de revistes homònimes de Castellbisbal ni del projecte web de 2013.

Document necessari: Expedient d’autorització 08078695, llicència d’activitat a República 27 i primer curs.

## Escola Angeleta Ferrer · 08020905
pendent: origen i continuïtat institucional

H46: trasllat de la graduada de nenes a plaça de Cuba el 1940. H130: proposta de canvi de nom en convocatòria de 2001, no acord. 1940 és trasllat, no fundació. La convocatòria no acredita aprovació del nom. No s’hereten dates de l’edifici ni de secundària.

Document necessari: Expedient de l’escola graduada de nenes del carrer Sant Cugat, trasllat de 1940 i continuïtat amb 08020905; acta del Ple de 08-02-2001 i resolució d’Ensenyament del canvi de nom.

## Escola Bressol Cerdanyola · 08046402
pendent: discrepància d’origen

MASMM atribueix creació a 1979; un arxiu geganter registra un vuitè aniversari el 1989. No convertir la resta 1989−8 en any fundacional; cal distingir municipalització i obertura.

Document necessari: Actes de creació, municipalització i primer curs de Cerdanyola; consultar Una escola avançada (2007).

## Escola de Dansa Heidi Consegal · 08056948
pendent: origen sota nom Dúnia

Fullet oficial de Dansa 2007: Dúnia 08056948, Concepció 11; coincideix amb el codi actual Heidi Consegal. 2007 és presència al directori, no obertura; es descarta 2001 del directori que la qualifica erròniament de primària.

Document necessari: Autorització original de Dúnia i expedient del canvi de denominació a Heidi Consegal; primer curs.

## Escola Josep Manuel Peramàs · 08020917
informat parcial: inauguració

Premsa contemporània de 02-02-1972: inauguració i funcionament des de setmanes abans. No data el primer dia de classe ni la creació legal; no es deriva 1971 d’un aniversari.

Document necessari: Ordre de creació i primer llibre de matrícula del grup Peramas.

## Escola Josep Montserrat · 08021041
informat parcial: constitució administrativa

Ordre de 24-07-1975: transformació del patronat de Caixa Laietana a règim ordinari. No data l’obertura del centre anterior; 1962, 1963 i 1964 continuen requerint conciliació.

Document necessari: Expedient del patronat i notícia Escuela Josep Montserrat en Peramas, Diari de Mataró, 21-09-1962, p. 1.

## Institut Damià Campeny · 08021302
informat: creació administrativa

Decret de 1969: secció; Decret 2165/1975: institut; Ordre de 1977: nom Damiá Campeny. No heretar la data del COPEM ni la construcció de 1966; primer dia de classe pendent.

Document necessari: Primera matrícula de l’institut 1975–1976, si es vol precisar l’inici efectiu.

## Llar d'infants La Llàntia · 08046414
pendent: obertura anterior al trasllat

Fent camí documenta trasllat el 1995–1996; gegants daten nous locals el 27-01-1996. 1996 no és fundació; no heretar 1978 de l’escola de primària homònima.

Document necessari: Creació i primer curs al carrer Boixa; consultar Una escola avançada (2007).

## Llar d'infants La Riereta · 08057515
pendent: obertura i conveni

La Iaia es crea el 1996–1997 quan feia poc que s’havia inaugurat l’escola; conveni de 15-10-1997. No equivaler la geganta ni el conveni al primer dia de classe.

Document necessari: Acta d’obertura, primer curs i conveni de creació de 15-10-1997; consultar Una escola avançada (2007).

## Llar d'infants Rocafonda · 08046426
pendent: obertura institucional

Edifici educatiu 1985–1987 i conveni de 16-10-1992 documentats. Construcció i conveni no són origen; la memòria d’una inauguració un Primer de Maig no n’indica l’any.

Document necessari: Acta d’inauguració i primer curs de la bressol; continuïtat amb guarderies veïnals si existeix.

## Llar d'infants Tabalet · 08046451
pendent: centres anteriors

Trasllat dels dos Tabalet al nou edifici el 8 i 9 de gener de 2004 documentat; conveni de 1992. 2004 és trasllat i ampliació; no s’adopta com a fundació dels dos centres anteriors.

Document necessari: Creació dels Tabalet I i II, primers cursos i unificació; consultar Una escola avançada (2007).

## LLI privada Nemomarlin Maresme · 08076790
pendent: obertura inicial

Xarxa Nemomarlin: incorporació el 2019–2020; cessament efectiu final 2025–2026. No prendre una previsió d’apertura 2018–2019 ni l’adhesió a la franquícia com a obertura real.

Document necessari: Autorització original 08076790, titulars i noms anteriors, primera matrícula al carrer Vallespir 2.

## Sant Josep · 08021181
pendent: discrepància 1968/1970

Història pròpia declara 1968; Caràcter propi 1970; URC separa classes i comunitat de 1970; benedicció 04-01-1970. No es construeix un interval 1968–1970 com si fos una incertesa sobre un mateix fet; són afirmacions i esdeveniments a separar.

Document necessari: Acta fundacional, primera matrícula i autorització; aclariment explícit dels anys 1968 i 1970.

## Sol-Ixent · 08035374
informat: fundació declarada

MASMM declara fundació per la família Sancho i Caballé el 1970. No és data d’autorització; no confondre amb ampliació BUP de 1980 ni societat mercantil de 2002.

Document necessari: Autorització inicial i primera matrícula, si es vol passar de fundació declarada a primer curs verificat.

