from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile,collections,subprocess
B=Path(__file__).parent;out=B/'mataro_escoles_v19';shutil.copytree(B/'mataro_escoles_v18',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,rows):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['codi_centre','centre','id_esdeveniment','tipus','data','id_font','afirmacio','decisio']);w.writeheader();w.writerows(rows)
a=read('mataro_centres_2026_2027.csv');am={r['codi_centre']:r for r in a};E=read('esdeveniments_historics_v18.csv');F=read('fonts_historiques_v18.csv');fm={r['id_font']:r for r in F}
def src(i,t,u,typ):
 r=dict(id_font=i,titol=t,url=u,consulta='2026-11-19',tipus=typ,abast='Fets i límits indicats en les fites i la revisió');F.append(r);fm[i]=r
src('H114','Triangle Acadèmia — El centre','https://triangle-academia.com/el-centre/','història declarada pel centre; web institucional')
src('H115','DOGC — Resolució ENS/1560/2012, de 25 de juliol, obertura de Triangle','https://portaldogc.gencat.cat/utilsEADOP/AppJava/PdfProviderServlet?documentId=614584&type=01&language=ca_ES','text íntegre del PDF consultat; DOGC 6185, 03-08-2012, pp. 39093–39094')
src('H116','Ajuntament — Cloenda dels Projectes Singulars 2025–2026, 03-06-2026','https://www.mataro.cat/ca/actualitat/noticies/2026/els-projectes-singulars-d2019enguany-clouen-amb-93-alumnes-participants-i-177-estades-formatives-en-empreses?set_language=ca','notícia institucional d’una activitat educativa')
src('H117','Picasoques — Web del centre, identitat i oferta','https://sompicasoques.com/','font del centre; codi 08078695 i adreça, sense data d’origen')
def ev(c,k,d,f,claim,loc,notes,end=None):
 E.append(dict(id_esdeveniment='HIST-'+str(max(int(x['id_esdeveniment'].split('-')[1]) for x in E)+1).zfill(3),id_entitat='ENT-'+c,codi_actual_referencia=c,centre=am[c]['nom'],tipus=k,data_min=d,data_max=end or d,precisio='curs' if end else 'any' if len(d)==4 else 'dia',afirmacio=claim,id_font=f,font_url=fm[f]['url'],localitzador=loc,estat='documentat; contrast parcial',notes=notes))







ev('08073363','antecedent_academia','1989','H114','Triangle declara una trajectòria com a acadèmia a Mataró des de 1989.','El centre, introducció','Antecedent acadèmic declarat retrospectivament; no s’atribueix aquest any a l’autorització del CFA ni s’hi data l’ocupació de l’edifici actual.')
ev('08073363','autoritzacio_obertura','2012-07-25','H115','La Resolució ENS/1560/2012 autoritza l’obertura de Triangle, codi 08073363, per impartir l’adaptació de l’ESO per a persones adultes.','DOGC 6185, 03-08-2012, p. 39093, apartat 1','Data de la resolució; publicació 03-08-2012. No fixa el primer dia real de classes. No duplica la fita declarada d’acreditació 2012–2013: afegeix l’acte legal concret, amb dues unitats i 57 places.')
ev('08078695','acollida_estades_formatives','2025','H116','L’Ajuntament inclou EB Picasoques entre els centres que han acollit estades formatives dels Projectes Singulars durant el curs 2025–2026.','Notícia de 03-06-2026, llista d’entitats acollidores','Activitat documentada, no presència en un simple directori ni fundació. La identitat del centre i el codi 08078695 es contrasten amb H117. No s’infereixen nombre d’estades ni dates individuals.',end='2026')
E.sort(key=lambda e:(e['data_min'],e['id_esdeveniment']));counts=collections.Counter(e['codi_actual_referencia'] for e in E)
assert len(E)==149 and len(counts)==74
write('esdeveniments_historics_v19.csv',E);write('fonts_historiques_v19.csv',F)
r=am['08073363'];e=next(e for e in E if e['id_esdeveniment']=='HIST-148')
changes=[dict(codi_centre=r['codi_centre'],centre=r['nom'],tipus_anterior=r['tipus_data_origen'],data_anterior=r['origen_data_min'],nou_tipus='autorització d’obertura del CFA; acadèmia antecedent des de 1989',nova_data_min=e['data_min'],nova_data_max=e['data_max'],id_esdeveniment=e['id_esdeveniment'],id_font=e['id_font'],limit=e['notes'])]
r.update(tipus_data_origen='autorització d’obertura del CFA; acadèmia prèvia des de 1989',origen_data_min=e['data_min'],origen_data_max=e['data_max'],fundacio_any='',fundacio_font=e['font_url'],estat_recerca_historica='autorització d’obertura del CFA documentada; antecedent acadèmic declarat el 1989')
am['08078695']['estat_recerca_historica']='activitat d’acollida formativa documentada 2025–2026; origen i autorització inicial pendents'
for r in a:r['nombre_fites_documentades']=counts[r['codi_centre']]
write('revisio_origens_v19.csv',changes);write('mataro_centres_2026_2027.csv',a)
g=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in g['features']:f['properties']=am[f['properties']['codi_centre']]
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(g,ensure_ascii=False,indent=2))
write('registre_recerca_v19.csv',[dict(data_consulta='2026-11-19',via='Web, CIDO i DOGC',consulta=f['titol'],resultat='Text consultat; veure HIST-147–149.',limit='Antecedent, autorització i activitat diferenciats.') for f in F if f['id_font'] in {'H114','H115','H116','H117'}]+[dict(data_consulta='2026-11-19',via='Cerca web, dos cercadors',consulta='Una escola avançada. L’escola bressol municipal de Mataró 1979–2007',resultat='Es retroba la notícia de 2007, sense localitzar el llibre íntegre ni exemplar verificat.',limit='No s’atribueixen autor, ISBN o pàgines no consultades. No prova que no sigui accessible en altres catàlegs.')])
(out/'pistes_documentals_v19.md').write_text("""# Contrast V19
Triangle: autorització inicial llegida íntegrament, ENS/1560/2012 de 25-07, DOGC 6185 de 03-08, pp. 39093–39094. Codi 08073363, Sant Josep Oriol 21 baixos, ESO per a persones adultes. Es completa el camp amb data administrativa; fundacio_any buit. 1989 queda com a trajectòria prèvia declarada, en fita pròpia. HIST-101 conserva l’acreditació declarada per al curs 2012–2013; no és una segona autorització.
Picasoques: primera fita del conjunt, acollida d’estades formatives 2025–2026, segons notícia municipal de 03-06-2026. H117 confirma nom, adreça i codi del centre. No s’afegeix una data d’autorització ni fundació. L’expressió «Actualment sense activitat» de la web correspon a una secció de serveis i no es pren com a cessament legal de tota l’escola. La coordenada incorrecta continua exclosa.
Llibre de bressols de 2007: cerca sense accés íntegre ni exemplar contrastat. Continua vigent la pista V15. El PEC de bressols municipals és accessible en un domini municipal alternatiu: https://entitatsmataro.cat/temes/educacio/escoles-bressol-0-3-anys/model-educatiu/pec-ebm-de-mataro.pdf/%40%40download . El seu apartat històric data la xarxa, no cadascun dels centres; no se’n trasllada 1978 o 1979 a totes les bressols.
""")
(out/'evidencies_v19').mkdir(exist_ok=True)
shutil.copy2('/tmp/triangle2012.pdf',out/'evidencies_v19/Triangle_ENS_1560_2012.pdf')
# Audit is rebuilt from the updated canonical data and events.
by=collections.defaultdict(list)
for e in E:by[e['codi_actual_referencia']].append(e)
audit=[]
for r in a:
 c=r['codi_centre'];es=sorted(by[c],key=lambda e:(e['data_min'],e['id_esdeveniment']));first=es[0] if es else {};typ=r['tipus_data_origen'];d=r['origen_data_min']
 if not d:cat='camp d’origen buit; recerca pendent'
 elif 'antecedent' in typ or 'patronat' in typ or 'predecessor' in typ:cat='antecedent; no obertura del centre actual'
 elif 'autorització' in typ:cat='autorització d’obertura; no primeres classes'
 elif 'administrativa' in typ or 'creació' in typ or 'transformació' in typ or typ=='creacio_escola':cat='constitució o creació; classes pendents de distingir'
 elif 'projecte' in typ:cat='inici de projecte; no autorització del codi'
 else:cat='data d’origen declarada; contrast segons font'
 specific={
 '08065123':'Conciliar codis 08065123 i 08021089 i trobar autorització pròpia. No heretar 1905 ni 2004.',
 '08078695':'Autorització i primer curs pendents. Corregir coordenada del CSV només amb portal 27 documentat.',
 '08073946':'Autorització i efectes legals confirmats; primer curs real i relació amb Pinotxo pendents.',
 '08078877':'2012 és consolidació del projecte segons la directora; alta del codi i autorització de cicles pendents.',
 '08056948':'2015 és actuació escolar; no és fundació ni autorització.',
 '08021181':'Conciliar 1968/1970: classes inicials, comunitat religiosa i actes d’inauguració.',
 }
 audit.append(dict(codi_centre=c,centre=r['nom'],fites_documentades=len(es),categoria_origen=cat,tipus_data_origen=typ,origen_data_min=d,origen_data_max=r['origen_data_max'],font_origen=r['fundacio_font'],primera_fita_id=first.get('id_esdeveniment',''),primera_fita_data=first.get('data_min',''),primera_fita_tipus=first.get('tipus',''),primera_fita_font=first.get('font_url',''),control='Primera fita cronològica no equival a fundació.',tasca_prioritaria=specific.get(c,'Precisar què data la font d’origen i contrastar-la.' if d else 'Cercar origen del centre; no adoptar la primera fita com a fundació.')))
write('auditoria_origens_v19.csv',audit);stats=collections.Counter(x['categoria_origen'] for x in audit);norigin=sum(bool(x['origen_data_min']) for x in audit);assert norigin==58
# Candidates are extracted from documented events but do not silently overwrite canonical origins.
missing=[e for e in E if not next(r for r in a if r['codi_centre']==e['codi_actual_referencia'])['origen_data_min'] and e['tipus'] in {'origen_declarat','inauguracio_escola','antecedent_aulari','consolidacio_projecte_escolar','autoritzacio_obertura'}]
write('pistes_origen_per_revisar_v19.csv',[dict(codi_centre=e['codi_actual_referencia'],centre=e['centre'],id_esdeveniment=e['id_esdeveniment'],tipus=e['tipus'],data=e['data_min'],id_font=e['id_font'],afirmacio=e['afirmacio'],decisio='Candidat de revisió; no afegit al camp canònic d’origen automàticament.') for e in missing])
chron=(out/'cronologia.html').read_text();opts='<option value="">Tots els centres documentats</option>'+''.join('<option value="'+c+'">'+html.escape(n)+'</option>' for c,n in sorted({(e['codi_actual_referencia'],e['centre']) for e in E},key=lambda x:x[1]));chron=re.sub(r'(<select id="centre">).*?(</select>)',lambda m:m[1]+opts+m[2],chron,count=1,flags=re.S)
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['data_min']+'–'+e['data_max'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(fm[e['id_font']]['titol'])+' · '+html.escape(e['localitzador'])+'</a></p></article>' for e in E)
chron=re.sub(r'<article.*?</article>(?:<article.*?</article>)*',lambda m:items,chron,count=1,flags=re.S).replace('146 fites documentades de 73 dels 75 registres de base (97,3%)','149 fites documentades de 74 dels 75 registres de base (98,7%)').replace('V18','V19');(out/'cronologia.html').write_text(chron)
idx=(out/'index.html').read_text().replace('versió 18','versió 19').replace('146 fites','149 fites').replace('71 centres amb alguna fita documentada','73 centres amb alguna fita documentada').replace('71/75 registres · 94,7%','73/75 registres · 97,3%');idx=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',idx,count=1,flags=re.S);idx=idx.replace('73 centres amb alguna fita documentada','74 centres amb alguna fita documentada').replace('73/75 registres · 97,3%','74/75 registres · 98,7%');(out/'index.html').write_text(idx)
style='<style>body{max-width:1200px;margin:32px auto;padding:20px;font:16px system-ui;color:#223b39;background:#f5f1e8}h1{font:32px Georgia}table{border-collapse:collapse;width:100%;background:white}td,th{text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid #ccd5ce}small{display:block;line-height:1.5}a{color:#16665c}input,select{padding:10px;margin:8px 8px 16px 0;max-width:100%;font:inherit}.scroll{overflow:auto}</style>'
rows=''.join('<tr data-search="'+html.escape(x['centre'].lower()+' '+x['codi_centre'],quote=True)+'" data-cat="'+html.escape(x['categoria_origen'],quote=True)+'"><td><b>'+html.escape(x['centre'])+'</b><small>'+x['codi_centre']+'</small></td><td>'+str(x['fites_documentades'])+'</td><td>'+html.escape(x['categoria_origen'])+'<small>'+html.escape(x['origen_data_min']+' '+x['tipus_data_origen'])+'</small></td><td>'+html.escape(x['primera_fita_data']+' '+x['primera_fita_tipus'])+'</td><td>'+html.escape(x['tasca_prioritaria'])+'</td></tr>' for x in sorted(audit,key=lambda x:x['centre']))
opts='<option value="">Totes les categories</option>'+''.join('<option>'+html.escape(c)+'</option>' for c in sorted(stats))
script="""const q=document.querySelector('#q'),cat=document.querySelector('#cat'),rows=[...document.querySelectorAll('tbody tr')];function filter(){let n=0;for(const r of rows){const show=r.dataset.search.includes(q.value.toLowerCase().trim())&&(!cat.value||r.dataset.cat===cat.value);r.hidden=!show;if(show)n++;}document.querySelector('#n').textContent=n+' registres';}q.addEventListener('input',filter);cat.addEventListener('change',filter);filter();"""
(out/'auditoria-origens.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Mataró · Auditoria d’orígens V19</title>'+style+'<a href="index.html">← Mapa</a> · <a href="cronologia.html">Cronologia</a><h1>Què sabem dels orígens?</h1><p><b>74/75 codis amb alguna fita · 149 fites. 58/75 tenen una data al camp d’origen; 17 el tenen buit.</b> Les 58 dates inclouen fundacions declarades, antecedents, constitucions administratives i inicis de projectes: no són 58 primers dies de classe verificats. El 98,7% mesura qualsevol fita, no la cobertura de fundacions.</p><p>La primera fita conservada és només la més antiga de les documentades al conjunt actual. No s’utilitza automàticament com a fundació ni com a inici d’ocupació de la seu del mapa. Els 75 són codis de la base registral; no tots actius confirmats.</p><p><a href="auditoria_origens_v19.csv">Dades de l’auditoria</a> · <a href="pistes_origen_per_revisar_v19.csv">Pistes d’origen</a> · <a href="registre_recerca_v19.csv">Registre de recerca</a> · <a href="pla_recerca_pendent_v12.md">Consultes documentals preparades</a></p><label for="q">Centre o codi </label><input id="q" type="search"><label for="cat"> Categoria </label><select id="cat">'+opts+'</select><p id="n"></p><div class="scroll"><table><thead><tr><th>Centre</th><th>Fites</th><th>Camp d’origen</th><th>Primera fita documentada</th><th>Tasca pendent</th></tr></thead><tbody>'+rows+'</tbody></table></div><script>'+script+'</script></html>')




(out/'cobertura.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><title>Cobertura V19</title>'+style+'<h1>74/75 codis amb alguna fita · 149 fites</h1><p>58 camps amb una data relacionada amb l’origen; 17 buits. Triangle: autorització de 2012 separada de la trajectòria prèvia. Picasoques: activitat formativa documentada, origen pendent. No són 58 fundacions verificades. Els 75 codis no són tots actius confirmats.</p><p><a href="index.html">Mapa</a> · <a href="cronologia.html">Cronologia</a> · <a href="auditoria-origens.html">Auditoria</a></p><table><tr><th>Centre</th><th>Fites</th><th>Recerca</th></tr>'+''.join('<tr><td>'+html.escape(r['nom'])+'</td><td>'+str(counts[r['codi_centre']])+'</td><td>'+html.escape(r['estat_recerca_historica'])+'</td></tr>' for r in sorted(a,key=lambda r:r['nom']))+'</table>')
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=19,fites_historiques=149,fites_noves_v19=3,camps_origen_nous_v19=1,codis_amb_camp_origen_informat=58,codis_sense_camp_origen=17,categories_auditoria_origen=dict(stats),nota='74 de 75 codis amb qualsevol fita; no equival a cobertura de fundacions. 58 camps daten orígens de naturalesa diversa, inclosos predecessors.',nota_v19='Triangle: autorització del CFA 25-07-2012 i antecedent acadèmic declarat el 1989. Picasoques: primera activitat documentada 2025–2026, origen pendent.',centres_amb_fites=74,centres_pendents=1,cobertura_percent=98.67,centres_amb_fites_text_integre_o_narrativa=74,centres_amb_fites_nomes_metadades=0);(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V19.md').write_text("""# Mataró, ciutat d’escoles — V19, 19-11-2026
Paquet acumulatiu. Obre index.html. Sense publicació en línia.
149 fites de 74/75 codis (98,7% amb qualsevol fita). 58 camps amb data relacionada amb l’origen i 17 buits. No són 58 fundacions verificades.
Tres fites noves: acadèmia Triangle des de 1989 segons declaració institucional; autorització d’obertura del CFA el 25-07-2012, codi 08073363 (PDF íntegre consultat i inclòs); acollida d’estades formatives a Picasoques durant 2025–2026 segons notícia municipal. Triangle completa un camp administratiu d’origen; el primer dia real de classes és pendent. L’acadèmia prèvia no data l’autorització. HIST-101 conserva la declaració d’acreditació per curs, no una segona autorització.
Picasoques passa a tenir una fita d’activitat; l’origen i l’autorització inicial segueixen pendents. El codi s’identifica amb la web del centre. Només Col·legi Salesià 08065123 continua sense fita atribuïble. Les coordenades de Picasoques segueixen excloses per error d’origen. Es mantenen 73 punts cartogràfics.
Llibre d’escoles bressol 1979–2007: sense consulta íntegra ni exemplar verificat. La pista V15 continua oberta. Vegeu pistes_documentals_v19.md; no s’omplen dates de centres amb la de la xarxa municipal.
Fitxers vigents: base CSV/GeoJSON, esdeveniments_historics_v19.csv, fonts_historiques_v19.csv, auditoria_origens_v19.csv, pistes_origen_per_revisar_v19.csv, revisio_origens_v19.csv, registre_recerca_v19.csv i resum_auditoria.json. Anteriors són checkpoints; no sumar files. Consultes documentals no enviades.
Mapa, cronologia, auditoria i cobertura sincronitzats; geometries no modificades. 75 codis no equivalen a 75 centres actius confirmats.
Validació automatitzada: codis, fonts, intervals, 149 articles, 75 files d’auditoria i cobertura, CSV/GeoJSON/visor, JavaScript, enllaços locals, SHA256 i ZIP. Sense inspecció visual en navegador.
""")
shutil.copy2(__file__,out/'amplia_mataro_v19.py')
assert len(a)==75 and len(audit)==75 and norigin==58 and len(E)==149
assert len({e['id_esdeveniment'] for e in E})==149
assert all(e['id_font'] in fm and e['data_min']<=e['data_max'] for e in E)
assert chron.count('<article data-year=')==149
assert '149 fites' in chron and '149 fites' in idx
assert (out/'cobertura.html').read_text().count('<tr>')==76
payload=re.search(r'const centres=(.*?);const esc=',idx,re.S).group(1)
assert json.loads(payload)==a
assert all(f['properties']==am[f['properties']['codi_centre']] for f in g['features'])
assert len([f for f in g['features'] if f['geometry']])==73
for name in ['index.html','cronologia.html','cobertura.html','auditoria-origens.html']:
 text=(out/name).read_text()
 for link in re.findall(r'href="([^"#]+)"',text):
  if not link.startswith(('http:','https:',chr(39))):assert (out/link).exists(),link
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',text,re.S)):
  path=Path('/tmp')/('v16_'+name+str(i)+'.js');path.write_text(s);subprocess.run(['node','--check',str(path)],check=True,capture_output=True)
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(manifest,indent=2))
zp=B/'Mataro_ciutat_escoles_V19_triangle_i_picasoques_2026-11-19.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v19/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(json.dumps(dict(zip=str(zp),fites=len(E),camps_origen=norigin,pendents=75-norigin)))
