# Mataró, ciutat d’escoles — V3 · primeres fites
18-11-2026. Paquet acumulatiu; conserva la V2 i n’actualitza cens, visor i seus.

Obriu index.html (mapa actual, Internet necessari) o cronologia.html (13 fites amb selector d’any; es pot llegir sense connexió, llevat dels enllaços).

75 centres; 76 seus conegudes, 75 punts de seus. No s’han afegit ni suprimit centres actuals en aquesta fase. Picasoques continua pendent de coordenada exacta.

## Aportacions
- Quatre centres amb documentació històrica inicial: Escola Pia (establiment 1737; col·legi 1738), Valldemia (fundació 1855 i canvis), Miquel Biada (antecedent 1886, transformacions, trasllat i titularitat), Joan Coromines (creació 2007/2008 i planificació d’una seu el 2019).
- Les 13 fites són afirmacions sintetitzades de fonts institucionals, no transcripcions d’expedients primaris. Cada fila té font i precisió temporal.
- El mapa continua sent el cens actual. El selector de la cronologia només filtra fites; no representa les escoles actives a cada any ni projecta les seus actuals cap al passat.
- Biada: continuïtat institucional documentada entre els codis 08021259 i 08077976 per combinació d’actes i web del centre. Es preserven els codis. La data exacta de vigència de cada codi no s’ha deduït del canvi de titularitat.
- Origen de 1886 s’etiqueta com a antecedent de Biada, no com a data d’alta del centre administratiu actual. Coromines conserva el curs 2007/2008 sense convertir-lo en un dia exacte.
- El projecte de nou edifici de Coromines documentat el 2019 no s’ha convertit en obertura ni trasllat.

## Fitxers nous
esdeveniments_historics_v3.csv, fonts_historiques_v3.csv, correspondencia_codis_entitats_v3.csv, cronologia.html.
Els localitzadors de fonts HTML són seccions; la referència al Ple 2023 es localitza pel punt 14. Les fonts poden canviar: caldrà capturar-ne còpies documentals en una fase d’arxiu.

## Següent fase
Ampliar a altres centres amb dates contrastades; identificar i geolocalitzar seus històriques; documentar baixes i fusions; contrastar els concerts per etapa. Només després construir intervals d’activitat cartogràfica amb cobertures i incerteses explícites.

Els scripts previs es conserven com a antecedents. amplia_mataro_v3.py registra aquesta transformació i requereix el paquet V2 en una carpeta germana. LLEGEIX_ME.md descriu la V2; aquest document és la guia vigent de V3.
