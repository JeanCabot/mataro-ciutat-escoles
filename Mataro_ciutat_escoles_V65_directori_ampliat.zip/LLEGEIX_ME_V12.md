# Mataró, ciutat d’escoles — V12, 18-11-2026
Obre index.html per al mapa i auditoria-origens.html per al nou control documental. Paquet acumulatiu, sense publicació en línia.

No s’afegeixen fites històriques: continuen 116 i 73/75 codis amb alguna fita (97,3%). Les cerques no han resolt l’autorització pròpia del Col·legi Salesià 08065123 ni la data inicial de Picasoques 08078695. Les coincidències de noms no s’han promogut a evidència. La manca de resultats no prova que els documents no existeixin.

Nova auditoria de 75 codis: 40 tenen data al camp d’origen i 35 no. Les 40 inclouen antecedents, creacions administratives i projectes, a més d’inicis escolars i fundacions declarades; no són 40 fundacions verificades. La primera fita datada tampoc equival automàticament a la fundació. La taula permet cercar centres i filtrar la naturalesa del camp d’origen. El nou CSV de pistes identifica fites existents que cal revisar abans de decidir si s’informen camps canònics; no modifica dates per inferència.

Dades històriques vigents: esdeveniments_historics_v11.csv i fonts_historiques_v11.csv (sense canvis); base CSV/GeoJSON i inventari de seus de V11. Nova informació: auditoria_origens_v12.csv, pistes_origen_per_revisar_v12.csv, registre_recerca_v12.csv, pla_recerca_pendent_v12.md i auditoria-origens.html. Versions anteriors són checkpoints, no sumar-ne registres.

S’han redactat consultes a Educació i als dos centres per obtenir actes, primer curs i conciliació de codis. Són esborranys: no s’ha enviat res. No cal informació personal d’alumnat o famílies.

Vigència i geometries: es mantenen les correccions de V9–V11 i els 73 punts de centre. Picasoques: el mapa del web és una consulta textual de l’adreça, no una coordenada de portal verificada. No es canvia el punt incorrecte del CSV ni s’assigna el portal 29 al 27. Figueretes: seu provisional sense coordenada contrastada. Els 75 codis no són 75 centres actius confirmats.

Validació: correspondència 75 codis, recomptes històrics preservats, taula d’auditoria, filtres de cerca/categoria, sintaxi JavaScript, enllaços locals, integritat ZIP i SHA256. Sense comprovació visual en navegador ni auditoria arxivística exhaustiva.
