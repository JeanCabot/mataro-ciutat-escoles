from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile
B=Path(__file__).parent;out=B/'mataro_escoles_v4';shutil.copytree(B/'mataro_escoles_v3',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,a):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(a[0]));w.writeheader();w.writerows(a)
F=read('fonts_historiques_v3.csv')
new=[('H09','Institut Alexandre Satorras — història','https://www.asatorras.cat/hist%C3%B2ria'),('H10','Escola Anxaneta — història','https://agora.xtec.cat/ceipanxaneta/lescola/historia/'),('H11','Escola Angeleta Ferrer — història','https://agora.xtec.cat/esc-angeletaferrer/lescola/historia/'),('H12','Ajuntament — inauguració Angeleta Ferrer, 27-02-2019','https://www.mataro.cat/ca/actualitat/noticies/2019/l2019escola-angeleta-ferrer-s2019inaugura?set_language=ca'),('H13','BOE-A-1979-5841 — Ordre de 08-01-1979','https://boe.es/diario_boe/txt.php?id=BOE-A-1979-5841'),('H14','Ajuntament — inici de curs 2017/2018','https://www.mataro.cat/ca/actualitat/noticies/2017/el-curs-escolar-2017-2018-comenca-amb-el-nou')]
for id,t,u in new:F.append({'id_font':id,'titol':t,'url':u,'consulta':'2026-11-18','tipus':'normativa primària' if id=='H13' else 'institucional','abast':'Llegir precisió i notes de cada esdeveniment'})
write('fonts_historiques_v4.csv',F);fm={r['id_font']:r for r in F}
E=read('esdeveniments_historics_v3.csv')
def ev(code,name,kind,d1,d2,precision,claim,f,notes='',loc=''):
 E.append({'id_esdeveniment':'HIST-'+str(len(E)+1).zfill(3),'id_entitat':'ENT-'+code,'codi_actual_referencia':code,'centre':name,'tipus':kind,'data_min':d1,'data_max':d2,'precisio':precision,'afirmacio':claim,'id_font':f,'font_url':fm[f]['url'],'localitzador':loc,'estat':'documentat en font institucional' if f!='H13' else 'documentat en disposició normativa','notes':notes})
ev('08021260','Institut Alexandre Satorras','constitucio_patronat','1958-10-20','1958-10-20','dia','Constitució del patronat del COPEM, precedent immediat de l’institut.','H09','No és data d’obertura de l’edifici actual; l’institut republicà de 1933/1934 es manté com a antecedent contextual, sense identificar-lo com la mateixa institució.','Els orígens de l’institut')
ev('08054113','Escola Anxaneta','titularitat','1987','1987','any','Pas de l’escola a la xarxa pública de la Generalitat.','H10','No és una fundació. La font esmenta una fusió posterior amb Ravalet, sense data; queda pendent de documentar.')
ev('08020905','Escola Angeleta Ferrer','cessament_us_seu','2012-11-08','2012-11-08','dia','Tancament de la seu de plaça de Cuba per problemes estructurals.','H11','La institució continua en espais provisionals de Torre Llauder; no es registra un tancament institucional.','Tancament i reallotjament')
ev('08020905','Escola Angeleta Ferrer','inici_us_seu','2017','2018','curs 2017/2018','Inici de l’activitat lectiva a Can Fàbregas del paper.','H12','La història del centre esmenta l’1 de setembre; s’adopta la precisió de curs de la font municipal per no confondre inici administratiu i classes.','Primer paràgraf de la notícia')
ev('08020905','Escola Angeleta Ferrer','inauguracio_oficial','2019-02-27','2019-02-27','dia','Inauguració oficial de la nova seu, posterior a l’inici d’activitat.','H12')
for code,name,street in [('08034734','Escola Camí del Mig','Camí del Mig, sense número'),('08034746','Escola Rocafonda','carrer Tàrrega; l’ordre també esmenta locals nous a ronda Sant Oleguer')]:
 ev(code,name,'constitucio_administrativa','1979-01-08','1979-01-08','data_ordre','Constitució del col·legi nacional '+name.replace('Escola ','')+'.','H13','Ordre publicada el 24-02-1979. No fixa per si sola el primer dia de classe. Adreça al text: '+street+'.','Apartat Primer, municipi Mataró')
ev('08075712','Institut Les Cinc Sénies','inici_activitat','2017','2018','curs 2017/2018','Posada en marxa del nou institut amb tres grups de primer d’ESO.','H14','Notícia de 06-09-2017 que anuncia l’inici de curs; no equival a una inauguració d’edifici definitiu.')
E.sort(key=lambda r:r['data_min']);write('esdeveniments_historics_v4.csv',E)
# No es canvia l’any fundacional si només s’ha acreditat una fita administrativa.
a=read('mataro_centres_2026_2027.csv')
for r in a:
 ee=[e for e in E if e['codi_actual_referencia']==r['codi_centre']]
 r['nombre_fites_documentades']=len(ee)
 if ee:r['estat_recerca_historica']='fites documentades; història parcial'
 if r['codi_centre']=='08021260':r.update(tipus_data_origen='patronat del precedent COPEM',origen_data_min='1958-10-20',origen_data_max='1958-10-20',fundacio_any='',fundacio_font=fm['H09']['url'])
 if r['codi_centre'] in ['08034734','08034746']:r.update(tipus_data_origen='constitució administrativa; no primer dia de classe',origen_data_min='1979-01-08',origen_data_max='1979-01-08',fundacio_any='',fundacio_font=fm['H13']['url'])
 if r['codi_centre']=='08075712':r.update(tipus_data_origen='inici per curs',origen_data_min='2017',origen_data_max='2018',fundacio_any='',fundacio_font=fm['H14']['url'])
write('mataro_centres_2026_2027.csv',a)
g=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in g['features']:f['properties']=next(r for r in a if r['codi_centre']==f['properties']['codi_centre'])
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(g,ensure_ascii=False,indent=2))
write('ocupacions_angeleta_ferrer_v4.csv',[
{'codi_centre':'08020905','seu':'Plaça de Cuba','inici':'desconegut','final':'2012-11-08','precisio':'final d’ús documentat; inici desconegut','font':'H11','geometria':'pendent de contrast','nota':'No s’usa 1931 com a fundació: és adquisició de l’edifici per a un altre ús educatiu.'},
{'codi_centre':'08020905','seu':'Espais de l’Escola Torre Llauder','inici':'després del tancament de novembre de 2012','final':'abans de l’activitat del curs 2017/2018 a la nova seu','precisio':'interval documental; sense dia exacte','font':'H11 | H12','geometria':'pendent de contrast històric','nota':'Seu compartida, no fusió de centres.'},
{'codi_centre':'08020905','seu':'Can Fàbregas del paper','inici':'curs 2017/2018','final':'observada al cens 2026/2027','precisio':'inici per curs; final és observació, no tancament','font':'H12 | CSV Generalitat','geometria':'punt actual del registre','nota':'Inauguració oficial 27-02-2019, posterior a l’ús lectiu.'}])
write('cua_historica_v4.csv',[
{'centre':'Anxaneta','pendent':'Documentar fundació de 1965 amb bibliografia o arxiu; datar trasllat a Solís i fusió amb Ravalet','pista':'Història del centre, Museu Arxiu de Santa Maria i premsa','criteri':'No afegir una data exacta només per aniversaris'},
{'centre':'Satorras','pendent':'Datar seus del COPEM i trasllat a l’edifici actual','pista':'Web del centre i Mataró i l’ensenyament','criteri':'No identificar automàticament institut republicà i Satorras'},
{'centre':'Camí del Mig i Rocafonda','pendent':'Contrastar primer ús 1978/1979 i correspondència de locals del BOE amb seus actuals','pista':'25 anys d’escola pública 1978–2003, Ajuntament','criteri':'Distingir data d’ordre, publicació i activitat'},
{'centre':'Angeleta Ferrer','pendent':'Documentar origen de Mare de Déu del Pilar i geolocalitzar seus anteriors','pista':'Arxiu municipal; història del centre','criteri':'Data d’adquisició d’un edifici no és fundació escolar'}])
# Cronologia amb filtre per centre i selector temporal.
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['precisio'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(fm[e['id_font']]['titol'])+'</a></p></article>' for e in E)
names=sorted({(e['codi_actual_referencia'],e['centre']) for e in E},key=lambda x:x[1])
opts=''.join('<option value="'+c+'">'+html.escape(n)+'</option>' for c,n in names)
chron='''<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Mataró · Cronologia educativa V4</title><style>body{max-width:920px;margin:35px auto;padding:0 20px;font:16px system-ui;background:#f5f1e8;color:#223b39}h1{font:34px Georgia}article{background:white;border-left:4px solid #216c5a;margin:15px 0;padding:18px}small{display:block;line-height:1.5}a{color:#16665c}input{width:100%}select{padding:10px;margin-bottom:20px;max-width:100%}</style><a href="index.html">← Mapa actual</a><h1>Mataró · Cronologia educativa</h1><p>21 fites documentades de 10 centres. Selecció inicial i parcial. El mapa mostra les seus actuals; aquesta cronologia no és un cens de centres actius a cada any.</p><label for="centre">Centre</label><select id="centre"><option value="">Tots els centres documentats</option>'''+opts+'''</select><br><label for="year">Fites amb inici fins a <b id="label">2026</b></label><input id="year" type="range" min="1737" max="2026" value="2026"><p id="n" role="status"></p>'''+items+'''<script>function paint(){let y=+document.getElementById('year').value,c=document.getElementById('centre').value,n=0;document.getElementById('label').textContent=y;document.querySelectorAll('article').forEach(a=>{a.hidden=+a.dataset.year>y||(c&&a.dataset.code!==c);if(!a.hidden)n++});document.getElementById('n').textContent=n+' fites visibles. Els cursos es mostren des del primer any del seu interval; no són dates exactes.'}document.getElementById('year').addEventListener('input',paint);document.getElementById('centre').addEventListener('change',paint);paint();</script></html>'''
(out/'cronologia.html').write_text(chron)
page=(out/'index.html').read_text().replace('versió 3','versió 4').replace('Cronologia documentada · 13 fites','Cronologia documentada · 21 fites')
page=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',page,count=1,flags=re.S)
(out/'index.html').write_text(page)
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=4,fites_historiques=21,centres_amb_fites=10,fites_noves_v4=8)
(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V4.md').write_text('''# Mataró, ciutat d’escoles — V4
Guia vigent. Paquet acumulatiu de 18-11-2026, amb 75 centres actuals i 21 fites de 10 centres (8 noves). Conserva CSV, fonts i dades de versions anteriors amb noms de versió; els fitxers històrics vigents són els V4.

Obriu index.html per al mapa contemporani i cronologia.html per a la cronologia amb filtre per centre i any. El mapa requereix connexió; la llista i la cronologia estan incorporades als fitxers.

## Aportacions
- Satorras: constitució del patronat COPEM, 20-10-1958. No s’assimila automàticament a l’institut republicà de 1933/1934 ni es dona per fundada la seu actual el 1958.
- Anxaneta: pas a la xarxa pública el 1987; la fundació i els trasllats requereixen recerca addicional. No es presenta 1987 com a origen escolar.
- Camí del Mig i Rocafonda: ordre de constitució de 08-01-1979 (BOE publicat el 24-02-1979). Dates administratives, no d’inici de classes. El text BOE conté adreces que cal conciliar.
- Angeleta Ferrer: tancament de la seu de plaça de Cuba el 08-11-2012, continuïtat provisional a Torre Llauder, activitat a Can Fàbregas el curs 2017/2018 i inauguració oficial el 27-02-2019. La precisió del curs evita confondre el dia administratiu d’inici de setembre amb el primer dia lectiu.
- Les Cinc Sénies: posada en marxa el curs 2017/2018; no és una inauguració d’edifici definitiu.

ocupacions_angeleta_ferrer_v4.csv inicia el model d’ocupacions amb límits coneguts i desconeguts. És una taula documental; no s’han afegit geometries històriques no verificades. Els casos sense data fundacional segueixen sense any de fundació al cens.

Validació: 75 codis actuals sense duplicats; 21 identificadors d’esdeveniment únics; 10 centres amb fites; referències de fonts comprovades per codi; CSV i GeoJSON coherents; JavaScript comprovat sintàcticament. El visor no s’ha sotmès a una prova visual de navegador en aquesta fase.

Fonts recuperades en línia; la majoria són històries institucionals, amb el BOE com a font normativa primària. La interpretació dels antecedents, els canvis de codi i la vigència dels edificis continua requerint contrast. Picasoques segueix pendent d’una coordenada exacta. No s’ha modificat cap web pública ni repositori amb aquesta ampliació.
''')
shutil.copy2(__file__,out/'amplia_mataro_v4.py')
assert len(a)==75 and len(E)==21 and len(names)==10 and len({e['id_esdeveniment'] for e in E})==21
assert all(e['id_font'] in fm for e in E)
for n in ['index.html','cronologia.html']:
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',(out/n).read_text(),re.S)):Path('/tmp/v4_'+n+str(i)+'.js').write_text(s)
m={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'}
(out/'SHA256.json').write_text(json.dumps(m,indent=2))
zp=B/'Mataro_ciutat_escoles_V4_21_fites_2026-11-18.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v4/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(zp)
