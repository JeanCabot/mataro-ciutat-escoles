# V28 · Cronologia al mapa

Obre index.html. Arrossega la barra inferior per consultar els centres que tenen documentada alguna fita fins a l’any seleccionat. Es fan servir les ubicacions del registre actual. Clica els punts per obrir les fitxes. Sobre el projecte obre la introducció separada.
