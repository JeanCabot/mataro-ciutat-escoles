# Contrast documental V23 — Angeleta Ferrer i l’escola de la Sra. Pilar

Dues fites noves; cap camp d’origen nou. 167 fites, 63 camps informats i 12 buits. L’objectiu d’acreditar els 17 orígens no està completat.

## La primària anterior a l’institut
La història publicada per Germanes Bertomeu (H46) descriu una escola graduada de nenes al carrer Sant Cugat, dirigida per Pilar Bertomeu i, després, per Conxita. Situa el trasllat a l’antic cafè La Unió de la plaça de Cuba i el nom Nuestra Señora del Pilar el 1940. És una fita de localització i denominació d’una escola ja existent; no és fundació. La història d’Angeleta Ferrer (H11) confirma l’ús de l’edifici per la primària Pilar, però cal provar la continuïtat institucional i del codi actual.
No s’equipara aquesta escola antiga al centre de Rocafonda inaugurat el 1969 amb el nom Germanes Bertomeu. La coincidència de mestres o d’homenatge no transfereix automàticament codis i dates.

## Correcció: convocatòria, no acord aprovat
La pàgina municipal del Ple de 08-02-2001 és una ordre del dia, dictada per Decret 737/2001 de 05-02-2001. El punt 27 proposa canviar Mare de Déu del Pilar per Angeleta Ferrer. No conté el debat, el resultat de la votació ni la resolució d’Ensenyament. La V22 l’havia descrit al dossier com un acord localitzat: aquesta qualificació era excessiva i es corregeix. El camp d’origen i les dates de canvi efectiu del nom no s’omplen a partir d’aquesta convocatòria.
El cos de la convocatòria conté una menció a 2000; es conserva la data del decret 2001, coherent amb el títol i l’assumpte. La data web de 2003 no és data del Ple.

## Documentació que ara cal cercar
Expedient de l’escola graduada de nenes del carrer Sant Cugat; expedient de trasllat de 1940; continuïtat amb el codi 08020905; acta completa de 08-02-2001 i resolució de canvi de nom. La petició concreta s’ha actualitzat a consultes_documentals_v23.csv. No s’ha enviat.

## Altres vies contrastades
Cerques per Dúnia i Heidi Consegal, Peques/Acuarella, Picasoques/Pica-soques i Nemomarlin no han aportat cap autorització inicial nova atribuïble inequívocament. Els resultats són directoris, presències i actes ja coneguts. No se’n dedueix una data ni inexistència de l’expedient. Les cerques del llibre Una escola avançada continuen portant a la notícia municipal de 2007, no al text complet. No es declara consultat el llibre.

## Fitxers vigents
Base CSV i GeoJSON; esdeveniments_historics_v23.csv, fonts_historiques_v23.csv, auditoria_origens_v23.csv, revisio_17_camps_v23.csv, registre_recerca_v23.csv, consultes_documentals_v23.csv i resum_auditoria.json. Els fitxers V22 i anteriors són checkpoints; no sumar-los. Es conserven les consultes de la V22 per als altres centres, sense presentar-les com a noves verificacions.
