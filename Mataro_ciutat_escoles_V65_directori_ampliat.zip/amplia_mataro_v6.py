from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile
B=Path(__file__).parent;out=B/'mataro_escoles_v6';shutil.copytree(B/'mataro_escoles_v5',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,a):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(a[0]));w.writeheader();w.writerows(a)
F=read('fonts_historiques_v5.csv')
new=[('H18','Escola Balmes — història','https://agora.xtec.cat/esc-balmes-mataro/lescola/historia/'),('H19','Ajuntament — Balmes al directori municipal','https://www.mataro.cat/ca/temes/educacio/e-obligatoria-3-16-anys/directori-de-centres/ensenyament-concertat-1/ensenyament-concertat-balmes?set_language=ca'),('H20','Cor de Maria — breu història','https://www.cordemariamataro.cat/breu-historia-i-caracteristiques-del-centre/'),('H21','Ajuntament — Salesians, Medalla de la Ciutat','https://www.mataro.cat/ca/actualitat/noticies/2005/el-col-legi-salesia-sant-antoni-de-padua-rep-la'),('H22','GEM — presentació','https://escolagem.cat/lescola/'),('H23','UB — Inventari del Fons GEM','https://diposit.ub.edu/bitstreams/c056028f-04dd-47e0-8412-724ad15da2b6/download'),('H24','GEM — contacte i dues adreces','https://escolagem.cat/contacta/')]
for id,t,u in new:F.append({'id_font':id,'titol':t,'url':u,'consulta':'2026-11-18','tipus':'arxivística universitària' if id=='H23' else 'institucional','abast':'H18 consultada mitjançant índex de cerca; accés directe 403. Data també corroborada a H19. H20 conté discrepància interna 3/4.' if id in ['H18','H20'] else 'Font publicada; vegeu límits de cada afirmació'})
write('fonts_historiques_v6.csv',F);fm={r['id_font']:r for r in F}
E=read('esdeveniments_historics_v5.csv')
def ev(code,name,kind,date,precision,claim,f,notes='',loc=''):
 E.append({'id_esdeveniment':'HIST-'+str(len(E)+1).zfill(3),'id_entitat':'ENT-'+code,'codi_actual_referencia':code,'centre':name,'tipus':kind,'data_min':date,'data_max':date,'precisio':precision,'afirmacio':claim,'id_font':f,'font_url':fm[f]['url'],'localitzador':loc,'estat':'documentat en font institucional','notes':notes})
ev('08021016','Balmes','fundacio','1896','any','Origen de l’Escola Balmes a Mataró.','H19','La seva situació concertada contemporània no es retroprojecta a 1896.')
ev('08021119','Cor de Maria','fundacio_comunitat_educativa','1861-11-19','dia','Fundació de la comunitat educativa del Cor de Maria a Mataró.','H20','La data no és l’ocupació de la seu actual. El número de la primera seu d’Argentona és discrepant dins la mateixa font.','Passatges de fundació i primera ubicació')
ev('08021089','Sant Antoni de Pàdua — Salesians','inauguracio_collegi','1905-04-24','dia','Inauguració del col·legi salesià de Sant Antoni de Pàdua.','H21','La font dona inauguració del col·legi; no s’hi afegeix una data diferent de primer dia lectiu.','Últim paràgraf')
ev('08021168','GEM','inici_projecte','1966','any','Inici del projecte educatiu GEM.','H22','Corroborat per l’inventari del fons GEM de la UB (H23).')
ev('08021168','GEM','inscripcio_associacio','1967-04','mes','Inscripció de l’associació i visat dels estatuts.','H23','És una fita jurídica diferenciada de l’inici educatiu de 1966.','Pàgina física 3 del PDF; pàgina interna 1 de 5')
E.sort(key=lambda e:e['data_min']);write('esdeveniments_historics_v6.csv',E)
a=read('mataro_centres_2026_2027.csv')
updates={'08021016':('1896','H19','fundació'),'08021119':('1861-11-19','H20','fundació de comunitat educativa'),'08021089':('1905-04-24','H21','inauguració del col·legi'),'08021168':('1966','H22','inici del projecte')}
for r in a:
 if r['codi_centre'] in updates:
  d,f,k=updates[r['codi_centre']];r.update(fundacio_any=d[:4] if k in ['fundació','fundació de comunitat educativa'] else '',fundacio_font=fm[f]['url'],tipus_data_origen=k,origen_data_min=d,origen_data_max=d,estat_recerca_historica='fites documentades; seus històriques pendents de completar')
 r['nombre_fites_documentades']=len([e for e in E if e['codi_actual_referencia']==r['codi_centre']])
write('mataro_centres_2026_2027.csv',a)
g=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in g['features']:f['properties']=next(r for r in a if r['codi_centre']==f['properties']['codi_centre'])
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(g,ensure_ascii=False,indent=2))
# Seu addicional confirmada, sense derivar coordenades del centre de vista d’un iframe.
seats=read('mataro_seus_observades.csv');s=dict.fromkeys(seats[0],'');s.update(id_seu_observada='SEU-08021168-PETIT',codi_centre='08021168',nom_centre='GEM',etapa_seu='GEM Petit; assignació d’etapes pendent de contrast específic',adreca='Passeig Cabanellas, 23',curs_observacio='2026/2027',estat='adreça documentada al web consultat; dates d’ocupació desconegudes',font='Web de contacte GEM, consulta 18-11-2026',font_verificacio='H24',control_coordenades='pendent de geocodificació; no derivada del centre de vista del mapa incrustat')
seats.append(s);write('mataro_seus_observades.csv',seats)
write('discrepancies_i_pistes_v6.csv',[
{'id':'D01','centre':'Cor de Maria','tema':'primera seu','dada_a':'Carrer d’Argentona 3','dada_b':'Carrer d’Argentona 4','font':'H20','decisio':'No fixar portal ni coordenada. Contrast pendent amb padró, arxiu o monografia.'},
{'id':'D02','centre':'GEM','tema':'adreça actual principal','dada_a':'Àvila 9–45, registre Generalitat','dada_b':'Àvila 9–43, web del centre','font':'CSV | H24','decisio':'Conservar l’adreça original; discrepància de rang pendent de contrast. No duplicar seu.'},
{'id':'D03','centre':'GEM Petit','tema':'coordenada','dada_a':'Adreça confirmada: passeig Cabanellas 23','dada_b':'Dos mapes incrustats comparteixen centre de vista','font':'H24','decisio':'No emprar el centre de vista com a coordenada del lloc.'}])
write('pistes_arxiu_v6.csv',[{'centre':'GEM','repositori':'CRAI Biblioteca Pavelló de la República — UB','url':'https://diposit.ub.edu/items/cf2ff02c-8d4f-4b85-8b74-8107a178da99','document':'Inventari del Fons GEM, Olga Giralt, 2014','contingut':'Documentació interna, informes, correspondència i circulars','us_previst':'Investigar trasllats, primers locals i canvis jurídics; inventari no equival a consulta de cada document.'}])
# Nova cronologia i filtre de 14 centres.
chron=(out/'cronologia.html').read_text();names=sorted({(e['codi_actual_referencia'],e['centre']) for e in E},key=lambda x:x[1])
opts='<option value="">Tots els centres documentats</option>'+''.join('<option value="'+c+'">'+html.escape(n)+'</option>' for c,n in names)
chron=re.sub(r'(<select id="centre">).*?(</select>)',lambda m:m[1]+opts+m[2],chron,count=1,flags=re.S)
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['precisio'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a target="_blank" rel="noopener" href="'+html.escape(e['font_url'],quote=True)+'">'+html.escape(fm[e['id_font']]['titol'])+'</a></p></article>' for e in E)
chron=re.sub(r'<article.*?</article>(?:<article.*?</article>)*',lambda m:items,chron,count=1,flags=re.S).replace('23 fites documentades de 10 centres','28 fites documentades de 14 centres').replace('V5','V6')
(out/'cronologia.html').write_text(chron)
idx=(out/'index.html').read_text().replace('versió 5','versió 6').replace('23 fites','28 fites')
idx=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',idx,count=1,flags=re.S)
(out/'index.html').write_text(idx)
# Vista de cobertura: mesura la recerca, no la qualitat dels centres.
coverage=[{'codi_centre':r['codi_centre'],'centre':r['nom'],'naturalesa_actual':r['naturalesa'],'fites_documentades':r['nombre_fites_documentades'],'estat':'iniciat' if int(r['nombre_fites_documentades']) else 'pendent','nota':'Cobertura documental del projecte; no avalua el centre'} for r in a]
write('cobertura_recerca_v6.csv',coverage)
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=6,fites_historiques=28,centres_amb_fites=14,seus_documentades=77,punts_seus=75,seus_sense_coordenada=['08078695 Picasoques','GEM Petit, passeig Cabanellas 23'])
(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V6.md').write_text('''# Mataró, ciutat d’escoles — V6
Guia vigent, 18-11-2026. Paquet acumulatiu.

75 centres actuals; 77 localitzacions registrals o seus actuals conegudes, de les quals 75 tenen punt. 28 fites de 14 centres: 5 fites noves de 4 centres privats. GEM Petit s’afegeix al catàleg de seus sense coordenada; no incrementa el nombre de centres.

## Novetats
Balmes: origen el 1896, corroborat al directori municipal i web escolar. Cor de Maria: comunitat educativa a Mataró el 19-11-1861; la primera adreça és contradictòria al mateix web (Argentona 3/4), per tant sense punt històric. Salesians: inauguració del col·legi 24-04-1905 segons Ajuntament. GEM: inici del projecte 1966 i inscripció de l’associació abril 1967, segons presentació escolar i inventari UB.

No es presenta un concert educatiu actual com a situació històrica de 1861 o 1896. El camp concert continua pendent per ensenyament i període. Les dates d’inauguració o projecte mantenen la seva categoria, no es converteixen totes en fundacions.

Hi ha un fons GEM al CRAI Biblioteca del Pavelló de la República, amb inventari públic. És una pista arxivística per a més recerca; no s’han examinat encara els documents individuals del fons. GEM també publica una adreça a Cabanellas 23 (GEM Petit), sense data d’inici. Àvila figura 9–45 al CSV i 9–43 al web: rang conservat i discrepància registrada. Els dos iframes de mapes comparteixen centre de vista, que no s’ha confós amb coordenada del segon centre.

Fitxers vigents: fonts_historiques_v6.csv; esdeveniments_historics_v6.csv; mataro_centres_2026_2027.csv/.geojson; mataro_seus_observades.csv; cobertura_recerca_v6.csv; discrepancies_i_pistes_v6.csv. Els fitxers amb versions anteriors es conserven com a antecedents. El GeoJSON de seus V2 continua incloent només les 75 geometries disponibles (GEM Petit no té punt).

Obriu index.html (cens actual), cronologia.html (28 fites, 14 centres) o angeleta-ferrer.html (cas de tres seus). Mapes amb connexió a Internet. El mapa general no és un cens històric de centres actius per any. Cap publicació al web feta en aquesta fase.

Validació: 75 codis sense duplicats; 28 esdeveniments únics; 14 codis amb fites; 77 identificadors de seu; referències de fonts íntegres i GeoJSON sincronitzat amb el cens. Comprovació sintàctica JavaScript, sense inspecció visual de navegador.
''')
shutil.copy2(__file__,out/'amplia_mataro_v6.py')
assert len(a)==75 and len(E)==28 and len(names)==14 and len(seats)==77 and len({s['id_seu_observada'] for s in seats})==77
assert len({e['id_esdeveniment'] for e in E})==28 and all(e['id_font'] in fm for e in E)
for n in ['index.html','cronologia.html']:
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',(out/n).read_text(),re.S)):Path('/tmp/v6_'+n+str(i)+'.js').write_text(s)
m={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(m,indent=2))
zp=B/'Mataro_ciutat_escoles_V6_28_fites_2026-11-18.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v6/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(zp)
