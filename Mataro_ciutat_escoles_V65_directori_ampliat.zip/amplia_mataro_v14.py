from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile,collections,subprocess
B=Path(__file__).parent;out=B/'mataro_escoles_v14';shutil.copytree(B/'mataro_escoles_v13',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,rows):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
a=read('mataro_centres_2026_2027.csv');am={r['codi_centre']:r for r in a};E=read('esdeveniments_historics_v13.csv');F=read('fonts_historiques_v13.csv');fm={r['id_font']:r for r in F}
def src(i,t,u,typ):
 r=dict(id_font=i,titol=t,url=u,consulta='2026-11-18',tipus=typ,abast='Fets i límits indicats en les fites i la revisió');F.append(r);fm[i]=r
src('H95','Fundació el Maresme — glosa històrica de Jaume Calsapeu, 2026','https://www.fundaciomaresme.cat/wp-content/uploads/2026/02/Glosa-de-la-historia-de-la-Fundacio-Maresme_Jaume-Calsapeu_20260206.pdf','història de la institució predecessora; relat retrospectiu')
src('H96','DOGC — ENS/2463/2016, obertura Cenafe Mataró','https://portaldogc.gencat.cat/utilsEADOP/AppJava/PdfProviderServlet?documentId=762690&type=01&language=ca_ES','document oficial, text íntegre')
src('H97','Angeleta Ferrer — història publicada pel centre','https://agora.xtec.cat/esc-angeletaferrer/lescola/historia/','relat institucional; dates de naturalesa diversa')
def ev(c,k,d,f,claim,loc,notes,end=None):
 E.append(dict(id_esdeveniment='HIST-'+str(max(int(x['id_esdeveniment'].split('-')[1]) for x in E)+1).zfill(3),id_entitat='ENT-'+c,codi_actual_referencia=c,centre=am[c]['nom'],tipus=k,data_min=d,data_max=end or d,precisio='curs' if end else 'any' if len(d)==4 else 'dia',afirmacio=claim,id_font=f,font_url=fm[f]['url'],localitzador=loc,estat='documentat; contrast parcial',notes=notes))


ev('08045227','obertura_predecessor','1966','H95','Obertura de l’escola Santa Bernadeta el curs 1966–1967, predecessora de Les Aigües.','p. 2, paràgraf de l’obertura','No és l’alta del codi públic actual. La mateixa font descriu la conversió en escola pública Les Aigües el 1990.',end='1967')
ev('08045227','inauguracio_predecessor','1966-10-26','H95','Inauguració oficial de l’escola Santa Bernadeta, segons la glosa històrica de la Fundació el Maresme.','p. 2, paràgraf següent a l’obertura','Acte diferent de l’obertura per curs; no es trasllada la data a l’edifici actual ni a l’alta del codi públic.')
ev('08075475','autoritzacio_obertura','2016-10-24','H96','Resolució ENS/2463/2016 d’autorització d’obertura de Cenafe Mataró, codi 08075475, a plaça Canigó 7.','DOGC 7242, 08-11-2016, p. 1, apartat 1','Data de resolució; no primer dia de classe. El canvi de titular de 2020 és una fita posterior.')
ev('08075475','efectes_autoritzacio_obertura','2016','H96','Efectes de l’autorització d’obertura de Cenafe des de l’inici del curs 2016–2017.','p. 1, després de la identificació del titular','Efectes legals diferenciats de resolució i publicació; no es fabrica data exacta d’inici de classes.',end='2017')
ev('08020905','pla_estrategic','2000','H97','Posada en marxa d’un pla estratègic per consolidar el centre, amb període 2000–2004.','Apartat Pla estratègic','La font indica pròrroga el 2005. No és una fundació; no s’atribueix a l’escola la construcció de l’edifici el 1892 ni l’ús com a institut el 1934.',end='2004')
for e in E:
 if e['id_esdeveniment']=='HIST-125':e['precisio']='període'
 if e['id_esdeveniment']=='HIST-088':
  assert e['codi_actual_referencia']=='08045227'
  e.update(data_min='1990-09-01',data_max='1990-09-01',precisio='dia',id_font='H95',font_url=fm['H95']['url'],afirmacio='Santa Bernadeta deixa el Patronat i esdevé l’escola pública d’educació especial Les Aigües l’1 de setembre de 1990.',localitzador='p. 4, paràgraf de la conversió',notes='Fita de V9 precisada amb la glosa de 2026; H56 conserva el relat institucional anterior. No és la primera obertura del predecessor ni una prova del dia d’ocupació de l’edifici actual.')
E.sort(key=lambda e:(e['data_min'],e['id_esdeveniment']));counts=collections.Counter(e['codi_actual_referencia'] for e in E);assert len(E)==125 and len(counts)==73
write('esdeveniments_historics_v14.csv',E);write('fonts_historiques_v14.csv',F)
origin_ids={'08045227':'HIST-121','08075475':'HIST-123','08050235':'HIST-090','08034357':'HIST-075','08078877':'HIST-115'}
changes=[]
for r in a:
 c=r['codi_centre'];r['nombre_fites_documentades']=counts[c]
 if c in origin_ids:
  e=next(x for x in E if x['id_esdeveniment']==origin_ids[c]);assert e['codi_actual_referencia']==c
  changes.append(dict(codi_centre=c,centre=r['nom'],tipus_anterior=r['tipus_data_origen'],data_anterior=r['origen_data_min'],nou_tipus=e['tipus'],nova_data_min=e['data_min'],nova_data_max=e['data_max'],id_esdeveniment=e['id_esdeveniment'],id_font=e['id_font'],limit=e['notes']))
  r.update(tipus_data_origen=e['tipus'],origen_data_min=e['data_min'],origen_data_max=e['data_max'],fundacio_any='',fundacio_font=e['font_url'],estat_recerca_historica='data relacionada amb l’origen documentada; tipus i límits explícits')
  if c=='08045227':r['tipus_data_origen']='obertura del predecessor Santa Bernadeta; codi públic posterior'
  if c=='08075475':r['tipus_data_origen']='autorització d’obertura; primeres classes pendents'
  if c=='08078877':r['tipus_data_origen']='consolidació de projecte; autorització del codi pendent'
  if c=='08034357':r['tipus_data_origen']='antecedent d’aulari; dècada, no any exacte'
write('revisio_cinc_origens_v14.csv',changes);write('mataro_centres_2026_2027.csv',a)
g=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in g['features']:f['properties']=am[f['properties']['codi_centre']]
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(g,ensure_ascii=False,indent=2))
# Audit is rebuilt from the updated canonical data and events.
by=collections.defaultdict(list)
for e in E:by[e['codi_actual_referencia']].append(e)
audit=[]
for r in a:
 c=r['codi_centre'];es=sorted(by[c],key=lambda e:(e['data_min'],e['id_esdeveniment']));first=es[0] if es else {};typ=r['tipus_data_origen'];d=r['origen_data_min']
 if not d:cat='camp d’origen buit; recerca pendent'
 elif 'antecedent' in typ or 'patronat' in typ or 'predecessor' in typ:cat='antecedent; no obertura del centre actual'
 elif 'autorització' in typ:cat='autorització d’obertura; no primeres classes'
 elif 'administrativa' in typ or 'creació' in typ or 'transformació' in typ or typ=='creacio_escola':cat='constitució o creació; classes pendents de distingir'
 elif 'projecte' in typ:cat='inici de projecte; no autorització del codi'
 else:cat='data d’origen declarada; contrast segons font'
 specific={
 '08065123':'Conciliar codis 08065123 i 08021089 i trobar autorització pròpia. No heretar 1905 ni 2004.',
 '08078695':'Autorització i primer curs pendents. Corregir coordenada del CSV només amb portal 27 documentat.',
 '08073946':'Autorització i efectes legals confirmats; primer curs real i relació amb Pinotxo pendents.',
 '08078877':'2012 és consolidació del projecte segons la directora; alta del codi i autorització de cicles pendents.',
 '08056948':'2015 és actuació escolar; no és fundació ni autorització.',
 '08021181':'Conciliar 1968/1970: classes inicials, comunitat religiosa i actes d’inauguració.',
 }
 audit.append(dict(codi_centre=c,centre=r['nom'],fites_documentades=len(es),categoria_origen=cat,tipus_data_origen=typ,origen_data_min=d,origen_data_max=r['origen_data_max'],font_origen=r['fundacio_font'],primera_fita_id=first.get('id_esdeveniment',''),primera_fita_data=first.get('data_min',''),primera_fita_tipus=first.get('tipus',''),primera_fita_font=first.get('font_url',''),control='Primera fita cronològica no equival a fundació.',tasca_prioritaria=specific.get(c,'Precisar què data la font d’origen i contrastar-la.' if d else 'Cercar origen del centre; no adoptar la primera fita com a fundació.')))
write('auditoria_origens_v14.csv',audit);stats=collections.Counter(x['categoria_origen'] for x in audit);norigin=sum(bool(x['origen_data_min']) for x in audit);assert norigin==51
# Candidates are extracted from documented events but do not silently overwrite canonical origins.
missing=[e for e in E if not next(r for r in a if r['codi_centre']==e['codi_actual_referencia'])['origen_data_min'] and e['tipus'] in {'origen_declarat','inauguracio_escola','antecedent_aulari','consolidacio_projecte_escolar','autoritzacio_obertura'}]
write('pistes_origen_per_revisar_v14.csv',[dict(codi_centre=e['codi_actual_referencia'],centre=e['centre'],id_esdeveniment=e['id_esdeveniment'],tipus=e['tipus'],data=e['data_min'],id_font=e['id_font'],afirmacio=e['afirmacio'],decisio='Candidat de revisió; no afegit al camp canònic d’origen automàticament.') for e in missing])
queries=[('CIDO','soques; Pica-Soques; Salesia; Salesians; Salesià','Sense nou acte atribuïble inequívocament als dos codis.','No prova que l’acte no existeixi; cercador de títols i indexació incompleta.'),('Web pública','08065123 autorització; Col·legi Salesià formació d’adults resolució','Retorna resolució de 2004 amb altre codi i llistats d’oferta ja coneguts.','No es converteix l’oferta en autorització inicial.'),('Web pública','Picasoques Mataró obertura; Pica-soques Mataró inauguració','Web del centre, directori i resultats homònims, sense data d’origen contrastada.','No s’atribueixen societats, revistes o escoles d’altres municipis.'),('Web oficial Picasoques','Contacte, ronda República 27','El mapa incrustat és una cerca textual de l’adreça.','No aporta una coordenada de portal verificada; no es corregeix geometria per inferència.')]
write('registre_recerca_v14.csv',[dict(data_consulta='2026-11-18',via=v,consulta=q,resultat=r,limit=l) for v,q,r,l in queries])
chron=(out/'cronologia.html').read_text();opts='<option value="">Tots els centres documentats</option>'+''.join('<option value="'+c+'">'+html.escape(n)+'</option>' for c,n in sorted({(e['codi_actual_referencia'],e['centre']) for e in E},key=lambda x:x[1]));chron=re.sub(r'(<select id="centre">).*?(</select>)',lambda m:m[1]+opts+m[2],chron,count=1,flags=re.S)
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['data_min']+'–'+e['data_max'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(fm[e['id_font']]['titol'])+' · '+html.escape(e['localitzador'])+'</a></p></article>' for e in E)
chron=re.sub(r'<article.*?</article>(?:<article.*?</article>)*',lambda m:items,chron,count=1,flags=re.S).replace('120 fites documentades de 73 dels 75 registres de base (97,3%)','125 fites documentades de 73 dels 75 registres de base (97,3%)').replace('V13','V14');(out/'cronologia.html').write_text(chron)
idx=(out/'index.html').read_text().replace('versió 13','versió 14').replace('120 fites','125 fites').replace('71 centres amb alguna fita documentada','73 centres amb alguna fita documentada').replace('71/75 registres · 94,7%','73/75 registres · 97,3%');idx=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',idx,count=1,flags=re.S);(out/'index.html').write_text(idx)
rows=''.join('<tr><td>'+html.escape(r['nom'])+'</td><td>'+str(counts[r['codi_centre']])+'</td><td>'+html.escape(r['estat_recerca_historica'])+'</td></tr>' for r in sorted(a,key=lambda r:r['nom']))
(out/'cobertura.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Cobertura V11</title><style>body{font:17px system-ui;max-width:980px;margin:40px auto;padding:20px;color:#243b35;background:#f7f5ed}table{border-collapse:collapse;width:100%}td,th{text-align:left;padding:10px;border-bottom:1px solid #ccc}a{color:#25634e}</style><h1>73 de 75 registres: 97,3%</h1><p>116 fites; històries parcials. Cobertura d’almenys una fita, de naturalesa diversa: no són 73 fundacions verificades. Gi: consolidació del projecte, sense data d’autorització del codi. Heidi: participació cultural, fundació pendent. La Fada: text íntegre i codi confirmats. Dos codis sense fita: Col·legi Salesià 08065123 i Picasoques. El denominador continua sent els 75 codis del CSV; no tots actius.</p><p><a href="index.html">Mapa</a> · <a href="cronologia.html">Cronologia</a> · <a href="revisio_pendents_v11.csv">Revisió</a> · <a href="evidencies_sense_fita_v11.csv">Dos casos sense fita</a></p><table><tr><th>Centre</th><th>Fites</th><th>Recerca</th></tr>'+rows+'</table></html>')
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=14,fites_historiques=125,centres_amb_fites=73,centres_pendents=2,cobertura_percent=97.33,centres_amb_fites_text_integre_o_narrativa=73,centres_amb_fites_nomes_metadades=0,centres_nous_v14=0,fites_noves_v14=5,camps_origen_nous_v14=5,nota='75 codis de base; vigència parcial. La Fada confirmada pel text íntegre. Cobertura de qualsevol fita; Gi consolidació de projecte i Heidi activitat cultural, sense fundació o autorització completa.');(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
style='<style>body{max-width:1200px;margin:32px auto;padding:20px;font:16px system-ui;color:#223b39;background:#f5f1e8}h1{font:32px Georgia}table{border-collapse:collapse;width:100%;background:white}td,th{text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid #ccd5ce}small{display:block;line-height:1.5}a{color:#16665c}input,select{padding:10px;margin:8px 8px 16px 0;max-width:100%;font:inherit}.scroll{overflow:auto}</style>'
rows=''.join('<tr data-search="'+html.escape(x['centre'].lower()+' '+x['codi_centre'],quote=True)+'" data-cat="'+html.escape(x['categoria_origen'],quote=True)+'"><td><b>'+html.escape(x['centre'])+'</b><small>'+x['codi_centre']+'</small></td><td>'+str(x['fites_documentades'])+'</td><td>'+html.escape(x['categoria_origen'])+'<small>'+html.escape(x['origen_data_min']+' '+x['tipus_data_origen'])+'</small></td><td>'+html.escape(x['primera_fita_data']+' '+x['primera_fita_tipus'])+'</td><td>'+html.escape(x['tasca_prioritaria'])+'</td></tr>' for x in sorted(audit,key=lambda x:x['centre']))
opts='<option value="">Totes les categories</option>'+''.join('<option>'+html.escape(c)+'</option>' for c in sorted(stats))
script="""const q=document.querySelector('#q'),cat=document.querySelector('#cat'),rows=[...document.querySelectorAll('tbody tr')];function filter(){let n=0;for(const r of rows){const show=r.dataset.search.includes(q.value.toLowerCase().trim())&&(!cat.value||r.dataset.cat===cat.value);r.hidden=!show;if(show)n++;}document.querySelector('#n').textContent=n+' registres';}q.addEventListener('input',filter);cat.addEventListener('change',filter);filter();"""
(out/'auditoria-origens.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Mataró · Auditoria d’orígens V14</title>'+style+'<a href="index.html">← Mapa</a> · <a href="cronologia.html">Cronologia</a><h1>Què sabem dels orígens?</h1><p><b>73/75 codis amb alguna fita · 125 fites. 51/75 tenen una data al camp d’origen; 24 el tenen buit.</b> Les 51 dates inclouen fundacions declarades, antecedents, constitucions administratives i inicis de projectes: no són 51 primers dies de classe verificats. El 97,3% mesura qualsevol fita, no la cobertura de fundacions.</p><p>La primera fita conservada és només la més antiga de les documentades al conjunt actual. No s’utilitza automàticament com a fundació ni com a inici d’ocupació de la seu del mapa. Els 75 són codis de la base registral; no tots actius confirmats.</p><p><a href="auditoria_origens_v14.csv">Dades de l’auditoria</a> · <a href="pistes_origen_per_revisar_v14.csv">Pistes d’origen</a> · <a href="registre_recerca_v14.csv">Registre de recerca</a> · <a href="pla_recerca_pendent_v12.md">Consultes documentals preparades</a></p><label for="q">Centre o codi </label><input id="q" type="search"><label for="cat"> Categoria </label><select id="cat">'+opts+'</select><p id="n"></p><div class="scroll"><table><thead><tr><th>Centre</th><th>Fites</th><th>Camp d’origen</th><th>Primera fita documentada</th><th>Tasca pendent</th></tr></thead><tbody>'+rows+'</tbody></table></div><script>'+script+'</script></html>')


rows=''.join('<tr><td>'+html.escape(r['nom'])+'</td><td>'+str(counts[r['codi_centre']])+'</td><td>'+html.escape(r['estat_recerca_historica'])+'</td></tr>' for r in sorted(a,key=lambda r:r['nom']))
(out/'cobertura.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Cobertura V14</title>'+style+'<h1>73/75 codis amb fites · 125 fites</h1><p>51 camps d’origen informats i 24 buits. Les dates inclouen antecedents, autoritzacions, inauguracions i projectes: no són fundacions totes verificades. Continuen pendents Col·legi Salesià i Picasoques. Els 75 codis no són tots centres actius confirmats.</p><p><a href="index.html">Mapa</a> · <a href="cronologia.html">Cronologia</a> · <a href="auditoria-origens.html">Orígens</a> · <a href="revisio_cinc_origens_v14.csv">Cinc camps revisats</a></p><table><tr><th>Centre</th><th>Fites</th><th>Recerca</th></tr>'+rows+'</table>')
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=14,fites_historiques=125,fites_noves_v14=5,fites_precisades_v14=1,codis_amb_camp_origen_informat=51,codis_sense_camp_origen=24,categories_auditoria_origen=dict(stats),nota_v14='Cenafe autorització 2016; Santa Bernadeta predecessor 1966–1967; Les Aigües conversió pública 01-09-1990. Cinc camps d’origen completats amb tipus explícit.');(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V14.md').write_text("""# Mataró, ciutat d’escoles — V14, 18-11-2026
Paquet acumulatiu. Obre index.html, cronologia.html i auditoria-origens.html. Sense publicació en línia.

125 fites, 73/75 codis amb alguna fita. 51 camps d’origen informats i 24 buits. Aquests camps no equivalen a 51 fundacions verificades: inclouen antecedents, autoritzacions, inauguracions, dates declarades i consolidació de projectes.

Cinc camps nous: Les Aigües (obertura del predecessor Santa Bernadeta el curs 1966–1967), Cenafe (autorització de 24-10-2016), Snoopy (origen declarat 1980 segons anunci conservat), Vista Alegre (antecedent d’aulari a la dècada 1970–1979) i Gi (consolidació del projecte el 2012 segons la directora). Els tres darrers reutilitzen fites existents i no generen nous esdeveniments. No es converteix cap dècada ni autorització en un primer dia de classes.

Les Aigües: glosa històrica de la Fundació el Maresme de 2026. Afegeix obertura de Santa Bernadeta el curs 1966–1967 i inauguració oficial el 26-10-1966. Precisa la conversió en escola pública Les Aigües l’1-09-1990 a la fita HIST-088, conservant-ne l’identificador. No implica que el codi públic actual existís el 1966 ni que l’edifici actual fos llavors ocupat. El relat institucional és retrospectiu; contrast amb documents contemporanis pendent.
Cenafe: text íntegre ENS/2463/2016 confirma codi 08075475 i plaça Canigó 7. Resolució 24-10-2016, publicació 08-11-2016, efectes des de l’inici del curs 2016–2017. No és el canvi de titular de 2020 ni prova de primeres classes. No s’afegeix una geometria nova.
Angeleta Ferrer: s’afegeix el pla estratègic 2000–2004 com a fita d’etapa; el camp d’origen segueix buit. La història del solar o de l’edifici no data automàticament la fundació de l’escola; altres dates del relat requereixen contrast.

Dades vigents: esdeveniments_historics_v14.csv, fonts_historiques_v14.csv, auditoria_origens_v14.csv, pistes_origen_per_revisar_v14.csv, revisio_cinc_origens_v14.csv i base canònica CSV/GeoJSON. Versions anteriors: checkpoints; no sumar registres. Es conserven mapa, cronologia, auditoria, proves i scripts. Consultes documentals de V12 encara sense enviar.

Continuen sense fita atribuïble Col·legi Salesià 08065123 i Picasoques 08078695. Les geometries i els avisos de vigència es mantenen: 73 punts de centre, 78 observacions de seu, 75 codis de base que no equivalen a 75 centres actius confirmats.

Validació de codis, fonts, intervals, dades del visor, GeoJSON, 125 articles de cronologia, 75 files d’auditoria, sintaxi JavaScript, enllaços locals, SHA256 i integritat ZIP. Sense inspecció visual en navegador ni auditoria arxivística exhaustiva.
""")
D=out/'documents_v14';D.mkdir(exist_ok=True)
for ext in ['pdf','txt']:
 p=Path('/tmp/cenafe14.'+ext)
 if p.exists():shutil.copy2(p,D/p.name)
shutil.copy2(__file__,out/'amplia_mataro_v14.py')
assert len(audit)==75 and sum(x['fites_documentades'] for x in audit)==125 and norigin==51 and len(counts)==73
assert len({e['id_esdeveniment'] for e in E})==125 and chron.count('<article data-year=')==125
assert all(e['id_font'] in fm and e['data_min']<=e['data_max'] for e in E)
for name in ['index.html','cronologia.html','cobertura.html','auditoria-origens.html']:
 text=(out/name).read_text()
 for link in re.findall(r'href="([^"#]+)"',text):
  if not link.startswith(('http:','https:',chr(39))):assert (out/link).exists(),link
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',text,re.S)):
  p=Path('/tmp')/('v14_'+name+str(i)+'.js');p.write_text(s);subprocess.run(['node','--check',str(p)],check=True,capture_output=True)
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(manifest,indent=2))
zp=B/'Mataro_ciutat_escoles_V14_origens_i_autoritzacions_2026-11-18.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v14/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(json.dumps(dict(zip=str(zp),fites=len(E),codis=len(counts),camps_origen=norigin,pendents=75-norigin)))
