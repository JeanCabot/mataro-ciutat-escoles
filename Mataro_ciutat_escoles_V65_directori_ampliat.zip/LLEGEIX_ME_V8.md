# Mataró, ciutat d’escoles — V8
Guia vigent del paquet acumulatiu, 18-11-2026.

Objectiu assolit: 38 dels 75 centres del registre 2026–2027 tenen almenys una fita documentada (50,7%). 37 pendents. 64 fites, 28 noves; 20 centres incorporats. No equival a 38 històries completes. Inclou obertures, trasllats, usos compartits, canvis de tipus de centre i una commemoració; no s’inventen fundacions.

Obrir index.html (mapa), cronologia.html (fites) o cobertura.html (llistat dels 75). Els mapes requereixen Internet. Aquesta fase no publica cap web.

## Fitxers vigents
esdeveniments_historics_v8.csv; fonts_historiques_v8.csv; cobertura_recerca_v8.csv; centres_incorporats_v8.csv; mataro_centres_2026_2027.csv/.geojson. Les versions anteriors són antecedents acumulatius i no s’han de sumar. Les taules de seus continuen en estat V7; no s’ha inferit nova geometria a partir de les fites d’aquesta fase.

## Criteri i limitacions
Denominador: codis de centre actuals, no edificis ni entitats històriques. Damià Campeny i CFA Can Marfà tenen codis diferents i comparteixen un fet espacial; es relaciona amb tots dos. EOI incorpora l’ús compartit amb batxillerat de Damià, sense atribuir-li una fundació. Antonio Machado incorpora seu definitiva d’abril de 2007. Peramàs incorpora la commemoració publicada de 2021–2022; no s’ha restat 50 per fabricar un dia d’obertura. Els instituts escola tenen canvi de tipologia de 2018–2019, no origen de les escoles anteriors. Cirera: origen 1997 segons el centre; antecedents de la fusió pendents de contrast. La Llàntia: la narració retrospectiva descriu diverses fases espacials; s’han conservat separades. Montserrat Solà: discrepància de número al Camí Ral pendent; no es fixa un punt històric.

Es mantenen els 75 centres, 74 punts de centre i 77 seus actuals conegudes (75 amb geometria) del paquet anterior. La cronologia filtra esdeveniments pel primer any del curs: no representa totes les escoles actives en cada any. Origen desconegut continua desconegut encara que hi hagi una altra fita.

Validats recomptes, codis, fonts, intervals, GeoJSON, dades del visor i integritat ZIP. Sintaxi JavaScript comprovada. Sense inspecció visual amb navegador ni verificació arxivística completa. Fonts institucionals amb URL i localitzador a cada fita.
