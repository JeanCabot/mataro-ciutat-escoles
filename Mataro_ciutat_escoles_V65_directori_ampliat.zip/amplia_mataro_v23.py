from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile,collections,subprocess
B=Path(__file__).parent;out=B/'mataro_escoles_v23';shutil.copytree(B/'mataro_escoles_v22',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,rows):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['codi_centre','centre','id_esdeveniment','tipus','data','id_font','afirmacio','decisio']);w.writeheader();w.writerows(rows)
a=read('mataro_centres_2026_2027.csv');am={r['codi_centre']:r for r in a};E=read('esdeveniments_historics_v22.csv');F=read('fonts_historiques_v22.csv');fm={r['id_font']:r for r in F}
def src(i,t,u,typ):
 r=dict(id_font=i,titol=t,url=u,consulta='2026-11-19',tipus=typ,abast='Fets i límits indicats en les fites i la revisió');F.append(r);fm[i]=r
def ev(c,k,d,f,claim,loc,notes,end=None):
 E.append(dict(id_esdeveniment='HIST-'+str(max(int(x['id_esdeveniment'].split('-')[1]) for x in E)+1).zfill(3),id_entitat='ENT-'+c,codi_actual_referencia=c,centre=am[c]['nom'],tipus=k,data_min=d,data_max=end or d,precisio='curs' if end else 'any' if len(d)==4 else 'dia',afirmacio=claim,id_font=f,font_url=fm[f]['url'],localitzador=loc,estat='documentat; contrast parcial',notes=notes))











src('H130','Ajuntament de Mataró — convocatòria del Ple de 8 de febrer de 2001','https://www.mataro.cat/ca/actualitat/reunions-municipals/reunions-del-1998-al-2002/ple-municipal-del-mes-de-febrer-8-2-2001','Ordre del dia, Decret 737/2001 de 5 de febrer; no acta ni acord adoptat')
fidx={f['id_font']:f for f in F}
fidx['H46']['consulta']='2026-11-19';fidx['H46']['abast']='Relat institucional consultat: escola graduada del carrer Sant Cugat, trasllat a plaça de Cuba el 1940 i nom Pilar; no acredita alta del codi actual.'
ev('08020905','trasllat_antecedent_continuitat_pendent','1940','H46','La història de Germanes Bertomeu situa el 1940 el trasllat de l’escola graduada de nenes a l’antic cafè La Unió de la plaça de Cuba i l’adopció del nom Nuestra Señora del Pilar.','Paràgraf sobre Conxita Bertomeu','Relat d’un trasllat d’una escola ja existent. Es relaciona amb l’antic nom i l’edifici d’Angeleta Ferrer, però la continuïtat institucional i registral resta per acreditar. No és la fundació de Germanes Bertomeu de 1969 ni d’Angeleta Ferrer; camp d’origen buit.')
ev('08020905','convocatoria_proposta_canvi_nom','2001-02-05','H130','El Decret municipal 737/2001, de 5 de febrer, inclou al punt 27 de l’ordre del dia del Ple convocat per al 8 de febrer el canvi de denominació del CEIP Mare de Déu del Pilar a CEIP Angeleta Ferrer.','Capçalera del decret i punt 27 de l’ordre del dia','Només s’ha consultat la convocatòria: no acredita aprovació del Ple ni resolució d’Ensenyament. El cos esmenta per error 2000, mentre títol, decret i assumpte indiquen 2001; la metadada web mostra una altra data de migració i no es pren com a data del fet.')
E.sort(key=lambda e:(e['data_min'],e['id_esdeveniment']));counts=collections.Counter(e['codi_actual_referencia'] for e in E)
assert len(E)==167 and len(counts)==75
write('esdeveniments_historics_v23.csv',E);write('fonts_historiques_v23.csv',F)
am['08020905']['estat_recerca_historica']='Trasllat d’un antecedent de primària el 1940 i proposta de nom el 2001 documentats; origen i continuïtat registral pendents.'
for r in a:r['nombre_fites_documentades']=counts[r['codi_centre']]
write('mataro_centres_2026_2027.csv',a)
g=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in g['features']:f['properties']=am[f['properties']['codi_centre']]
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(g,ensure_ascii=False,indent=2))
# Audit is rebuilt from the updated canonical data and events.
by=collections.defaultdict(list)
for e in E:by[e['codi_actual_referencia']].append(e)
audit=[]
for r in a:
 c=r['codi_centre'];es=sorted(by[c],key=lambda e:(e['data_min'],e['id_esdeveniment']));first=es[0] if es else {};typ=r['tipus_data_origen'];d=r['origen_data_min']
 if not d:cat='camp d’origen buit; recerca pendent'
 elif 'antecedent' in typ or 'patronat' in typ or 'predecessor' in typ:cat='antecedent; no obertura del centre actual'
 elif 'autorització' in typ:cat='autorització d’obertura; no primeres classes'
 elif 'administrativa' in typ or 'creació' in typ or 'transformació' in typ or typ=='creacio_escola':cat='constitució o creació; classes pendents de distingir'
 elif 'projecte' in typ:cat='inici de projecte; no autorització del codi'
 else:cat='data d’origen declarada; contrast segons font'
 specific={
 '08065123':'Conciliar codis 08065123 i 08021089 i trobar autorització pròpia. No heretar 1905 ni 2004.',
 '08078695':'Autorització i primer curs pendents. Corregir coordenada del CSV només amb portal 27 documentat.',
 '08073946':'Autorització i efectes legals confirmats; primer curs real i relació amb Pinotxo pendents.',
 '08078877':'2012 és consolidació del projecte segons la directora; alta del codi i autorització de cicles pendents.',
 '08056948':'2015 és actuació escolar; no és fundació ni autorització.',
 '08021181':'Conciliar 1968/1970: classes inicials, comunitat religiosa i actes d’inauguració.',
 }
 audit.append(dict(codi_centre=c,centre=r['nom'],fites_documentades=len(es),categoria_origen=cat,tipus_data_origen=typ,origen_data_min=d,origen_data_max=r['origen_data_max'],font_origen=r['fundacio_font'],primera_fita_id=first.get('id_esdeveniment',''),primera_fita_data=first.get('data_min',''),primera_fita_tipus=first.get('tipus',''),primera_fita_font=first.get('font_url',''),control='Primera fita cronològica no equival a fundació.',tasca_prioritaria=specific.get(c,'Precisar què data la font d’origen i contrastar-la.' if d else 'Cercar origen del centre; no adoptar la primera fita com a fundació.')))
write('auditoria_origens_v23.csv',audit);stats=collections.Counter(x['categoria_origen'] for x in audit);norigin=sum(bool(x['origen_data_min']) for x in audit);assert norigin==63
# Candidates are extracted from documented events but do not silently overwrite canonical origins.
missing=[e for e in E if not next(r for r in a if r['codi_centre']==e['codi_actual_referencia'])['origen_data_min'] and e['tipus'] in {'origen_declarat','inauguracio_escola','antecedent_aulari','consolidacio_projecte_escolar','autoritzacio_obertura'}]
write('pistes_origen_per_revisar_v23.csv',[dict(codi_centre=e['codi_actual_referencia'],centre=e['centre'],id_esdeveniment=e['id_esdeveniment'],tipus=e['tipus'],data=e['data_min'],id_font=e['id_font'],afirmacio=e['afirmacio'],decisio='Candidat de revisió; no afegit al camp canònic d’origen automàticament.') for e in missing])
chron=(out/'cronologia.html').read_text();opts='<option value="">Tots els centres documentats</option>'+''.join('<option value="'+c+'">'+html.escape(n)+'</option>' for c,n in sorted({(e['codi_actual_referencia'],e['centre']) for e in E},key=lambda x:x[1]));chron=re.sub(r'(<select id="centre">).*?(</select>)',lambda m:m[1]+opts+m[2],chron,count=1,flags=re.S)
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['data_min']+'–'+e['data_max'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(fm[e['id_font']]['titol'])+' · '+html.escape(e['localitzador'])+'</a></p></article>' for e in E)
chron=re.sub(r'<article.*?</article>(?:<article.*?</article>)*',lambda m:items,chron,count=1,flags=re.S).replace('151 fites documentades de 75 dels 75 registres de base (100%)','167 fites documentades de 75 dels 75 registres de base (100%)').replace('V22','V23').replace('165 fites','167 fites');(out/'cronologia.html').write_text(chron)
idx=(out/'index.html').read_text().replace('versió 22','versió 23').replace('165 fites','167 fites').replace('71 centres amb alguna fita documentada','73 centres amb alguna fita documentada').replace('71/75 registres · 94,7%','73/75 registres · 97,3%');idx=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',idx,count=1,flags=re.S);idx=idx.replace('73 centres amb alguna fita documentada','74 centres amb alguna fita documentada').replace('73/75 registres · 97,3%','74/75 registres · 98,7%');idx=idx.replace('74 centres amb alguna fita documentada','75 centres amb alguna fita documentada').replace('74/75 registres · 98,7%','75/75 registres · 100%');(out/'index.html').write_text(idx)
style='<style>body{max-width:1200px;margin:32px auto;padding:20px;font:16px system-ui;color:#223b39;background:#f5f1e8}h1{font:32px Georgia}table{border-collapse:collapse;width:100%;background:white}td,th{text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid #ccd5ce}small{display:block;line-height:1.5}a{color:#16665c}input,select{padding:10px;margin:8px 8px 16px 0;max-width:100%;font:inherit}.scroll{overflow:auto}</style>'
rows=''.join('<tr data-search="'+html.escape(x['centre'].lower()+' '+x['codi_centre'],quote=True)+'" data-cat="'+html.escape(x['categoria_origen'],quote=True)+'"><td><b>'+html.escape(x['centre'])+'</b><small>'+x['codi_centre']+'</small></td><td>'+str(x['fites_documentades'])+'</td><td>'+html.escape(x['categoria_origen'])+'<small>'+html.escape(x['origen_data_min']+' '+x['tipus_data_origen'])+'</small></td><td>'+html.escape(x['primera_fita_data']+' '+x['primera_fita_tipus'])+'</td><td>'+html.escape(x['tasca_prioritaria'])+'</td></tr>' for x in sorted(audit,key=lambda x:x['centre']))
opts='<option value="">Totes les categories</option>'+''.join('<option>'+html.escape(c)+'</option>' for c in sorted(stats))
script="""const q=document.querySelector('#q'),cat=document.querySelector('#cat'),rows=[...document.querySelectorAll('tbody tr')];function filter(){let n=0;for(const r of rows){const show=r.dataset.search.includes(q.value.toLowerCase().trim())&&(!cat.value||r.dataset.cat===cat.value);r.hidden=!show;if(show)n++;}document.querySelector('#n').textContent=n+' registres';}q.addEventListener('input',filter);cat.addEventListener('change',filter);filter();"""
(out/'auditoria-origens.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Mataró · Auditoria d’orígens V23</title>'+style+'<a href="index.html">← Mapa</a> · <a href="cronologia.html">Cronologia</a><h1>Què sabem dels orígens?</h1><p><b>75/75 codis amb alguna fita · 167 fites. 63/75 tenen una data al camp d’origen; 12 el tenen buit.</b> Les 63 dates inclouen fundacions declarades, antecedents, constitucions administratives i inicis de projectes: no són 63 primers dies de classe verificats. El 100% mesura qualsevol fita, no la cobertura de fundacions.</p><p>La primera fita conservada és només la més antiga de les documentades al conjunt actual. No s’utilitza automàticament com a fundació ni com a inici d’ocupació de la seu del mapa. Els 75 són codis de la base registral; no tots actius confirmats.</p><p><a href="auditoria_origens_v23.csv">Dades de l’auditoria</a> · <a href="pistes_origen_per_revisar_v23.csv">Pistes d’origen</a> · <a href="registre_recerca_v23.csv">Registre de recerca</a> · <a href="pla_recerca_pendent_v12.md">Consultes documentals preparades</a></p><label for="q">Centre o codi </label><input id="q" type="search"><label for="cat"> Categoria </label><select id="cat">'+opts+'</select><p id="n"></p><div class="scroll"><table><thead><tr><th>Centre</th><th>Fites</th><th>Camp d’origen</th><th>Primera fita documentada</th><th>Tasca pendent</th></tr></thead><tbody>'+rows+'</tbody></table></div><script>'+script+'</script></html>')




(out/'cobertura.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><title>Cobertura V23</title>'+style+'<h1>75/75 codis amb alguna fita · 167 fites</h1><p>63 camps amb una data relacionada amb l’origen; 12 buits. Peques: ampliació de 2013 documentada, autorització inicial pendent. Tots els codis tenen alguna fita, de naturalesa diversa. No són 63 fundacions verificades. Els 75 codis no són tots actius confirmats.</p><p><a href="index.html">Mapa</a> · <a href="cronologia.html">Cronologia</a> · <a href="auditoria-origens.html">Auditoria</a></p><table><tr><th>Centre</th><th>Fites</th><th>Recerca</th></tr>'+''.join('<tr><td>'+html.escape(r['nom'])+'</td><td>'+str(counts[r['codi_centre']])+'</td><td>'+html.escape(r['estat_recerca_historica'])+'</td></tr>' for r in sorted(a,key=lambda r:r['nom']))+'</table>')



review=read('revisio_17_camps_v22.csv')
for r in review:
 if r['codi_centre']=='08020905':
  r.update(estat_revisio='pendent: origen i continuïtat institucional',evidencia='H46: trasllat de la graduada de nenes a plaça de Cuba el 1940. H130: proposta de canvi de nom en convocatòria de 2001, no acord.',limit='1940 és trasllat, no fundació. La convocatòria no acredita aprovació del nom. No s’hereten dates de l’edifici ni de secundària.',document_necessari='Expedient de l’escola graduada de nenes del carrer Sant Cugat, trasllat de 1940 i continuïtat amb 08020905; acta del Ple de 08-02-2001 i resolució d’Ensenyament del canvi de nom.',fonts='H46; H11; H130',data_consulta='2026-11-19')
write('revisio_17_camps_v23.csv',review)
queries=read('consultes_documentals_v22.csv')
for q in queries:
 if q['codi_centre']=='08020905':
  r=next(x for x in review if x['codi_centre']==q['codi_centre']);q['document']=r['document_necessari'];q['text_consulta']='Per a la cartografia històrica dels centres educatius de Mataró, sol·licito referència i, si és possible, còpia de: '+q['document']+' Cal distingir l’antiguitat de l’escola de la del seu edifici i els actes de proposta dels acords efectivament adoptats.'
write('consultes_documentals_v23.csv',queries)
report="""# Contrast documental V23 — Angeleta Ferrer i l’escola de la Sra. Pilar

Dues fites noves; cap camp d’origen nou. 167 fites, 63 camps informats i 12 buits. L’objectiu d’acreditar els 17 orígens no està completat.

## La primària anterior a l’institut
La història publicada per Germanes Bertomeu (H46) descriu una escola graduada de nenes al carrer Sant Cugat, dirigida per Pilar Bertomeu i, després, per Conxita. Situa el trasllat a l’antic cafè La Unió de la plaça de Cuba i el nom Nuestra Señora del Pilar el 1940. És una fita de localització i denominació d’una escola ja existent; no és fundació. La història d’Angeleta Ferrer (H11) confirma l’ús de l’edifici per la primària Pilar, però cal provar la continuïtat institucional i del codi actual.
No s’equipara aquesta escola antiga al centre de Rocafonda inaugurat el 1969 amb el nom Germanes Bertomeu. La coincidència de mestres o d’homenatge no transfereix automàticament codis i dates.

## Correcció: convocatòria, no acord aprovat
La pàgina municipal del Ple de 08-02-2001 és una ordre del dia, dictada per Decret 737/2001 de 05-02-2001. El punt 27 proposa canviar Mare de Déu del Pilar per Angeleta Ferrer. No conté el debat, el resultat de la votació ni la resolució d’Ensenyament. La V22 l’havia descrit al dossier com un acord localitzat: aquesta qualificació era excessiva i es corregeix. El camp d’origen i les dates de canvi efectiu del nom no s’omplen a partir d’aquesta convocatòria.
El cos de la convocatòria conté una menció a 2000; es conserva la data del decret 2001, coherent amb el títol i l’assumpte. La data web de 2003 no és data del Ple.

## Documentació que ara cal cercar
Expedient de l’escola graduada de nenes del carrer Sant Cugat; expedient de trasllat de 1940; continuïtat amb el codi 08020905; acta completa de 08-02-2001 i resolució de canvi de nom. La petició concreta s’ha actualitzat a consultes_documentals_v23.csv. No s’ha enviat.

## Altres vies contrastades
Cerques per Dúnia i Heidi Consegal, Peques/Acuarella, Picasoques/Pica-soques i Nemomarlin no han aportat cap autorització inicial nova atribuïble inequívocament. Els resultats són directoris, presències i actes ja coneguts. No se’n dedueix una data ni inexistència de l’expedient. Les cerques del llibre Una escola avançada continuen portant a la notícia municipal de 2007, no al text complet. No es declara consultat el llibre.

## Fitxers vigents
Base CSV i GeoJSON; esdeveniments_historics_v23.csv, fonts_historiques_v23.csv, auditoria_origens_v23.csv, revisio_17_camps_v23.csv, registre_recerca_v23.csv, consultes_documentals_v23.csv i resum_auditoria.json. Els fitxers V22 i anteriors són checkpoints; no sumar-los. Es conserven les consultes de la V22 per als altres centres, sense presentar-les com a noves verificacions.
"""
(out/'pistes_documentals_v23.md').write_text(report)
(out/'revisio_17_camps_v23.md').write_text(report+'\n\n'+''.join('## '+r['centre']+' · '+r['codi_centre']+'\n'+r['estat_revisio']+'\n\n'+r['evidencia']+' '+r['limit']+'\n\nDocument necessari: '+r['document_necessari']+'\n\n' for r in review))
(out/'consultes_documentals_v23.md').write_text('# Esborranys de consultes, no enviats\n\n'+''.join('## '+q['centre']+'\n'+q['text_consulta']+'\n\n' for q in queries))
write('registre_recerca_v23.csv',[dict(data='2026-11-19',codi_centre='08020905',via='Història institucional Germanes Bertomeu',resultat='Trasllat a plaça de Cuba el 1940, no origen',font='H46'),dict(data='2026-11-19',codi_centre='08020905',via='Convocatòria municipal 2001',resultat='Proposta del nom; acord i aprovació no acreditats',font='H130'),dict(data='2026-11-19',codi_centre='08056948;08062547;08078695;08076790',via='Dos cercadors web; noms antics i actuals',resultat='Sense autorització inicial nova atribuïble; recerca no exhaustiva',font='Vegeu límits al report')])
for name in ['index.html','auditoria-origens.html','cobertura.html']:
 t=(out/name).read_text();t=t.replace('revisio_17_camps_v22.md','revisio_17_camps_v23.md');t=t.replace('</html>','<p><a href="pistes_documentals_v23.md">Novetats i correccions V23</a></p></html>');(out/name).write_text(t)
idx=(out/'index.html').read_text()
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=23,fites_historiques=167,fites_noves_v23=2,camps_origen_nous_v23=0,codis_amb_camp_origen_informat=63,codis_sense_camp_origen=12,categories_auditoria_origen=dict(stats),nota_v23='Angeleta Ferrer: trasllat d’un antecedent el 1940 i proposta del nom el 2001; convocatòria no equival a acord. Origen encara pendent.');(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V23.md').write_text('# Mataró, ciutat d’escoles — V23, 19-11-2026\n\nPaquet acumulatiu: obre index.html. No publicat en línia.\n\n'+report+'\n\nValidació automatitzada: 167 fites, 75 codis, 130 fonts, 63 camps informats i 12 buits; CSV/GeoJSON/JSON del mapa, JavaScript, enllaços locals, SHA256 i ZIP. 73 punts; geometries i estils conservats. Sense revisió visual al navegador.\n')
shutil.copy2(__file__,out/'amplia_mataro_v23.py')
assert len(a)==75 and len(audit)==75 and norigin==63 and len(E)==167
assert len({e['id_esdeveniment'] for e in E})==167
assert all(e['id_font'] in fm and e['data_min']<=e['data_max'] for e in E)
assert chron.count('<article data-year=')==167
assert '167 fites' in chron and '167 fites' in idx
assert (out/'cobertura.html').read_text().count('<tr>')==76
payload=re.search(r'const centres=(.*?);const esc=',idx,re.S).group(1)
assert json.loads(payload)==a
assert all(f['properties']==am[f['properties']['codi_centre']] for f in g['features'])
assert len([f for f in g['features'] if f['geometry']])==73
for name in ['index.html','cronologia.html','cobertura.html','auditoria-origens.html']:
 text=(out/name).read_text()
 for link in re.findall(r'href="([^"#]+)"',text):
  if not link.startswith(('http:','https:',chr(39))):assert (out/link).exists(),link
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',text,re.S)):
  path=Path('/tmp')/('v16_'+name+str(i)+'.js');path.write_text(s);subprocess.run(['node','--check',str(path)],check=True,capture_output=True)
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(manifest,indent=2))
zp=B/'Mataro_ciutat_escoles_V23_antecedent_Pilar_2026-11-19.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v23/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(json.dumps(dict(zip=str(zp),fites=len(E),camps_origen=norigin,pendents=75-norigin)))
