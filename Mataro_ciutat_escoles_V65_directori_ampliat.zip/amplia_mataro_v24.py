from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile,collections,subprocess
B=Path(__file__).parent;out=B/'mataro_escoles_v24';shutil.copytree(B/'mataro_escoles_v23',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,rows):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['codi_centre','centre','id_esdeveniment','tipus','data','id_font','afirmacio','decisio']);w.writeheader();w.writerows(rows)
a=read('mataro_centres_2026_2027.csv');am={r['codi_centre']:r for r in a};E=read('esdeveniments_historics_v23.csv');F=read('fonts_historiques_v23.csv');fm={r['id_font']:r for r in F}
def src(i,t,u,typ):
 r=dict(id_font=i,titol=t,url=u,consulta='2026-11-19',tipus=typ,abast='Fets i límits indicats en les fites i la revisió');F.append(r);fm[i]=r
def ev(c,k,d,f,claim,loc,notes,end=None):
 E.append(dict(id_esdeveniment='HIST-'+str(max(int(x['id_esdeveniment'].split('-')[1]) for x in E)+1).zfill(3),id_entitat='ENT-'+c,codi_actual_referencia=c,centre=am[c]['nom'],tipus=k,data_min=d,data_max=end or d,precisio='curs' if end else 'any' if len(d)==4 else 'dia',afirmacio=claim,id_font=f,font_url=fm[f]['url'],localitzador=loc,estat='documentat; contrast parcial',notes=notes))











src('H131','Resolució EDC/2102/2004, de 13 de juliol — obertura de Misha, Mataró','https://repositori.educacio.gencat.cat/bitstream/handle/20.500.12694/945/1014_XXII_agost.pdf?isAllowed=y&sequence=5','Full de disposicions i actes administratius núm. 1014, pàgines 1033–1034')
ev('08062547','autoritzacio_obertura','2004-07-13','H131','La Resolució EDC/2102/2004 autoritza l’obertura de Misha, codi 08062547, al carrer Rierot 2–4, baixos, amb efectes des de l’inici del curs 2004–2005: 5 unitats i 66 places.','Resolució i annex, pàgines impreses 1033–1034','El mateix codi identifica el centre avui denominat Peques. És autorització administrativa: no acredita el primer dia efectiu de classes. No s’infereix el dia d’inici del curs.')
am['08062547'].update(tipus_data_origen='autorització d’obertura',origen_data_min='2004-07-13',origen_data_max='2004-07-13',fundacio_font=fm['H131']['url'],estat_recerca_historica='Autorització inicial de Misha, mateix codi 08062547: 13-07-2004, efectes curs 2004–2005. Primeres classes i successió completa de noms pendents.')
E.sort(key=lambda e:(e['data_min'],e['id_esdeveniment']));counts=collections.Counter(e['codi_actual_referencia'] for e in E)
assert len(E)==168 and len(counts)==75
write('esdeveniments_historics_v24.csv',E);write('fonts_historiques_v24.csv',F)

for r in a:r['nombre_fites_documentades']=counts[r['codi_centre']]
write('mataro_centres_2026_2027.csv',a)
g=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in g['features']:f['properties']=am[f['properties']['codi_centre']]
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(g,ensure_ascii=False,indent=2))
# Audit is rebuilt from the updated canonical data and events.
by=collections.defaultdict(list)
for e in E:by[e['codi_actual_referencia']].append(e)
audit=[]
for r in a:
 c=r['codi_centre'];es=sorted(by[c],key=lambda e:(e['data_min'],e['id_esdeveniment']));first=es[0] if es else {};typ=r['tipus_data_origen'];d=r['origen_data_min']
 if not d:cat='camp d’origen buit; recerca pendent'
 elif 'antecedent' in typ or 'patronat' in typ or 'predecessor' in typ:cat='antecedent; no obertura del centre actual'
 elif 'autorització' in typ:cat='autorització d’obertura; no primeres classes'
 elif 'administrativa' in typ or 'creació' in typ or 'transformació' in typ or typ=='creacio_escola':cat='constitució o creació; classes pendents de distingir'
 elif 'projecte' in typ:cat='inici de projecte; no autorització del codi'
 else:cat='data d’origen declarada; contrast segons font'
 specific={
 '08065123':'Conciliar codis 08065123 i 08021089 i trobar autorització pròpia. No heretar 1905 ni 2004.',
 '08078695':'Autorització i primer curs pendents. Corregir coordenada del CSV només amb portal 27 documentat.',
 '08073946':'Autorització i efectes legals confirmats; primer curs real i relació amb Pinotxo pendents.',
 '08078877':'2012 és consolidació del projecte segons la directora; alta del codi i autorització de cicles pendents.',
 '08056948':'2015 és actuació escolar; no és fundació ni autorització.',
 '08021181':'Conciliar 1968/1970: classes inicials, comunitat religiosa i actes d’inauguració.',
 }
 audit.append(dict(codi_centre=c,centre=r['nom'],fites_documentades=len(es),categoria_origen=cat,tipus_data_origen=typ,origen_data_min=d,origen_data_max=r['origen_data_max'],font_origen=r['fundacio_font'],primera_fita_id=first.get('id_esdeveniment',''),primera_fita_data=first.get('data_min',''),primera_fita_tipus=first.get('tipus',''),primera_fita_font=first.get('font_url',''),control='Primera fita cronològica no equival a fundació.',tasca_prioritaria=specific.get(c,'Precisar què data la font d’origen i contrastar-la.' if d else 'Cercar origen del centre; no adoptar la primera fita com a fundació.')))
write('auditoria_origens_v24.csv',audit);stats=collections.Counter(x['categoria_origen'] for x in audit);norigin=sum(bool(x['origen_data_min']) for x in audit);assert norigin==64
# Candidates are extracted from documented events but do not silently overwrite canonical origins.
missing=[e for e in E if not next(r for r in a if r['codi_centre']==e['codi_actual_referencia'])['origen_data_min'] and e['tipus'] in {'origen_declarat','inauguracio_escola','antecedent_aulari','consolidacio_projecte_escolar','autoritzacio_obertura'}]
write('pistes_origen_per_revisar_v24.csv',[dict(codi_centre=e['codi_actual_referencia'],centre=e['centre'],id_esdeveniment=e['id_esdeveniment'],tipus=e['tipus'],data=e['data_min'],id_font=e['id_font'],afirmacio=e['afirmacio'],decisio='Candidat de revisió; no afegit al camp canònic d’origen automàticament.') for e in missing])
chron=(out/'cronologia.html').read_text();opts='<option value="">Tots els centres documentats</option>'+''.join('<option value="'+c+'">'+html.escape(n)+'</option>' for c,n in sorted({(e['codi_actual_referencia'],e['centre']) for e in E},key=lambda x:x[1]));chron=re.sub(r'(<select id="centre">).*?(</select>)',lambda m:m[1]+opts+m[2],chron,count=1,flags=re.S)
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['data_min']+'–'+e['data_max'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(fm[e['id_font']]['titol'])+' · '+html.escape(e['localitzador'])+'</a></p></article>' for e in E)
chron=chron.replace('167 fites','168 fites')
chron=re.sub(r'<article.*?</article>(?:<article.*?</article>)*',lambda m:items,chron,count=1,flags=re.S).replace('151 fites documentades de 75 dels 75 registres de base (100%)','168 fites documentades de 75 dels 75 registres de base (100%)').replace('V23','V24').replace('167 fites','168 fites');(out/'cronologia.html').write_text(chron)
idx=(out/'index.html').read_text().replace('167 fites','168 fites').replace('63 camps','64 camps').replace('12 buits','11 buits').replace('versió 23','versió 24').replace('167 fites','168 fites').replace('71 centres amb alguna fita documentada','73 centres amb alguna fita documentada').replace('71/75 registres · 94,7%','73/75 registres · 97,3%');idx=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',idx,count=1,flags=re.S);idx=idx.replace('73 centres amb alguna fita documentada','74 centres amb alguna fita documentada').replace('73/75 registres · 97,3%','74/75 registres · 98,7%');idx=idx.replace('74 centres amb alguna fita documentada','75 centres amb alguna fita documentada').replace('74/75 registres · 98,7%','75/75 registres · 100%');(out/'index.html').write_text(idx)
style='<style>body{max-width:1200px;margin:32px auto;padding:20px;font:16px system-ui;color:#223b39;background:#f5f1e8}h1{font:32px Georgia}table{border-collapse:collapse;width:100%;background:white}td,th{text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid #ccd5ce}small{display:block;line-height:1.5}a{color:#16665c}input,select{padding:10px;margin:8px 8px 16px 0;max-width:100%;font:inherit}.scroll{overflow:auto}</style>'
rows=''.join('<tr data-search="'+html.escape(x['centre'].lower()+' '+x['codi_centre'],quote=True)+'" data-cat="'+html.escape(x['categoria_origen'],quote=True)+'"><td><b>'+html.escape(x['centre'])+'</b><small>'+x['codi_centre']+'</small></td><td>'+str(x['fites_documentades'])+'</td><td>'+html.escape(x['categoria_origen'])+'<small>'+html.escape(x['origen_data_min']+' '+x['tipus_data_origen'])+'</small></td><td>'+html.escape(x['primera_fita_data']+' '+x['primera_fita_tipus'])+'</td><td>'+html.escape(x['tasca_prioritaria'])+'</td></tr>' for x in sorted(audit,key=lambda x:x['centre']))
opts='<option value="">Totes les categories</option>'+''.join('<option>'+html.escape(c)+'</option>' for c in sorted(stats))
script="""const q=document.querySelector('#q'),cat=document.querySelector('#cat'),rows=[...document.querySelectorAll('tbody tr')];function filter(){let n=0;for(const r of rows){const show=r.dataset.search.includes(q.value.toLowerCase().trim())&&(!cat.value||r.dataset.cat===cat.value);r.hidden=!show;if(show)n++;}document.querySelector('#n').textContent=n+' registres';}q.addEventListener('input',filter);cat.addEventListener('change',filter);filter();"""
(out/'auditoria-origens.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Mataró · Auditoria d’orígens V24</title>'+style+'<a href="index.html">← Mapa</a> · <a href="cronologia.html">Cronologia</a><h1>Què sabem dels orígens?</h1><p><b>75/75 codis amb alguna fita · 168 fites. 64/75 tenen una data al camp d’origen; 11 el tenen buit.</b> Les 64 dates inclouen fundacions declarades, antecedents, constitucions administratives i inicis de projectes: no són 64 primers dies de classe verificats. El 100% mesura qualsevol fita, no la cobertura de fundacions.</p><p>La primera fita conservada és només la més antiga de les documentades al conjunt actual. No s’utilitza automàticament com a fundació ni com a inici d’ocupació de la seu del mapa. Els 75 són codis de la base registral; no tots actius confirmats.</p><p><a href="auditoria_origens_v24.csv">Dades de l’auditoria</a> · <a href="pistes_origen_per_revisar_v24.csv">Pistes d’origen</a> · <a href="registre_recerca_v24.csv">Registre de recerca</a> · <a href="pla_recerca_pendent_v12.md">Consultes documentals preparades</a></p><label for="q">Centre o codi </label><input id="q" type="search"><label for="cat"> Categoria </label><select id="cat">'+opts+'</select><p id="n"></p><div class="scroll"><table><thead><tr><th>Centre</th><th>Fites</th><th>Camp d’origen</th><th>Primera fita documentada</th><th>Tasca pendent</th></tr></thead><tbody>'+rows+'</tbody></table></div><script>'+script+'</script></html>')




(out/'cobertura.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><title>Cobertura V24</title>'+style+'<h1>75/75 codis amb alguna fita · 168 fites</h1><p>64 camps amb una data relacionada amb l’origen; 11 buits. Peques: autorització inicial de Misha (mateix codi) de 2004 documentada; efectes curs 2004–2005. Tots els codis tenen alguna fita, de naturalesa diversa. No són 64 fundacions verificades. Els 75 codis no són tots actius confirmats.</p><p><a href="index.html">Mapa</a> · <a href="cronologia.html">Cronologia</a> · <a href="auditoria-origens.html">Auditoria</a></p><table><tr><th>Centre</th><th>Fites</th><th>Recerca</th></tr>'+''.join('<tr><td>'+html.escape(r['nom'])+'</td><td>'+str(counts[r['codi_centre']])+'</td><td>'+html.escape(r['estat_recerca_historica'])+'</td></tr>' for r in sorted(a,key=lambda r:r['nom']))+'</table>')



review=read('revisio_17_camps_v23.csv')
for r in review:
 if r['codi_centre']=='08062547':
  r.update(estat_revisio='informat: autorització inicial; primeres classes pendents',evidencia='H131: EDC/2102/2004, de 13 de juliol. Obertura de Misha, mateix codi 08062547, Rierot 2–4; efectes curs 2004–2005, 5 unitats i 66 places.',limit='Data administrativa, no primer dia de classes. Cal reconstruir la successió completa Misha/Peques/Acuarella/Peques sense suposar-ne dates.',document_necessari='Primer curs efectiu i resolucions de canvi de nom i titularitat intermèdies; autorització inicial ja localitzada.',fonts='H131; H120; H84',data_consulta='2026-11-19')
write('revisio_17_camps_v24.csv',review)
queries=read('consultes_documentals_v23.csv')
queries=[q for q in queries if q['codi_centre']!='08062547']
write('consultes_documentals_v24.csv',queries)
report="""# Contrast documental V24 — autorització inicial de Misha / Peques

168 fites, 75 codis, 131 fonts. 64 camps amb una data relacionada amb l’origen; 11 buits. Dels 17 casos revisats, 6 tenen una data qualificada i 11 continuen pendents. Les dates inclouen actes administratius: no equivalen a fundacions ni a primeres classes verificades.

## Nova evidència primària
La Resolució EDC/2102/2004, de 13 de juliol, autoritza l’obertura de Misha, a Mataró: codi 08062547, carrer Rierot 2–4, baixos. L’annex estableix efectes des de l’inici del curs 2004–2005, amb 5 unitats i 66 places. Font H131, Full de disposicions i actes administratius núm. 1014, pàgines impreses 1033–1034. El codi coincideix amb el registre actual de Peques i el mateix emplaçament consta en l’ampliació de 2013 (H120).

Es registra 13-07-2004 com a autorització d’obertura; no s’omple fundacio_any ni s’inventa la data de la primera classe. El canvi de nom a Acuarella de 2018 (H84) i la denominació actual Peques no determinen totes les dates intermèdies de nom i titularitat. Aquesta successió continua pendent de reconstrucció.

## Correcció del pendent
L’autorització inicial de Peques ja no és pendent. Es conserva la recerca anterior com a checkpoint, es retiren les peticions d’autorització inicial d’aquest codi de la cua vigent i s’actualitzen el mapa, la cronologia, l’auditoria i la revisió dels 17 casos. Les 11 consultes restants són esborranys no enviats.

## Fitxers vigents
CSV i GeoJSON canònics; esdeveniments_historics_v24.csv, fonts_historiques_v24.csv, auditoria_origens_v24.csv, revisio_17_camps_v24.csv, consultes_documentals_v24.csv, registre_recerca_v24.csv i resum_auditoria.json. Els fitxers V23 i anteriors són checkpoints; no sumar-los. Obre index.html. Aquest paquet no s’ha publicat en línia.
"""
(out/'pistes_documentals_v24.md').write_text(report)
(out/'revisio_17_camps_v24.md').write_text(report+'\n\n'+''.join('## '+r['centre']+' · '+r['codi_centre']+'\n'+r['estat_revisio']+'\n\n'+r['evidencia']+' '+r['limit']+'\n\nDocument necessari: '+r['document_necessari']+'\n\n' for r in review))
(out/'consultes_documentals_v24.md').write_text('# Esborranys de consultes, no enviats\n\n'+''.join('## '+q['centre']+'\n'+q['text_consulta']+'\n\n' for q in queries))
write('registre_recerca_v24.csv',[dict(data='2026-11-19',codi_centre='08062547',via='Cerca pel codi oficial i lectura de la resolució completa',resultat='Autorització inicial Misha, mateix codi actual Peques, 13-07-2004; efectes curs 2004–2005',font='H131')])
for name in ['index.html','auditoria-origens.html','cobertura.html']:
 t=(out/name).read_text();t=t.replace('revisio_17_camps_v23.md','revisio_17_camps_v24.md');t=t.replace('</html>','<p><a href="pistes_documentals_v24.md">Novetats i correccions V24</a></p></html>');(out/name).write_text(t)
idx=(out/'index.html').read_text()
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=24,fites_historiques=168,fites_noves_v24=1,camps_origen_nous_v24=1,codis_amb_camp_origen_informat=64,codis_sense_camp_origen=11,categories_auditoria_origen=dict(stats),nota_v24='Misha / Peques, codi 08062547: autorització EDC/2102/2004 de 13-07-2004; efectes curs 2004–2005. Primeres classes pendents.');(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V24.md').write_text('# Mataró, ciutat d’escoles — V24, 19-11-2026\n\nPaquet acumulatiu: obre index.html. No publicat en línia.\n\n'+report+'\n\nValidació automatitzada: 168 fites, 75 codis, 131 fonts, 64 camps informats i 11 buits; CSV/GeoJSON/JSON del mapa, JavaScript, enllaços locals, SHA256 i ZIP. 73 punts; geometries i estils conservats. Sense revisió visual al navegador.\n')
shutil.copy2(__file__,out/'amplia_mataro_v24.py')
assert len(a)==75 and len(audit)==75 and norigin==64 and len(E)==168
assert len({e['id_esdeveniment'] for e in E})==168
assert all(e['id_font'] in fm and e['data_min']<=e['data_max'] for e in E)
assert chron.count('<article data-year=')==168
assert '168 fites' in chron and '168 fites' in idx
assert (out/'cobertura.html').read_text().count('<tr>')==76
payload=re.search(r'const centres=(.*?);const esc=',idx,re.S).group(1)
assert json.loads(payload)==a
assert all(f['properties']==am[f['properties']['codi_centre']] for f in g['features'])
assert len([f for f in g['features'] if f['geometry']])==73
for name in ['index.html','cronologia.html','cobertura.html','auditoria-origens.html']:
 text=(out/name).read_text()
 for link in re.findall(r'href="([^"#]+)"',text):
  if not link.startswith(('http:','https:',chr(39))):assert (out/link).exists(),link
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',text,re.S)):
  path=Path('/tmp')/('v16_'+name+str(i)+'.js');path.write_text(s);subprocess.run(['node','--check',str(path)],check=True,capture_output=True)
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(manifest,indent=2))
zp=B/'Mataro_ciutat_escoles_V24_obertura_Misha_Peques_2026-11-19.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v24/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(json.dumps(dict(zip=str(zp),fites=len(E),camps_origen=norigin,pendents=75-norigin)))
