from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile
B=Path(__file__).parent;out=B/'mataro_escoles_v7';shutil.copytree(B/'mataro_escoles_v6',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,a):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(a[0]));w.writeheader();w.writerows(a)
F=read('fonts_historiques_v6.csv')
for id,t,u in [('H25','Meritxell — Alumni','https://www.fundaciomeritxell.cat/coneix-nos/alumni-escola-meritxell/'),('H26','Freta — PEC, apartat 3.3','https://www.freta.cat/wp-content/uploads/2018/03/ON_SOM3.pdf'),('H27','Freta — presentació i història','https://www.freta.cat/presentacio/'),('H28','Mare de Déu de Lourdes — història','https://mdlourdes.cat/escola/'),('H29','Divina Providència — ideari','https://www.providencia.cat/sec-Ideari-11966.html')]:
 F.append({'id_font':id,'titol':t,'url':u,'consulta':'2026-11-18','tipus':'institucional','abast':'Història publicada pel centre; distinció entre origen, seu, ensenyament i titularitat'})
write('fonts_historiques_v7.csv',F);fm={r['id_font']:r for r in F}
E=read('esdeveniments_historics_v6.csv')
def ev(code,name,kind,d,precision,claim,f,notes='',loc=''):
 E.append({'id_esdeveniment':'HIST-'+str(len(E)+1).zfill(3),'id_entitat':'ENT-'+code,'codi_actual_referencia':code,'centre':name,'tipus':kind,'data_min':d,'data_max':d,'precisio':precision,'afirmacio':claim,'id_font':f,'font_url':fm[f]['url'],'localitzador':loc,'estat':'documentat en font del centre','notes':notes})
ev('08020991','Meritxell','inici_escola','1969','any','Inici de l’Escola Meritxell.','H25','La fundació cultural titular és una figura jurídica posterior; no es confonen les dates.','Introducció Alumni')
ev('08034141','Freta','inici_centre','1964','any','Inici com a centre d’idiomes segons el PEC.','H26','El PEC associa els inicis a Amàlia 25; la presentació web situa un primer local a plaça de les Tereses. La seqüència espacial queda pendent.','3.3 Història')
ev('08034141','Freta','ensenyament','1972','any','Incorporació al marc de formació professional reglada, segons la història del centre.','H26','Descriu l’adaptació dels estudis del centre, no l’origen general de l’FP a Espanya.','3.3 Història')
ev('08034141','Freta','trasllat_seu','1987','any','Trasllat al nou edifici de passeig Rocafonda 45–47 a l’inici del curs.','H26','Corroborat per la presentació web H27. No s’assigna un dia concret.','3.3 Història')
ev('08021065','Mare de Déu de Lourdes','adquisicio_finca','1906-02','mes','Compra de la finca per les religioses de la Misericòrdia de Moissac.','H28','No és encara obertura de classes.','La nostra història: febrer 1906')
ev('08021065','Mare de Déu de Lourdes','obertura_classes','1906-09','mes','Obertura de classes a l’alumnat de la ciutat.','H28','La precisió és de mes; no es dedueix un dia exacte.','La nostra història: setembre 1906')
ev('08021065','Mare de Déu de Lourdes','titularitat','2006','any','Cessió de titularitat a la Fundació Privada Madame Gényer.','H28','No és una nova escola.','La nostra història: any 2006')
ev('08021235','Divina Providència','antecedent_monastic','1849','any','Fundació del monestir al qual pertany el col·legi, segons l’ideari del centre.','H29','La data no es dona per provada com a primer dia d’activitat escolar. Cal contrastar la bibliografia que situa altres fites educatives als anys 1850.','Missió')
E.sort(key=lambda e:e['data_min']);write('esdeveniments_historics_v7.csv',E)
a=read('mataro_centres_2026_2027.csv')
updates={'08020991':('1969','inici escolar','H25'),'08034141':('1964','inici com a centre d’idiomes','H26'),'08021065':('1906-09','obertura de classes','H28'),'08021235':('1849','antecedent monàstic; obertura escolar pendent','H29')}
for r in a:
 if r['codi_centre'] in updates:
  d,k,f=updates[r['codi_centre']];r.update(fundacio_any='',fundacio_font=fm[f]['url'],tipus_data_origen=k,origen_data_min=d,origen_data_max=d,estat_recerca_historica='fites documentades; origen i seus pendents de contrast addicional')
 r['nombre_fites_documentades']=len([e for e in E if e['codi_actual_referencia']==r['codi_centre']])
write('mataro_centres_2026_2027.csv',a)
g=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in g['features']:f['properties']=next(r for r in a if r['codi_centre']==f['properties']['codi_centre'])
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(g,ensure_ascii=False,indent=2))
# Completar inici de la seu actual de Freta, sense afegir noves geometries.
seats=read('mataro_seus_observades.csv')
for s in seats:
 if s['codi_centre']=='08034141':s['inici_ocupacio']='1987, inici de curs; dia desconegut';s['font_verificacio']+=' | H26 | H27'
write('mataro_seus_observades.csv',seats)
sg=json.loads((out/'mataro_seus_v2.geojson').read_text())
for f in sg['features']:f['properties']=next(s for s in seats if s['id_seu_observada']==f['properties']['id_seu_observada'])
(out/'mataro_seus_v2.geojson').write_text(json.dumps(sg,ensure_ascii=False,indent=2))
write('freta_seus_documentals_v7.csv',[
{'codi_centre':'08034141','emplaçament':'Plaça de les Tereses, número desconegut','periode':'anys seixanta segons presentació web','font':'H27','estat':'primer local segons web; conciliar amb PEC','geometria':'pendent'},
{'codi_centre':'08034141','emplaçament':'Carrer Amàlia 25','periode':'inici segons PEC; posterior a Tereses segons web','font':'H26 | H27','estat':'adreça documentada, seqüència discrepant','geometria':'pendent'},
{'codi_centre':'08034141','emplaçament':'Carrer d’en Moles, número desconegut','periode':'abans del trasllat de 1987; inici desconegut','font':'H26 | H27','estat':'locals addicionals; no trasllat únic acreditat','geometria':'pendent'},
{'codi_centre':'08034141','emplaçament':'Passeig Rocafonda 45–47','periode':'des de 1987; seu observada al registre actual','font':'H26 | H27 | CSV Generalitat','estat':'inici d’ocupació documentat per any','geometria':'punt del registre actual'}])
d=read('discrepancies_i_pistes_v6.csv');d.extend([
{'id':'D04','centre':'Freta','tema':'primer local','dada_a':'PEC: centre de 1964 al carrer Amàlia 25','dada_b':'Web: primer local a plaça de les Tereses i després Amàlia','font':'H26 | H27','decisio':'Conservar dues afirmacions. Data d’inici del centre admesa segons PEC, seqüència exacta de seus pendent.'},
{'id':'D05','centre':'Divina Providència','tema':'origen monàstic i escolar','dada_a':'Ideari: monestir fundat 1849','dada_b':'Bibliografia de cerca esmenta dates educatives als anys 1850','font':'H29; bibliografia per verificar','decisio':'1849 només antecedent monàstic. No s’ha fixat la fundació escolar.'}]);write('discrepancies_i_pistes_v7.csv',d)
# Regeneració de cronologia conservant els controls.
names=sorted({(e['codi_actual_referencia'],e['centre']) for e in E},key=lambda x:x[1]);chron=(out/'cronologia.html').read_text()
opts='<option value="">Tots els centres documentats</option>'+''.join('<option value="'+c+'">'+html.escape(n)+'</option>' for c,n in names)
chron=re.sub(r'(<select id="centre">).*?(</select>)',lambda m:m[1]+opts+m[2],chron,count=1,flags=re.S)
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['precisio'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(fm[e['id_font']]['titol'])+'</a></p></article>' for e in E)
chron=re.sub(r'<article.*?</article>(?:<article.*?</article>)*',lambda m:items,chron,count=1,flags=re.S).replace('28 fites documentades de 14 centres','36 fites documentades de 18 centres').replace('V6','V7')
(out/'cronologia.html').write_text(chron)
idx=(out/'index.html').read_text().replace('versió 6','versió 7').replace('28 fites','36 fites');idx=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',idx,count=1,flags=re.S);(out/'index.html').write_text(idx)
write('cobertura_recerca_v7.csv',[{'codi_centre':r['codi_centre'],'centre':r['nom'],'naturalesa_actual':r['naturalesa'],'fites_documentades':r['nombre_fites_documentades'],'estat':'iniciat' if r['nombre_fites_documentades'] else 'pendent','nota':'Cobertura de recerca, no avaluació de qualitat escolar'} for r in a])
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=7,fites_historiques=36,centres_amb_fites=18,fites_noves_v7=8);(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V7.md').write_text('''# Mataró, ciutat d’escoles — V7
Guia vigent. Paquet acumulatiu del 18-11-2026. 75 centres actuals, 77 seus actuals registrals/documentades (75 amb geometria), 36 fites de 18 centres. Les localitzacions històriques s’inventarien en taules separades i no incrementen el nombre de centres actuals.

## Ampliació
Meritxell: inici escolar 1969, segons Alumni institucional. Freta: inici 1964, adopció d’FP reglada 1972 i trasllat a Rocafonda 1987, segons PEC. Mare de Déu de Lourdes: compra de finca febrer 1906, obertura de classes setembre 1906 i canvi de titularitat 2006. Divina Providència: antecedent monàstic de 1849; no es tracta com una fundació escolar resolta.

## Precisió
Freta té dues narracions diferents sobre el primer local (Tereses/Amàlia), conservades a discrepancies_i_pistes_v7.csv. No s’ha geocodificat un lloc inicial ambigu. Els locals d’en Moles són documentals i amb número desconegut. La fitxa de seu actual té inici d’ocupació per any, no dia exacte. No s’han incorporat al mapa de Mataró les seus de Freta a Calella.
La data fundacional del monestir de Divina Providència no prova per si sola l’obertura escolar. El camp fundacio_any continua buit en aquest cas i altres d’origen tipificat. Tots els tipus de fita són consultables al CSV.

## Fitxers vigents
fonts_historiques_v7.csv, esdeveniments_historics_v7.csv, discrepancies_i_pistes_v7.csv, cobertura_recerca_v7.csv, freta_seus_documentals_v7.csv, mataro_centres_2026_2027.csv/.geojson, mataro_seus_observades.csv.
Els fitxers V1–V6 són antecedents; no sumar-ne registres als V7, que ja són acumulatius. El GeoJSON de seus conserva el nom V2 per compatibilitat però les propietats s’han actualitzat a partir de la taula vigent.
Obrir index.html, cronologia.html o angeleta-ferrer.html. Els mapes requereixen Internet. Sense publicació web en aquesta fase.

Validació de recompte, integritat de codis i fonts, geometries i sintaxi JavaScript. No s’ha fet inspecció visual amb navegador. La cronologia és parcial: 18 de 75 centres amb alguna fita, no 18 històries completes. Els 57 restants continuen pendents.
''')
shutil.copy2(__file__,out/'amplia_mataro_v7.py')
assert len(a)==75 and len(E)==36 and len(names)==18 and len({e['id_esdeveniment'] for e in E})==36
assert all(e['id_font'] in fm for e in E)
for n in ['index.html','cronologia.html']:
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',(out/n).read_text(),re.S)):Path('/tmp/v7_'+n+str(i)+'.js').write_text(s)
m={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(m,indent=2))
zp=B/'Mataro_ciutat_escoles_V7_36_fites_2026-11-18.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v7/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(zp)
