from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile,collections,subprocess
B=Path(__file__).parent;out=B/'mataro_escoles_v12';shutil.copytree(B/'mataro_escoles_v11',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,rows):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
a=read('mataro_centres_2026_2027.csv');E=read('esdeveniments_historics_v11.csv');F=read('fonts_historiques_v11.csv');fm={r['id_font']:r for r in F}
# No new historical assertion is promoted by this audit.
by=collections.defaultdict(list)
for e in E:by[e['codi_actual_referencia']].append(e)
audit=[]
for r in a:
 c=r['codi_centre'];es=sorted(by[c],key=lambda e:(e['data_min'],e['id_esdeveniment']));first=es[0] if es else {};typ=r['tipus_data_origen'];d=r['origen_data_min']
 if not d:cat='camp d’origen buit; recerca pendent'
 elif 'antecedent' in typ or 'patronat' in typ:cat='antecedent; no obertura del centre actual'
 elif 'administrativa' in typ or 'creació' in typ:cat='constitució o creació; classes pendents de distingir'
 elif 'projecte' in typ:cat='inici de projecte; no autorització del codi'
 else:cat='data d’origen declarada; contrast segons font'
 specific={
 '08065123':'Conciliar codis 08065123 i 08021089 i trobar autorització pròpia. No heretar 1905 ni 2004.',
 '08078695':'Autorització i primer curs pendents. Corregir coordenada del CSV només amb portal 27 documentat.',
 '08073946':'Autorització i efectes legals confirmats; primer curs real i relació amb Pinotxo pendents.',
 '08078877':'2012 és consolidació del projecte segons la directora; alta del codi i autorització de cicles pendents.',
 '08056948':'2015 és actuació escolar; no és fundació ni autorització.',
 '08021181':'Conciliar 1968/1970: classes inicials, comunitat religiosa i actes d’inauguració.',
 }
 audit.append(dict(codi_centre=c,centre=r['nom'],fites_documentades=len(es),categoria_origen=cat,tipus_data_origen=typ,origen_data_min=d,origen_data_max=r['origen_data_max'],font_origen=r['fundacio_font'],primera_fita_id=first.get('id_esdeveniment',''),primera_fita_data=first.get('data_min',''),primera_fita_tipus=first.get('tipus',''),primera_fita_font=first.get('font_url',''),control='Primera fita cronològica no equival a fundació.',tasca_prioritaria=specific.get(c,'Precisar què data la font d’origen i contrastar-la.' if d else 'Cercar origen del centre; no adoptar la primera fita com a fundació.')))
write('auditoria_origens_v12.csv',audit);stats=collections.Counter(x['categoria_origen'] for x in audit);norigin=sum(bool(x['origen_data_min']) for x in audit);assert norigin==40
# Candidates are extracted from documented events but do not silently overwrite canonical origins.
missing=[e for e in E if not next(r for r in a if r['codi_centre']==e['codi_actual_referencia'])['origen_data_min'] and e['tipus'] in {'origen_declarat','inauguracio_escola','antecedent_aulari','consolidacio_projecte_escolar','autoritzacio_obertura'}]
write('pistes_origen_per_revisar_v12.csv',[dict(codi_centre=e['codi_actual_referencia'],centre=e['centre'],id_esdeveniment=e['id_esdeveniment'],tipus=e['tipus'],data=e['data_min'],id_font=e['id_font'],afirmacio=e['afirmacio'],decisio='Candidat de revisió; no afegit al camp canònic d’origen automàticament.') for e in missing])
queries=[('CIDO','soques; Pica-Soques; Salesia; Salesians; Salesià','Sense nou acte atribuïble inequívocament als dos codis.','No prova que l’acte no existeixi; cercador de títols i indexació incompleta.'),('Web pública','08065123 autorització; Col·legi Salesià formació d’adults resolució','Retorna resolució de 2004 amb altre codi i llistats d’oferta ja coneguts.','No es converteix l’oferta en autorització inicial.'),('Web pública','Picasoques Mataró obertura; Pica-soques Mataró inauguració','Web del centre, directori i resultats homònims, sense data d’origen contrastada.','No s’atribueixen societats, revistes o escoles d’altres municipis.'),('Web oficial Picasoques','Contacte, ronda República 27','El mapa incrustat és una cerca textual de l’adreça.','No aporta una coordenada de portal verificada; no es corregeix geometria per inferència.')]
write('registre_recerca_v12.csv',[dict(data_consulta='2026-11-18',via=v,consulta=q,resultat=r,limit=l) for v,q,r,l in queries])
# Current observations and sources remain V11: they contain the latest substantive historical assertions.
for n in ['index.html','cronologia.html']:
 s=(out/n).read_text().replace('versió 11','versió 12').replace('V11','V12')
 s=s.replace('<nav>','<nav><a href="auditoria-origens.html">Orígens i límits de la recerca</a>',1) if n=='index.html' else s.replace('<h1>','<p><a href="auditoria-origens.html">Auditoria d’orígens</a></p><h1>',1)
 (out/n).write_text(s)
s=(out/'cobertura.html').read_text().replace('Cobertura V11','Cobertura V12').replace('<h1>','<p><a href="auditoria-origens.html">Auditoria d’orígens i dates</a></p><h1>',1);(out/'cobertura.html').write_text(s)
style='<style>body{max-width:1200px;margin:32px auto;padding:20px;font:16px system-ui;color:#223b39;background:#f5f1e8}h1{font:32px Georgia}table{border-collapse:collapse;width:100%;background:white}td,th{text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid #ccd5ce}small{display:block;line-height:1.5}a{color:#16665c}input,select{padding:10px;margin:8px 8px 16px 0;max-width:100%;font:inherit}.scroll{overflow:auto}</style>'
rows=''.join('<tr data-search="'+html.escape(x['centre'].lower()+' '+x['codi_centre'],quote=True)+'" data-cat="'+html.escape(x['categoria_origen'],quote=True)+'"><td><b>'+html.escape(x['centre'])+'</b><small>'+x['codi_centre']+'</small></td><td>'+str(x['fites_documentades'])+'</td><td>'+html.escape(x['categoria_origen'])+'<small>'+html.escape(x['origen_data_min']+' '+x['tipus_data_origen'])+'</small></td><td>'+html.escape(x['primera_fita_data']+' '+x['primera_fita_tipus'])+'</td><td>'+html.escape(x['tasca_prioritaria'])+'</td></tr>' for x in sorted(audit,key=lambda x:x['centre']))
opts='<option value="">Totes les categories</option>'+''.join('<option>'+html.escape(c)+'</option>' for c in sorted(stats))
script="""const q=document.querySelector('#q'),cat=document.querySelector('#cat'),rows=[...document.querySelectorAll('tbody tr')];function filter(){let n=0;for(const r of rows){const show=r.dataset.search.includes(q.value.toLowerCase().trim())&&(!cat.value||r.dataset.cat===cat.value);r.hidden=!show;if(show)n++;}document.querySelector('#n').textContent=n+' registres';}q.addEventListener('input',filter);cat.addEventListener('change',filter);filter();"""
(out/'auditoria-origens.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Mataró · Auditoria d’orígens V12</title>'+style+'<a href="index.html">← Mapa</a> · <a href="cronologia.html">Cronologia</a><h1>Què sabem dels orígens?</h1><p><b>73/75 codis amb alguna fita · 116 fites. 40/75 tenen una data al camp d’origen; 35 el tenen buit.</b> Les 40 dates inclouen fundacions declarades, antecedents, constitucions administratives i inicis de projectes: no són 40 primers dies de classe verificats. El 97,3% mesura qualsevol fita, no la cobertura de fundacions.</p><p>La primera fita conservada és només la més antiga de les documentades al conjunt actual. No s’utilitza automàticament com a fundació ni com a inici d’ocupació de la seu del mapa. Els 75 són codis de la base registral; no tots actius confirmats.</p><p><a href="auditoria_origens_v12.csv">Dades de l’auditoria</a> · <a href="pistes_origen_per_revisar_v12.csv">Pistes d’origen</a> · <a href="registre_recerca_v12.csv">Registre de recerca</a> · <a href="pla_recerca_pendent_v12.md">Consultes documentals preparades</a></p><label for="q">Centre o codi </label><input id="q" type="search"><label for="cat"> Categoria </label><select id="cat">'+opts+'</select><p id="n"></p><div class="scroll"><table><thead><tr><th>Centre</th><th>Fites</th><th>Camp d’origen</th><th>Primera fita documentada</th><th>Tasca pendent</th></tr></thead><tbody>'+rows+'</tbody></table></div><script>'+script+'</script></html>')
(out/'pla_recerca_pendent_v12.md').write_text('''# Consultes documentals preparades — 18-11-2026
Esborranys; no s’han enviat missatges ni sol·licituds.

## 1. Serveis Territorials d’Educació al Maresme–Vallès Oriental
Assumpte: consulta documental dels centres 08065123 i 08078695

Estic elaborant una cartografia històrica dels centres educatius de Mataró. Voldria localitzar les resolucions d’autorització inicial, les dates d’efectes i, si n’hi ha, els canvis de codi o denominació dels centres següents:
- Col·legi Salesià, codi 08065123, avinguda de Puig i Cadafalch 80. La Resolució EDC/2410/2004 descriu formació de persones adultes però l’annex porta el codi 08021089; la correcció posterior només esmena la comarca. Hi ha un acte que expliqui l’assignació o la separació dels dos codis?
- Escola bressol Picasoques, codi 08078695, ronda de la República 27, baixos. Quina és l’autorització inicial i des de quin curs té efectes?

Agrairia la referència de publicació o una còpia dels actes administratius públics corresponents, sense dades personals d’alumnat ni expedients particulars.

## 2. Col·legi Salesià / arxiu del centre
Assumpte: origen de la formació de persones adultes i codi 08065123

Per a una cartografia històrica educativa de Mataró, voldria distingir la fundació del col·legi de 1905 de l’inici del centre de persones adultes amb codi 08065123. Disposeu d’una memòria, resolució o document que indiqui el primer curs d’aquesta oferta i expliqui la relació administrativa amb el codi 08021089 que apareix a la resolució de 2004? Em seria útil també distingir activitat prèvia i autorització formal.

## 3. Picasoques / documentació del centre
Assumpte: primer curs i autorització de Picasoques

Estic documentant la història dels centres educatius de Mataró. Em podríeu indicar el primer curs en què Picasoques va acollir infants a ronda de la República 27 i la referència de l’autorització del codi 08078695? Si hi havia una denominació o un projecte anterior al mateix local, voldria poder separar les etapes. Una memòria, anunci d’obertura o resolució permetria citar la dada amb precisió.

## Regla d’incorporació
Registrar per separat data de resolució, publicació, efectes legals, primeres classes i ocupació de seu. Conservar l’original de cada resposta i indicar si és relat retrospectiu o document contemporani. No modificar els comptadors fins a disposar d’una fita atribuïble. No cal cap dada d’infants ni famílies.
''')
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=12,fites_noves_v12=0,codis_amb_camp_origen_informat=40,codis_sense_camp_origen=35,categories_auditoria_origen=dict(stats),nota_v12='Auditoria de cobertura: 97,3% és qualsevol fita; 40 camps d’origen informats, amb dates heterogènies. Dos codis continuen sense fita. Consultes documentals redactades, no enviades.');(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V12.md').write_text('''# Mataró, ciutat d’escoles — V12, 18-11-2026
Obre index.html per al mapa i auditoria-origens.html per al nou control documental. Paquet acumulatiu, sense publicació en línia.

No s’afegeixen fites històriques: continuen 116 i 73/75 codis amb alguna fita (97,3%). Les cerques no han resolt l’autorització pròpia del Col·legi Salesià 08065123 ni la data inicial de Picasoques 08078695. Les coincidències de noms no s’han promogut a evidència. La manca de resultats no prova que els documents no existeixin.

Nova auditoria de 75 codis: 40 tenen data al camp d’origen i 35 no. Les 40 inclouen antecedents, creacions administratives i projectes, a més d’inicis escolars i fundacions declarades; no són 40 fundacions verificades. La primera fita datada tampoc equival automàticament a la fundació. La taula permet cercar centres i filtrar la naturalesa del camp d’origen. El nou CSV de pistes identifica fites existents que cal revisar abans de decidir si s’informen camps canònics; no modifica dates per inferència.

Dades històriques vigents: esdeveniments_historics_v11.csv i fonts_historiques_v11.csv (sense canvis); base CSV/GeoJSON i inventari de seus de V11. Nova informació: auditoria_origens_v12.csv, pistes_origen_per_revisar_v12.csv, registre_recerca_v12.csv, pla_recerca_pendent_v12.md i auditoria-origens.html. Versions anteriors són checkpoints, no sumar-ne registres.

S’han redactat consultes a Educació i als dos centres per obtenir actes, primer curs i conciliació de codis. Són esborranys: no s’ha enviat res. No cal informació personal d’alumnat o famílies.

Vigència i geometries: es mantenen les correccions de V9–V11 i els 73 punts de centre. Picasoques: el mapa del web és una consulta textual de l’adreça, no una coordenada de portal verificada. No es canvia el punt incorrecte del CSV ni s’assigna el portal 29 al 27. Figueretes: seu provisional sense coordenada contrastada. Els 75 codis no són 75 centres actius confirmats.

Validació: correspondència 75 codis, recomptes històrics preservats, taula d’auditoria, filtres de cerca/categoria, sintaxi JavaScript, enllaços locals, integritat ZIP i SHA256. Sense comprovació visual en navegador ni auditoria arxivística exhaustiva.
''')
shutil.copy2(__file__,out/'amplia_mataro_v12.py')
assert len(audit)==75 and sum(x['fites_documentades'] for x in audit)==116 and sum(bool(x['fites_documentades']) for x in audit)==73
assert (out/'esdeveniments_historics_v11.csv').read_bytes()==(B/'mataro_escoles_v11/esdeveniments_historics_v11.csv').read_bytes()
for name in ['index.html','cronologia.html','cobertura.html','auditoria-origens.html']:
 text=(out/name).read_text()
 for link in re.findall(r'href="([^"#]+)"',text):
  if not link.startswith(('http:','https:',chr(39))):assert (out/link).exists(),link
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',text,re.S)):
  p=Path('/tmp')/('v12_'+name+str(i)+'.js');p.write_text(s);subprocess.run(['node','--check',str(p)],check=True,capture_output=True)
# Exercise the new filter logic with the actual audit data in a small DOM fixture.
fixture="const data="+json.dumps(audit,ensure_ascii=False)+";const r=data.map(x=>({dataset:{search:(x.centre+' '+x.codi_centre).toLowerCase(),cat:x.categoria_origen},hidden:false}));const els={'#q':{value:'',addEventListener(){}},'#cat':{value:'',addEventListener(){}},'#n':{textContent:''}};const document={querySelector:s=>els[s],querySelectorAll:()=>r};"+script+";if(els['#n'].textContent!=='75 registres')throw Error('all');els['#q'].value='08078695';filter();if(r.filter(x=>!x.hidden).length!==1)throw Error('search');els['#q'].value='';els['#cat'].value='camp d’origen buit; recerca pendent';filter();if(r.filter(x=>!x.hidden).length!==35)throw Error('category');"
p=Path('/tmp/v12_filter_test.js');p.write_text(fixture);subprocess.run(['node',str(p)],check=True,capture_output=True)
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(manifest,indent=2))
zp=B/'Mataro_ciutat_escoles_V12_auditoria_origens_2026-11-18.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v12/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(json.dumps(dict(zip=str(zp),fites=116,centres=73,camps_origen=norigin,pendents_camp_origen=35,categories=dict(stats)),ensure_ascii=False))
