# V63 · Instagram

Vuit fitxes d’escoles bressol municipals incorporen el compte compartit de Fundesplai, que hi presta suport educatiu. El compte és de Fundesplai i la fitxa n’indica el paper.

- Instagram de Fundesplai (suport educatiu) · [@fundesplai](https://www.instagram.com/fundesplai/) · [Font](https://escoles.fundesplai.org/es/servicios-para-la-pequena-infancia/escoles-bressol/)
- Instagram de Fundesplai (suport educatiu) · [@fundesplai](https://www.instagram.com/fundesplai/) · [Font](https://escoles.fundesplai.org/es/servicios-para-la-pequena-infancia/escoles-bressol/)
- Instagram de Fundesplai (suport educatiu) · [@fundesplai](https://www.instagram.com/fundesplai/) · [Font](https://escoles.fundesplai.org/es/servicios-para-la-pequena-infancia/escoles-bressol/)
- Instagram de Fundesplai (suport educatiu) · [@fundesplai](https://www.instagram.com/fundesplai/) · [Font](https://escoles.fundesplai.org/es/servicios-para-la-pequena-infancia/escoles-bressol/)
- Instagram de Fundesplai (suport educatiu) · [@fundesplai](https://www.instagram.com/fundesplai/) · [Font](https://escoles.fundesplai.org/es/servicios-para-la-pequena-infancia/escoles-bressol/)
- Instagram de Fundesplai (suport educatiu) · [@fundesplai](https://www.instagram.com/fundesplai/) · [Font](https://escoles.fundesplai.org/es/servicios-para-la-pequena-infancia/escoles-bressol/)
- Instagram de Fundesplai (suport educatiu) · [@fundesplai](https://www.instagram.com/fundesplai/) · [Font](https://escoles.fundesplai.org/es/servicios-para-la-pequena-infancia/escoles-bressol/)
- Instagram de Fundesplai (suport educatiu) · [@fundesplai](https://www.instagram.com/fundesplai/) · [Font](https://escoles.fundesplai.org/es/servicios-para-la-pequena-infancia/escoles-bressol/)
