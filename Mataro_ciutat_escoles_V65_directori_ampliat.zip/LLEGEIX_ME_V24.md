# Mataró, ciutat d’escoles — V24, 19-11-2026

Paquet acumulatiu: obre index.html. No publicat en línia.

# Contrast documental V24 — autorització inicial de Misha / Peques

168 fites, 75 codis, 131 fonts. 64 camps amb una data relacionada amb l’origen; 11 buits. Dels 17 casos revisats, 6 tenen una data qualificada i 11 continuen pendents. Les dates inclouen actes administratius: no equivalen a fundacions ni a primeres classes verificades.

## Nova evidència primària
La Resolució EDC/2102/2004, de 13 de juliol, autoritza l’obertura de Misha, a Mataró: codi 08062547, carrer Rierot 2–4, baixos. L’annex estableix efectes des de l’inici del curs 2004–2005, amb 5 unitats i 66 places. Font H131, Full de disposicions i actes administratius núm. 1014, pàgines impreses 1033–1034. El codi coincideix amb el registre actual de Peques i el mateix emplaçament consta en l’ampliació de 2013 (H120).

Es registra 13-07-2004 com a autorització d’obertura; no s’omple fundacio_any ni s’inventa la data de la primera classe. El canvi de nom a Acuarella de 2018 (H84) i la denominació actual Peques no determinen totes les dates intermèdies de nom i titularitat. Aquesta successió continua pendent de reconstrucció.

## Correcció del pendent
L’autorització inicial de Peques ja no és pendent. Es conserva la recerca anterior com a checkpoint, es retiren les peticions d’autorització inicial d’aquest codi de la cua vigent i s’actualitzen el mapa, la cronologia, l’auditoria i la revisió dels 17 casos. Les 11 consultes restants són esborranys no enviats.

## Fitxers vigents
CSV i GeoJSON canònics; esdeveniments_historics_v24.csv, fonts_historiques_v24.csv, auditoria_origens_v24.csv, revisio_17_camps_v24.csv, consultes_documentals_v24.csv, registre_recerca_v24.csv i resum_auditoria.json. Els fitxers V23 i anteriors són checkpoints; no sumar-los. Obre index.html. Aquest paquet no s’ha publicat en línia.


Validació automatitzada: 168 fites, 75 codis, 131 fonts, 64 camps informats i 11 buits; CSV/GeoJSON/JSON del mapa, JavaScript, enllaços locals, SHA256 i ZIP. 73 punts; geometries i estils conservats. Sense revisió visual al navegador.
