from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile,collections
B=Path(__file__).parent;out=B/'mataro_escoles_v9';shutil.copytree(B/'mataro_escoles_v8',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,a):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(a[0]));w.writeheader();w.writerows(a)
F=read('fonts_historiques_v8.csv'); fm={r['id_font']:r for r in F}
def src(i,t,u,typ='institucional'):
 r=dict(id_font=i,titol=t,url=u,consulta='2026-11-18',tipus=typ,abast='Fets i límits descrits a la fita o a la revisió individual');F.append(r);fm[i]=r
src('H41','CFA Alarona — Història','https://agora.xtec.cat/afaalarona/el-centre/historia/')
src('H42','Estudiar a Mataró — CFA Can Noè','https://estudiaramataro.cat/centre/cfa-can-noe/')
src('H43','Ajuntament — directori El Turó','https://capitaleconomiasocial.mataro.cat/ca/temes/educacio/e-obligatoria-3-16-anys/directori-de-centres/ensenyament-concertat-1/ensenyament-concertat-el-turo')
src('H44','Ajuntament — Els Garrofers, octubre 2009','https://www.mataro.cat/ca/actualitat/noticies/2009/mataro-inaugura-l2019escola-bressol-municipal-els')
src('H45','Escola Camí del Cros — Història','https://agora.xtec.cat/esc-camidelcros/lescola/historia/')
src('H46','Escola Germanes Bertomeu — Història','https://agora.xtec.cat/escolagermanesbertomeu/lescola/historia/')
src('H47','Escola Josep Montserrat — 60 aniversari','https://blocs.xtec.cat/josepmontserrat/?p=2222')
src('H48','Escola Vista Alegre — petita història, 2009','https://blocs.xtec.cat/webceipvistaalegre/')
src('H49','Institut Puig i Cadafalch — PEC V6, 2025','https://inspuig.org/wp/wp-content/uploads/2025/07/GC-PEC_projecte_educatiu_centre_V6.pdf')
src('H50','Ajuntament — acta del Ple, 1 març 2018, convenis bressol','https://www.mataro.cat/ca/lajuntament/ple/actes-del-ple/2018/01-03-2018/acta_ple-view/%2B%2Bwidget%2B%2Bform.widgets.file/%40%40download/2018_03_01.pdf')
src('H51','Ajuntament — IME, acta 20 gener 2004','https://www.mataro.cat/ca/actualitat/reunions-municipals/2004/acta-del-consell-plenari-de-linstitut-municipal')
src('H52','Ajuntament — directori bressol, Figueretes','https://www.mataro.cat/ca/temes/educacio/escoles-bressol-0-3-anys/directori-descoles-bressol-municipals')
src('H53','Ajuntament — nou emplaçament Figueretes, curs 2025–2026','https://www.mataro.cat/ca/actualitat/noticies/2025/el-curs-comenca-amb-la-nova-ubicacio-de-l2019eb-les-figueretes-i-mes-oferta-d2019fp')
src('H54','Ajuntament — rehabilitació Figueretes, octubre 2026','https://www.mataro.cat/ca/actualitat/noticies/2026/llum-verda-al-projecte-de-rehabilitacio-integral-de-l-escola-bressol-les-figueretes')
src('H55','Ajuntament — vacants bressol 2026–2027, Isern 18','https://www.mataro.cat/ca/temes/educacio/escoles-bressol-0-3-anys/oferta-places-ebm-2026-2027.pdf')
src('H56','Fundació el Maresme — història, versió 2017','https://fundaciomaresme.cat/wp-content/uploads/2017/08/20170831-HISTORIA-DE-LA-FUNDACI%C3%93-EL-MARESME_actualitzat.pdf')
src('H57','Brullet de Luna — Escola del Cros i Les Aigües','https://brulletdeluna.com/ca/projecte/escola-del-cros-i-les-aigues/','autoria del projecte arquitectònic')
src('H58','Anca — Qui som','https://ancamataro.com/qui-som/')
src('H59','Nemomarlin — incorporacions curs 2019–2020','https://www.escuelanemomarlin.com/welcome-back-to-school-nemomarlin/')
src('H60','DOGC — Resolució EDF/3357/2026, cessament Nemomarlin','https://portaldogc.gencat.cat/utilsEADOP/AppJava/PdfProviderServlet?documentId=1055287&language=es_ES&type=01')
src('H61','Conservatori Liceu — conveni Valldemia i final seu Centre Catòlic, 2024','https://www.conservatoriliceu.es/noticies/escoles/xarxa-escoles-liceu-incorporacio-maristes-valldemia/')
src('H62','El Carreró — història','https://elcarrero.com/escola-de-musica/el-carrero/')
src('H63','Ajuntament — Medalla al Sagrat Cor, 2014','https://www.mataro.cat/ca/actualitat/noticies/2014/l2019ajuntament-atorga-la-medalla-de-la-ciutat-al')
src('H64','Sol-Ixent — Colla gegantera','https://www.escolasol-ixent.cat/colla-gegantera/')
src('H65','Triangle — Escola de persones adultes','https://triangle-academia.com/es/escuela-de-adultos/')
src('H66','Consorci Sanitari — nova aula hospitalària, 2020–2021','https://www.csdm.cat/ca/actualitat/noticies/1641/els-joves-ingressats-a-salut-mental-han-tingut-aquest-curs-un-professor-per-donar-continuitat-als-seus-estudis')
src('H67','Arenas i altres — Aules d’hospital de dia, 2019','https://ambitsaaf.cat/article/download/1427/2165/3108','article de professionals dels serveis; testimoni directe')
src('H68','DOGC — correcció del canvi de titular Cenafe, 2024','https://portaldogc.gencat.cat/utilsEADOP/AppJava/PdfProviderServlet?documentId=987214&language=es_ES&type=01')
src('H69','Sant Josep — Caràcter propi, 2021','https://santjosepfranciscanes.es/wp/wp-content/uploads/2021/11/CARACTER-PROPI-col-SANT-JOSEP.pdf')
src('H70','Sant Josep — Història web','https://colegiosanjosemataro.com/historia/?verify_token=1')
src('H71','Generalitat — formació persones adultes, fullet 2008','https://repositori.educacio.gencat.cat/bitstream/handle/20.500.12694/5082/formacio_persones_adultes_general_fullet_2008.pdf?isAllowed=y&sequence=13')
src('H72','Ajuntament — immobles, inventari descriptiu 2016','https://www.mataro.cat/transparencia/patrimoni/relacio-dimmobles-propis-i-en-regim-darrendament-ocupats-i-o-adscrits-a-lajuntament/2016')
src('H73','Generalitat — oferta tècniques d’actuació teatral 2024','https://repositori.educacio.gencat.cat/bitstream/handle/20.500.12694/6547/tecniques_actuacio_teatral_arts_esceniques_grau_superior.pdf?isAllowed=y&sequence=1')
src('H74','Heidi Consegal — horari docent 2020–2021','https://escoladansaheidi.com/wp-content/uploads/Horaris.pdf')
src('H75','Picasoques — contacte i codi','https://sompicasoques.com/contacte')
src('H76','Ajuntament — Projectes Singulars 2023, centres participants','https://carecitylab.cat/ca/actualitat/noticies/2023/la-16a-edicio-dels-projectes-singulars-ha-possibilitat-112-estades-formatives-d2019alumnes-de-4t-d2019eso')
src('H77','Generalitat — oferta infantil 0–3, juny 2024','https://repositori.educacio.gencat.cat/bitstream/handle/20.500.12694/6429/Educaci%C3%B3%20infantil_0_3_anys.pdf?isAllowed=y&sequence=1')
src('H78','Ajuntament — reobertura prevista La Llàntia, febrer 2026','https://www.mataro.cat/ca/actualitat/noticies/2026/reobre-escola-bressol-la-llantia-despres-obres-de-millora-edifici')
src('H79','El Xumet — obertura explicada per la directora a La Vanguardia','https://www.lavanguardia.com/vivo/20231029/9333602/gran-hermano-guarderia.html','premsa amb testimoni directe')
src('H80','Snoopy — anunci del centre, El Tot 1658 (2015)','https://www.totmataro.cat/wp-content/revistes/eltot_1658.pdf','anunci del centre en premsa')
src('H81','Vidal Ribas — context musical Mataró, projecte acadèmic','https://repositori.educacio.gencat.cat/bitstream/handle/20.500.12694/7151/PF%20Montserrat%20Vidal%20Ribas.pdf?isAllowed=y&sequence=6','treball acadèmic; contrast secundari')
write('fonts_historiques_v9.csv',F)
a=read('mataro_centres_2026_2027.csv');am={r['codi_centre']:r for r in a};E=read('esdeveniments_historics_v8.csv');oldcodes={e['codi_actual_referencia'] for e in E}
def ev(c,k,d,f,claim,loc='',notes='',end=None,prec=None):
 E.append(dict(id_esdeveniment='HIST-'+str(len(E)+1).zfill(3),id_entitat='ENT-'+c,codi_actual_referencia=c,centre=am[c]['nom'],tipus=k,data_min=d,data_max=end or d,precisio=prec or ('curs' if end else {4:'any',7:'mes',10:'dia'}[len(d)]),afirmacio=claim,id_font=f,font_url=fm[f]['url'],localitzador=loc,estat='documentat; contrast parcial',notes=notes))
ev('08062511','inici_escola','1982','H41','Origen d’Alarona al barri del Pla d’en Boet.','Història')
ev('08062511','trasllat_seu','1985','H41','Trasllat a baixos de l’avinguda Lluís Companys el curs 1985–1986.','Història',end='1986')
ev('08062511','trasllat_seu','2009','H41','Trasllat al carrer Sant Cugat 169–173.','Història')
ev('08061658','titularitat_municipal','2001','H42','Titularitat municipal des del curs 2001–2002.','Descripció','No es dedueix que sigui l’origen de tota l’activitat precedent.',end='2002')
ev('08021193','fundacio','1968','H43','Fundació d’El Turó per la família Trens-Colomer.','Presentació','No confondre amb l’antiga escola pública Turó de Cerdanyola.')
ev('08071056','obertura_classes','2009-09','H44','Entrada en funcionament d’Els Garrofers el setembre de 2009.','Darrer paràgraf','La inauguració anunciada per al 25 d’octubre és un acte diferent.')
ev('08039616','inici_escola','1981','H45','Inici de l’Escola Camí del Cros.','Història')
ev('08039616','inauguracio_edifici','1986','H45','Inauguració de l’edifici escolar.','Història','El despatx d’arquitectura H57 també situa el final d’obra el 1986.')
ev('08020929','inauguracio_escola','1969-09-15','H46','Inauguració de l’Escola Germanes Bertomeu a Rocafonda.','Darrer paràgraf','No es traslladen al codi actual les dates de les escoles anteriors dirigides per les germanes.')
ev('08021041','commemoracio','2023','H47','Commemoració del seixantenari amb una producció musical de la comunitat educativa.','Entrada 1 març 2023','No es fabrica una data exacta de fundació restant seixanta anys.')
ev('08034357','antecedent_aulari','1970','H48','La història de Vista Alegre situa els inicis com a aulari als anys setanta.','Petita història de l’escola','Interval de dècada; no s’afirma un any concret. La narració de les etapes EGB/Primària requereix contrast.',end='1979',prec='dècada')
ev('08052979','creacio_institut','1995','H49','Creació de l’institut en espais de l’antiga Escola Cerdanyola.','PEC, apartat 2, p. 4')
for c,d,loc in [('08046402','1992-10-15','p. 13, Cerdanyola'),('08046414','1992-10-14','p. 13, La Llàntia'),('08046438','1992-10-16','p. 13, Les Figueretes'),('08046426','1992-10-16','p. 13, Rocafonda'),('08046451','1992-10-14','p. 12–13, Tabalet'),('08057515','1997-10-15','p. 14, La Riereta')]:
 ev(c,'conveni_sosteniment',d,'H50','Signatura del conveni de creació i sosteniment amb el Departament d’Ensenyament.',loc,'Data del conveni recollida a l’acta de 2018; no és necessàriament primera obertura.')
ev('08046451','nova_seu','2004-01-08','H51','Entrada de l’alumnat de l’antic Tabalet al nou edifici.','Punt 3.2','La incorporació de l’alumnat nou es descriu per al dia 9.')
ev('08046438','inici_escola','1981','H52','Inici d’activitat de Les Figueretes.','Fitxa Les Figueretes')
ev('08046438','tancament_preventiu_seu','2025','H54','Tancament preventiu de l’edifici per deficiències estructurals.','Antecedents del projecte de rehabilitació','Continua el servei en altres espais; no és el cessament del centre.')
ev('08046438','trasllat_provisional','2025','H53','Nova ubicació al carrer Jaume Isern per al curs 2025–2026, després de l’estada al casal de Cirera.','Inici de curs','H55 confirma Isern 18 per al curs 2026–2027. No s’atribueix al centre el punt de l’edifici antic.',end='2026')
ev('08046414','rehabilitacio_edifici','2026-02','H78','Obres de millora acabades i visita municipal abans de la reobertura anunciada.','Notícia 4 febrer 2026','La nota preveu reobrir el 9 de febrer; no s’ha verificat retrospectivament aquell dia concret.')
ev('08045227','titularitat_i_denominacio','1990','H56','Pas de Santa Bernardeta a titularitat pública amb el nom Les Aigües.','Cronologia 1990','La història de l’entitat anterior i el codi registral actual es mantenen diferenciats.')
ev('08045227','final_obra','1990','H57','Final d’obra de l’edifici de Les Aigües.','Dades de projecte','No equival automàticament a inauguració o primer dia de classe.')
ev('08050235','origen_declarat','1980','H80','Snoopy declara activitat des de 1980 en un anunci del centre.','Anunci i entrevista, curs 2015–2016','Declaració comercial del centre; no prova la data d’autorització ni l’inici de cada seu.')
ev('08067302','obertura_classes','2006','H79','Obertura d’El Xumet l’any 2006 segons l’entrevista a la seva directora.','Introducció i testimoni de la directora','Font periodística amb testimoni directe; autorització administrativa original pendent.')
ev('08066826','obertura_classes','2004','H58','Obertura de la llar d’infants Anca.','Qui som')
ev('08076790','incorporacio_xarxa','2019','H59','Incorporació de Maresme a la xarxa Nemomarlin en el curs 2019–2020.','Noves escoles','La incorporació a la xarxa no prova la primera obertura del local.',end='2020')
ev('08076790','resolucio_cessament','2026-09-15','H60','Resolució que autoritza el cessament de Nemomarlin, codi 08076790.','Apartats 1 i 2','Publicació DOGC 28-09-2026; efectes des del final del curs 2025–2026, sense dia deduït.')
ev('08057126','fundacio','1962','H61','Fundació de l’escola de música pels pianistes Pere González i Josep Canals.','Història de l’escola','H81 dona 1959: es prioritza la font de l’entitat i es conserva la discrepància.')
ev('08057126','tancament_seu','2024','H61','Anunci de tancament de la seu del Centre Catòlic i relleu musical a Valldemia el curs 2024–2025.','Notícia 14 juny 2024','No s’ha acreditat que el codi 08057126 es traslladi a Valldemia; no es tracta com un simple canvi de domicili.')
ev('08070623','inici_escola','1999','H62','Inici de l’escola de música El Carreró.','Presentació','H81 dona 2000. Es prioritza la història del centre i es conserva la discrepància.')
ev('08021028','fundacio','1889','H63','Fundació de l’escola del Sagrat Cor per Carmen del Nen Jesús.','Història del centre','No confondre amb l’antic centre marista homònim.')
ev('08021028','medalla_ciutat','2014-05-29','H63','Lliurament de la Medalla de la Ciutat al col·legi.','Acte de lliurament','L’acord del Ple de concessió és anterior, del 3 d’abril.')
ev('08035374','patrimoni_escolar','1979','H64','Construcció del gegant Sol-Ixent per alumnat de segon i tercer de BUP el curs 1979–1980.','Colla gegantera','Documenta activitat i patrimoni educatiu; no la fundació del centre.',end='1980')
ev('08073363','acreditacio_formacio_adults','2012','H65','Acreditació com a escola de formació de persones adultes des del curs 2012–2013.','Escola de formació d’adults','El centre remet al DOGC 6185, de 03-08-2012; inici general de l’acadèmia pendent.',end='2013')
ev('08062407','inici_aula_hospital_dia','2001','H67','Inici de l’aula d’hospital de dia d’adolescents de Mataró.','p. 128, introducció','Font redactada per professionals del servei. No es confon amb l’aula d’ingrés de 2020.')
ev('08077277','inici_aula_hospitalaria','2020','H66','Estrena de l’aula hospitalària de Salut Mental Infantojuvenil durant el curs 2020–2021.','Notícia 28 juliol 2021','L’hospital confirma el primer curs; no data l’obertura de tota la unitat sanitària.',end='2021')
ev('08075475','autoritzacio_canvi_titular','2020-02-13','H68','Resolució EDU/418/2020 d’autorització de canvi de titular del centre.','Títol i remissió de la correcció de 2024','La correcció de 2024 esmena el NIF, no crea el centre. Obertura de 2016 localitzada en un índex secundari, pendent text original.')
E.sort(key=lambda e:(e['data_min'],e['id_esdeveniment']));write('esdeveniments_historics_v9.csv',E)
counts=collections.Counter(e['codi_actual_referencia'] for e in E);newcodes=set(counts)-oldcodes
assert len(counts)==66 and len(newcodes)==28
# Evidència datada conservada fora de les fites, sense inflar-ne la cobertura.
obs=[
('08065123','2008','H71','Oferta instrumental i de secundària per a persones adultes, codi 08065123, a Puig i Cadafalch 80.','Autorització pròpia i relació administrativa amb Sant Antoni de Pàdua pendents; no s’hereta la fundació de 1905.'),
('08070209','2016','H72','La Caseta documentada a Bonaire 14.','Trobar resolució definitiva d’obertura i data inicial. El Síndic conté un expedient d’autorització pendent; no es dedueix el desenllaç.'),
('08062547','2016','H72','Peques-Misha documentada al Rierot 2–4.','Conciliar noms Peques, Misha i Acuarella i localitzar autorització; compartir adreça no prova continuïtat.'),
('08078695','2023','H76','Picasoques consta entre els centres d’acollida de Projectes Singulars.','Inici i autorització d’obertura pendents; no es confon amb revistes escolars homònimes.'),
('08074291','2024','H77','Petit Somni documentada al Camí Ral 371–373 amb el codi 08074291.','Trobar data inicial i autorització. No usar El Petit Somni de Vilassar de Mar.'),
('08056948','2020–2021','H74','Horari docent de dansa al carrer Concepció 11.','Data d’obertura i autorització pendents. Es descarta una data de 2001 d’un directori que confon dansa i primària.'),
('08078877','2024','H73','Oferta oficial de tècniques d’actuació teatral, codi 08078877, Camí del Mig 71.','Separar origen de Gi Shows, escola no reglada i autorització dels cicles.'),
('08073946','2016','H72','La Fada-Pinotxo documentada a Alfons X el Savi 131.','Conciliar denominacions i autoritzacions; el canvi de nom no es data per inferència.'),
('08021181','1968 / 1970','H69 | H70','La història web dona 1968 i el caràcter propi PDF dona 1970.','Discrepància no resolta: no es publica una fundació única ni es compta com a fita resolta.')]
write('evidencies_sense_fita_v9.csv',[dict(codi_centre=c,centre=am[c]['nom'],data_document=d,fonts=f,afirmacio=cl,pendent=p) for c,d,f,cl,p in obs])
obsmap={c:(d,f,cl,p) for c,d,f,cl,p in obs}
write('revisio_37_centres_v9.csv',[dict(codi_centre=r['codi_centre'],centre=r['nom'],resultat='fites incorporades' if r['codi_centre'] in newcodes else 'evidència o discrepància; fita pendent',fites_noves=sum(e['codi_actual_referencia']==r['codi_centre'] for e in E[0:] if int(e['id_esdeveniment'].split('-')[1])>64),fonts=' | '.join(sorted({e['id_font'] for e in E if e['codi_actual_referencia']==r['codi_centre']})) if r['codi_centre'] in newcodes else obsmap[r['codi_centre']][1],pendent='Completar seus, origen i contrast arxivístic.' if r['codi_centre'] in newcodes else obsmap[r['codi_centre']][3]) for r in a if r['codi_centre'] not in oldcodes])
# Canonical origins only where directly substantiated. Keep conflict types and observations separate.
origin_kinds={'inici_escola','obertura_classes','fundacio','creacio_institut','inici_aula_hospital_dia','inici_aula_hospitalaria'}
for r in a:
 c=r['codi_centre'];r['nombre_fites_documentades']=counts[c];r['estat_activitat_verificat']='presència al CSV; activitat no auditada exhaustivament';r['font_estat_activitat']='';r['nota_seu_actual']=''
 if c in newcodes:
  es=[e for e in E if e['codi_actual_referencia']==c];orig=next((e for e in es if e['tipus'] in origin_kinds),None)
  r['estat_recerca_historica']='fites documentades; història parcial'
  if orig:r.update(fundacio_any='',fundacio_font=orig['font_url'],tipus_data_origen=orig['tipus'],origen_data_min=orig['data_min'],origen_data_max=orig['data_max'])
 elif c in obsmap:r['estat_recerca_historica']='revisat; evidència datada o discrepància; fita pendent'
 if c=='08076790':r.update(estat_activitat_verificat='cessament autoritzat; efectes final curs 2025–2026',font_estat_activitat=fm['H60']['url'],nota_seu_actual='Registre del CSV conservat per traçabilitat; no és un centre actiu confirmat.')
 if c=='08057126':r.update(estat_activitat_verificat='seu Centre Catòlic tancada el 2024; continuïtat del codi pendent',font_estat_activitat=fm['H61']['url'],nota_seu_actual='Relleu de l’oferta musical a Valldemia; no s’assigna aquest codi a la nova oferta.')
 if c=='08046438':r.update(adreca='Carrer de Jaume Isern, 18 (seu provisional)',longitud='',latitud='',control_coordenades='FORA: antiga geometria no correspon a la seu provisional; portal nou pendent',precisio_coordenada='pendent geocodificació de la seu provisional',font_verificacio=(r['font_verificacio']+' | H53 | H54 | H55').strip(' |'),nota_seu_actual='Servei reubicat; l’edifici de baixada de les Figueretes es va tancar preventivament el 2025.')
write('mataro_centres_2026_2027.csv',a)
g=json.loads((out/'mataro_centres_2026_2027.geojson').read_text());g['features']=[f for f in g['features'] if f['properties']['codi_centre']!='08046438']
for f in g['features']:f['properties']=am[f['properties']['codi_centre']]
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(g,ensure_ascii=False,indent=2))
# Seats are observations, not an assertion that all are in use today.
seats=read('mataro_seus_observades.csv')
for s in seats:
 s['vigencia_seu']='observació registral/documental; ús actual no verificat exhaustivament'
 if s['codi_centre']=='08046438':s.update(vigencia_seu='edifici tancat preventivament el 2025',final_ocupacio='2025; dia pendent',estat='seu antiga; no és ubicació vigent del servei',font_verificacio='H54 | H55')
 if s['codi_centre']=='08076790':s.update(vigencia_seu='centre amb cessament efectiu final curs 2025–2026',final_ocupacio='final curs 2025–2026',estat='seu de centre cessat segons DOGC',font_verificacio='H60')
 if s['codi_centre']=='08057126':s.update(vigencia_seu='tancament seu Centre Catòlic anunciat 2024',final_ocupacio='2024; dia pendent',estat='seu tancada; continuïtat registral pendent',font_verificacio='H61')
newseat=dict.fromkeys(seats[0],'');newseat.update(id_seu_observada='SEU-08046438-ISERN',codi_centre='08046438',nom_centre=am['08046438']['nom'],adreca='Carrer de Jaume Isern, 18',curs_observacio='2026/2027',inici_ocupacio='curs 2025–2026',estat='seu provisional documentada; coordenades pendents',font='Ajuntament, oferta 2026–2027',font_verificacio='H53 | H54 | H55',control_coordenades='sense geometria',vigencia_seu='provisional; confirmada octubre 2026');seats.append(newseat)
write('mataro_seus_observades.csv',seats)
sg=json.loads((out/'mataro_seus_v2.geojson').read_text())
for f in sg['features']:f['properties']=next(s for s in seats if s['id_seu_observada']==f['properties']['id_seu_observada'])
(out/'mataro_seus_v2.geojson').write_text(json.dumps(sg,ensure_ascii=False,indent=2))
d=read('discrepancies_i_pistes_v7.csv')
for i,c,t,aa,bb,fs,dec in [
('D06','Sant Josep','fundació','Història web: 1968','Caràcter propi: 1970','H69 | H70','Conservar afirmacions separades; origen únic pendent.'),
('D07','Liceu Mataró','fundació','Font de l’entitat: 1962','Treball acadèmic: 1959','H61 | H81','Prioritat a la font de l’entitat; discrepància conservada.'),
('D08','El Carreró','origen','Història del centre: 1999','Treball acadèmic: 2000','H62 | H81','Prioritat a la història del centre; no s’unifiquen les dates.'),
('D09','Nemomarlin','vigència','Presència al CSV 2026–2027','Cessament efectiu final curs 2025–2026','CSV | H60','Mantenir fila per traçabilitat i marcar cessament; no presentar 75 com a centres actius confirmats.'),
('D10','Les Figueretes','seu','CSV: antiga ubicació','Ajuntament: seu provisional Isern 18','CSV | H53 | H54 | H55','Retirar punt antic del mapa principal; guardar-lo a inventari amb vigència històrica.'),
('D11','Liceu Mataró','seu i codi','CSV manté centre','Entitat tanca seu i situa relleu a Valldemia','CSV | H61','No traslladar mecànicament codi i punt a Valldemia.')]:d.append(dict(id=i,centre=c,tema=t,dada_a=aa,dada_b=bb,font=fs,decisio=dec))
write('discrepancies_i_pistes_v9.csv',d)
cover=[dict(codi_centre=r['codi_centre'],centre=r['nom'],naturalesa_actual=r['naturalesa'],fites_documentades=counts[r['codi_centre']],estat='fites; història parcial' if counts[r['codi_centre']] else 'revisat; fita pendent',nota='Denominador fix: 75 codis del CSV; no tots tenen activitat actual confirmada') for r in a];write('cobertura_recerca_v9.csv',cover)
chron=(out/'cronologia.html').read_text();names=sorted({(e['codi_actual_referencia'],e['centre']) for e in E},key=lambda x:x[1])
opts='<option value="">Tots els centres documentats</option>'+''.join('<option value="'+c+'">'+html.escape(n)+'</option>' for c,n in names)
chron=re.sub(r'(<select id="centre">).*?(</select>)',lambda m:m[1]+opts+m[2],chron,count=1,flags=re.S)
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['data_min']+'–'+e['data_max'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(fm[e['id_font']]['titol'])+' · '+html.escape(e['localitzador'])+'</a></p></article>' for e in E)
chron=re.sub(r'<article.*?</article>(?:<article.*?</article>)*',lambda m:items,chron,count=1,flags=re.S).replace('64 fites documentades de 38 centres (50,7% de 75)',f'{len(E)} fites documentades de 66 dels 75 registres de base (88%)').replace('V8','V9').replace('El mapa mostra les seus actuals','El mapa mostra localitzacions registrals i correccions documentades');(out/'cronologia.html').write_text(chron)
idx=(out/'index.html').read_text().replace('versió 8','versió 9').replace('64 fites',f'{len(E)} fites').replace('38 centres amb alguna fita documentada','66 centres amb alguna fita documentada').replace('38/75 centres · 50,7%','66/75 registres · 88%')
idx=idx.replace('Cens registral 2026–2027','Base de 75 registres del CSV 2026–2027; inclou cessaments i seus pendents de conciliació')
idx=idx.replace('Públic / privat indica naturalesa:', 'Gris: cessament o seu tancada documentats. Les Figueretes figura a Isern 18, encara sense punt. Públic / privat indica naturalesa:')
idx=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',idx,count=1,flags=re.S)
idx=idx.replace("esc(r.naturalesa)+' · '+esc(r.codi_centre)+'</small></article>'", "esc(r.naturalesa)+' · '+esc(r.codi_centre)+'<br>'+esc(r.estat_activitat_verificat)+'<br>'+esc(r.nota_seu_actual)+'</small></article>'")
idx=idx.replace("color:r.naturalesa==='Públic'?'#216c5a':'#ac592e'", "color:r.font_estat_activitat?'#777':r.naturalesa==='Públic'?'#216c5a':'#ac592e'")
idx=idx.replace("+'<br>Origen: '+esc(", "+'<br>'+esc(r.estat_activitat_verificat)+'<br>'+esc(r.nota_seu_actual)+(r.font_estat_activitat?'<br><a target=\"_blank\" rel=\"noopener\" href=\"'+esc(r.font_estat_activitat)+'\">Font de vigència</a>':'')+'<br>Origen: '+esc(")
idx=idx.replace("a.length+' centres · '", "a.length+' registres de centre · '").replace("verd: públic · taronja: privat'", "verd: públic · taronja: privat · gris: cessament o seu tancada'")
(out/'index.html').write_text(idx)
rows=''.join('<tr><td>'+html.escape(r['nom'])+'</td><td>'+str(counts[r['codi_centre']])+'</td><td>'+('Fites; història parcial' if counts[r['codi_centre']] else 'Revisat; fita pendent')+'</td></tr>' for r in sorted(a,key=lambda r:r['nom']))
(out/'cobertura.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Cobertura de recerca V9</title><style>body{font:17px system-ui;max-width:980px;margin:40px auto;padding:20px;color:#243b35;background:#f7f5ed}table{border-collapse:collapse;width:100%}td,th{text-align:left;padding:10px;border-bottom:1px solid #ccc}a{color:#25634e}</style><h1>66 de 75 registres: 88%</h1><p>Revisió inicial feta dels 37 casos pendents de V8: 28 amb fites incorporades i 9 amb evidència o discrepàncies encara sense fita. No són 66 històries completes. El denominador conserva els 75 codis del CSV i no afirma que tots siguin actius.</p><p><a href="index.html">Mapa</a> · <a href="cronologia.html">Cronologia</a> · <a href="revisio_37_centres_v9.csv">Revisió dels 37</a> · <a href="evidencies_sense_fita_v9.csv">Nou casos pendents</a></p><table><thead><tr><th>Centre</th><th>Fites</th><th>Recerca</th></tr></thead><tbody>'+rows+'</tbody></table></html>')
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=9,fites_historiques=len(E),centres_amb_fites=66,centres_pendents=9,cobertura_percent=88.0,denominador_centres=75,significat_denominador='codis del CSV aportat; no nombre de centres actius confirmats',centres_nous_v9=28,fites_noves_v9=len(E)-64,casos_revisats_v9=37,punts_centre=73,observacions_seus=len(seats));(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V9.md').write_text(f'''# Mataró, ciutat d’escoles — V9
Guia vigent del paquet acumulatiu del 18-11-2026.

## Resultat
Revisió inicial dels 37 casos pendents de V8: 28 centres amb noves fites, 9 amb evidència o discrepàncies sense fita incorporada. Total: 66/75 (88%), {len(E)} fites ({len(E)-64} noves). No són històries completes ni un cens de 75 centres actius verificats. El denominador continua sent el conjunt de 75 codis del CSV aportat per permetre comparar versions.

## Obre
index.html: mapa i llista. cronologia.html: fites datades amb fonts. cobertura.html: progrés i pendents. Mapes amb Internet; sense publicació en línia en aquesta fase.

## Dades vigents
esdeveniments_historics_v9.csv, fonts_historiques_v9.csv, cobertura_recerca_v9.csv, revisio_37_centres_v9.csv, evidencies_sense_fita_v9.csv, discrepancies_i_pistes_v9.csv, mataro_centres_2026_2027.csv/.geojson, mataro_seus_observades.csv i mataro_seus_v2.geojson. Fitxers de versions anteriors: checkpoints, no sumar-ne registres. El nom del GeoJSON de seus es conserva per compatibilitat.

## Correccions de vigència
Nemomarlin: cessament autoritzat segons DOGC EDF/3357/2026, amb efectes des del final del curs 2025–2026. Fila conservada amb avís; no centre actiu confirmat. Liceu: seu Centre Catòlic tancada segons la mateixa entitat el 2024; relleu de l’oferta a Valldemia, sense traslladar-hi el codi 08057126. Els punts d’aquestes dues seus figuren en gris per transparència documental.
Les Figueretes: servei provisional a Jaume Isern 18, documentat per a 2026–2027; l’antiga seu tancada el 2025 es conserva a inventari però es retira del mapa principal. No s’inventa coordenada del nou portal. Ara hi ha 73 punts de centre i 78 observacions de seu, algunes històriques: no equivalen a 78 seus actives. Les noves fites no creen geometries històriques per inferència.

## Nou casos sense fita
Col·legi Salesià, La Caseta, Peques, Picasoques, Petit Somni, Heidi Consegal, GiEscola, La Fada i Sant Josep. Tots tenen una entrada d’evidència i una tasca concreta. Les observacions de presència o oferta datada es mantenen separades de les fites per no inflar el percentatge.
Sant Josep: web 1968 vs PDF institucional 1970. No s’ha triat una fundació única. No s’atribueix a Col·legi Salesià 08065123 la fundació de 1905 de Sant Antoni de Pàdua 08021089.

## Altres cauteles
Liceu: es prioritza 1962 de la institució sobre 1959 d’un treball acadèmic. El Carreró: 1999 del centre sobre 2000 d’aquell treball. Snoopy: 1980 segons anunci del centre, amb precisió d’any i pendent de verificació registral; no es deriva l’origen de l’experiència comercial anunciada. El Xumet: 2006 segons entrevista a la directora, pendent d’autorització original. Vista Alegre: dècada de 1970, no any inicial concret. Convenis de sosteniment de bressols: dates legals, no primer dia de classe. Dates d’efectes, resolució, publicació i ocupació no s’intercanvien. El filtre temporal és de fites, no de totes les escoles actives en cada any.

## Validació
Recomptes i integritat de codis, fonts, intervals, enllaços locals, propietats GeoJSON, dades del visor, sintaxi JavaScript, SHA256 i ZIP. Sense inspecció visual amb navegador ni contrast arxivístic complet. Els programes de versions anteriors es conserven com a traçabilitat i alguns requereixen els seus directoris d’entrada originals.
''')
shutil.copy2(__file__,out/'amplia_mataro_v9.py')
assert len(a)==75 and len({r['codi_centre'] for r in a})==75
assert len({e['id_esdeveniment'] for e in E})==len(E)
assert all(e['id_font'] in fm and e['codi_actual_referencia'] in am and e['data_min']<=e['data_max'] for e in E)
assert {c for c,*_ in obs}==set(am)-set(counts)
assert len(g['features'])==73 and all(f['properties']['codi_centre']!='08046438' for f in g['features'])
assert len(re.findall('<article data-year=',chron))==len(E)
for n in ['index.html','cronologia.html']:
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',(out/n).read_text(),re.S)):Path('/tmp/v9_'+n+str(i)+'.js').write_text(s)
for name in ['index.html','cronologia.html','cobertura.html']:
 for link in re.findall(r'href="([^"#]+)"',(out/name).read_text()):
  if not link.startswith(('http:','https:')) and not link.startswith(chr(39)):assert (out/link).exists(),link
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(manifest,indent=2))
zp=B/'Mataro_ciutat_escoles_V9_revisio_resta_2026-11-18.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v9/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(json.dumps(dict(zip=str(zp),fites=len(E),centres=len(counts),nous=len(newcodes),pendents=len(obs),seus=len(seats)),ensure_ascii=False))
