# V61 · Instagram

Dues fitxes guanyen un enllaç. El compte de l’Escola Marta Mata correspon a l’associació de famílies i s’identifica a la fitxa.

- Instagram de Mataró Jiu-Jitsu · [@matarojiujitsu](https://www.instagram.com/matarojiujitsu/) · [Font](https://atlasmataro.com/jiu-jitsu-mataro/)
- Instagram de l’AFA de l’Escola Marta Mata · [@ampa.martamata](https://www.instagram.com/ampa.martamata/) · [Font](https://agora.xtec.cat/esc-mmata-mataro/ampa/)
