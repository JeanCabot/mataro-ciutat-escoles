# Contrast documental V23 — Angeleta Ferrer i l’escola de la Sra. Pilar

Dues fites noves; cap camp d’origen nou. 167 fites, 63 camps informats i 12 buits. L’objectiu d’acreditar els 17 orígens no està completat.

## La primària anterior a l’institut
La història publicada per Germanes Bertomeu (H46) descriu una escola graduada de nenes al carrer Sant Cugat, dirigida per Pilar Bertomeu i, després, per Conxita. Situa el trasllat a l’antic cafè La Unió de la plaça de Cuba i el nom Nuestra Señora del Pilar el 1940. És una fita de localització i denominació d’una escola ja existent; no és fundació. La història d’Angeleta Ferrer (H11) confirma l’ús de l’edifici per la primària Pilar, però cal provar la continuïtat institucional i del codi actual.
No s’equipara aquesta escola antiga al centre de Rocafonda inaugurat el 1969 amb el nom Germanes Bertomeu. La coincidència de mestres o d’homenatge no transfereix automàticament codis i dates.

## Correcció: convocatòria, no acord aprovat
La pàgina municipal del Ple de 08-02-2001 és una ordre del dia, dictada per Decret 737/2001 de 05-02-2001. El punt 27 proposa canviar Mare de Déu del Pilar per Angeleta Ferrer. No conté el debat, el resultat de la votació ni la resolució d’Ensenyament. La V22 l’havia descrit al dossier com un acord localitzat: aquesta qualificació era excessiva i es corregeix. El camp d’origen i les dates de canvi efectiu del nom no s’omplen a partir d’aquesta convocatòria.
El cos de la convocatòria conté una menció a 2000; es conserva la data del decret 2001, coherent amb el títol i l’assumpte. La data web de 2003 no és data del Ple.

## Documentació que ara cal cercar
Expedient de l’escola graduada de nenes del carrer Sant Cugat; expedient de trasllat de 1940; continuïtat amb el codi 08020905; acta completa de 08-02-2001 i resolució de canvi de nom. La petició concreta s’ha actualitzat a consultes_documentals_v23.csv. No s’ha enviat.

## Altres vies contrastades
Cerques per Dúnia i Heidi Consegal, Peques/Acuarella, Picasoques/Pica-soques i Nemomarlin no han aportat cap autorització inicial nova atribuïble inequívocament. Els resultats són directoris, presències i actes ja coneguts. No se’n dedueix una data ni inexistència de l’expedient. Les cerques del llibre Una escola avançada continuen portant a la notícia municipal de 2007, no al text complet. No es declara consultat el llibre.

## Fitxers vigents
Base CSV i GeoJSON; esdeveniments_historics_v23.csv, fonts_historiques_v23.csv, auditoria_origens_v23.csv, revisio_17_camps_v23.csv, registre_recerca_v23.csv, consultes_documentals_v23.csv i resum_auditoria.json. Els fitxers V22 i anteriors són checkpoints; no sumar-los. Es conserven les consultes de la V22 per als altres centres, sense presentar-les com a noves verificacions.


## CFA Can Noè · 08061658
informat: inici declarat

PEC propi, pp. 3–4: servei des de 1979. 1979 data el servei històric, no l’alta del codi; 2001–02 data titularitat.

Document necessari: Expedient de creació i primera matrícula, si es vol verificar primer curs i continuïtat registral.

## Col·legi Salesià · 08065123
pendent: continuïtat de codis

Història pròpia, pp. 10–11: cursos, CFA i unificació; directori de 2007 amb 08065123 localitzat. 1992 és origen declarat d’un CFA de l’obra; no s’ha provat la continuïtat amb el codi actual.

Document necessari: Expedient d’alta 08065123 i relació amb 08021089; actes de 1992 i unificació 2005.

## EB privada Peques · 08062547
pendent: autorització inicial

ENS/2170/2013 amplia i ENS/2711/2018 canvia titular i nom. Cap acte inicial localitzat; cap data deduïda del número de codi.

Document necessari: Resolució d’autorització prèvia a ENS/2170/2013 i primera matrícula; noms Peques i Acuarella Mataró.

## EB privada Picasoques · 08078695
pendent: autorització inicial

Web pròpia identifica codi i Ronda República 27; cerques per Picasoques, Pica-soques i Pica Soques. No heretar dates de revistes homònimes de Castellbisbal ni del projecte web de 2013.

Document necessari: Expedient d’autorització 08078695, llicència d’activitat a República 27 i primer curs.

## Escola Angeleta Ferrer · 08020905
pendent: origen i continuïtat institucional

H46: trasllat de la graduada de nenes a plaça de Cuba el 1940. H130: proposta de canvi de nom en convocatòria de 2001, no acord. 1940 és trasllat, no fundació. La convocatòria no acredita aprovació del nom. No s’hereten dates de l’edifici ni de secundària.

Document necessari: Expedient de l’escola graduada de nenes del carrer Sant Cugat, trasllat de 1940 i continuïtat amb 08020905; acta del Ple de 08-02-2001 i resolució d’Ensenyament del canvi de nom.

## Escola Bressol Cerdanyola · 08046402
pendent: discrepància d’origen

MASMM atribueix creació a 1979; un arxiu geganter registra un vuitè aniversari el 1989. No convertir la resta 1989−8 en any fundacional; cal distingir municipalització i obertura.

Document necessari: Actes de creació, municipalització i primer curs de Cerdanyola; consultar Una escola avançada (2007).

## Escola de Dansa Heidi Consegal · 08056948
pendent: origen sota nom Dúnia

Fullet oficial de Dansa 2007: Dúnia 08056948, Concepció 11; coincideix amb el codi actual Heidi Consegal. 2007 és presència al directori, no obertura; es descarta 2001 del directori que la qualifica erròniament de primària.

Document necessari: Autorització original de Dúnia i expedient del canvi de denominació a Heidi Consegal; primer curs.

## Escola Josep Manuel Peramàs · 08020917
informat parcial: inauguració

Premsa contemporània de 02-02-1972: inauguració i funcionament des de setmanes abans. No data el primer dia de classe ni la creació legal; no es deriva 1971 d’un aniversari.

Document necessari: Ordre de creació i primer llibre de matrícula del grup Peramas.

## Escola Josep Montserrat · 08021041
informat parcial: constitució administrativa

Ordre de 24-07-1975: transformació del patronat de Caixa Laietana a règim ordinari. No data l’obertura del centre anterior; 1962, 1963 i 1964 continuen requerint conciliació.

Document necessari: Expedient del patronat i notícia Escuela Josep Montserrat en Peramas, Diari de Mataró, 21-09-1962, p. 1.

## Institut Damià Campeny · 08021302
informat: creació administrativa

Decret de 1969: secció; Decret 2165/1975: institut; Ordre de 1977: nom Damiá Campeny. No heretar la data del COPEM ni la construcció de 1966; primer dia de classe pendent.

Document necessari: Primera matrícula de l’institut 1975–1976, si es vol precisar l’inici efectiu.

## Llar d'infants La Llàntia · 08046414
pendent: obertura anterior al trasllat

Fent camí documenta trasllat el 1995–1996; gegants daten nous locals el 27-01-1996. 1996 no és fundació; no heretar 1978 de l’escola de primària homònima.

Document necessari: Creació i primer curs al carrer Boixa; consultar Una escola avançada (2007).

## Llar d'infants La Riereta · 08057515
pendent: obertura i conveni

La Iaia es crea el 1996–1997 quan feia poc que s’havia inaugurat l’escola; conveni de 15-10-1997. No equivaler la geganta ni el conveni al primer dia de classe.

Document necessari: Acta d’obertura, primer curs i conveni de creació de 15-10-1997; consultar Una escola avançada (2007).

## Llar d'infants Rocafonda · 08046426
pendent: obertura institucional

Edifici educatiu 1985–1987 i conveni de 16-10-1992 documentats. Construcció i conveni no són origen; la memòria d’una inauguració un Primer de Maig no n’indica l’any.

Document necessari: Acta d’inauguració i primer curs de la bressol; continuïtat amb guarderies veïnals si existeix.

## Llar d'infants Tabalet · 08046451
pendent: centres anteriors

Trasllat dels dos Tabalet al nou edifici el 8 i 9 de gener de 2004 documentat; conveni de 1992. 2004 és trasllat i ampliació; no s’adopta com a fundació dels dos centres anteriors.

Document necessari: Creació dels Tabalet I i II, primers cursos i unificació; consultar Una escola avançada (2007).

## LLI privada Nemomarlin Maresme · 08076790
pendent: obertura inicial

Xarxa Nemomarlin: incorporació el 2019–2020; cessament efectiu final 2025–2026. No prendre una previsió d’apertura 2018–2019 ni l’adhesió a la franquícia com a obertura real.

Document necessari: Autorització original 08076790, titulars i noms anteriors, primera matrícula al carrer Vallespir 2.

## Sant Josep · 08021181
pendent: discrepància 1968/1970

Història pròpia declara 1968; Caràcter propi 1970; URC separa classes i comunitat de 1970; benedicció 04-01-1970. No es construeix un interval 1968–1970 com si fos una incertesa sobre un mateix fet; són afirmacions i esdeveniments a separar.

Document necessari: Acta fundacional, primera matrícula i autorització; aclariment explícit dels anys 1968 i 1970.

## Sol-Ixent · 08035374
informat: fundació declarada

MASMM declara fundació per la família Sancho i Caballé el 1970. No és data d’autorització; no confondre amb ampliació BUP de 1980 ni societat mercantil de 2002.

Document necessari: Autorització inicial i primera matrícula, si es vol passar de fundació declarada a primer curs verificat.

