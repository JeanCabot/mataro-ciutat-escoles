# Mataró, ciutat d’escoles · V55

164 fitxes al directori, 50 més que a la V53, a banda de la capa de lleure i casals.

Hwarang Mataró consta al número 2 a la web del centre i al directori municipal. El marcador orientatiu utilitza el punt de l’ICGC del número 1 del mateix passatge. La fitxa indica aquesta precisió.

El fitxer incorporacions_V55_fonts.csv documenta les 50 incorporacions.
