from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile,collections,subprocess
B=Path(__file__).parent;out=B/'mataro_escoles_v17';shutil.copytree(B/'mataro_escoles_v16',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,rows):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['codi_centre','centre','id_esdeveniment','tipus','data','id_font','afirmacio','decisio']);w.writeheader();w.writerows(rows)
a=read('mataro_centres_2026_2027.csv');am={r['codi_centre']:r for r in a};E=read('esdeveniments_historics_v16.csv');F=read('fonts_historiques_v16.csv');fm={r['id_font']:r for r in F}
def src(i,t,u,typ):
 r=dict(id_font=i,titol=t,url=u,consulta='2026-11-18',tipus=typ,abast='Fets i límits indicats en les fites i la revisió');F.append(r);fm[i]=r
src('H106','BOE — Ordre de 31 d’agost de 1964, escoles en règim de consells escolars primaris','https://www.boe.es/boe/dias/1964/09/28/pdfs/A12730-12730.pdf','normativa; pàgina 12730 consultada, continuació no necessària per a la fita')
src('H107','BOE — Ordre de 8 de gener de 1979, centres estatals de Barcelona','https://www.boe.es/diario_boe/txt.php?id=BOE-A-1979-5841','normativa; text consultat')
src('H108','BOE — Ordre de 17 d’agost de 1979, unitats de preescolar de Barcelona','https://www.boe.es/diario_boe/txt.php?id=BOE-A-1979-23103&lang=es','normativa; text consultat')
src('H109','Campdepadròs arquitectes — IES Damià Campeny','https://campdepadrosarq.wordpress.com/2014/05/12/promocio-publica-3/','fitxa d’obra publicada per l’equip d’arquitectura')
src('H110','MASMM — Mataró: noms de llocs, Escola Josep Montserrat i Cuadrada','https://masmm.org/arxiu/llocs/02410.html','síntesi històrica retrospectiva; pista d’origen pendent de contrast')
def ev(c,k,d,f,claim,loc,notes,end=None):
 E.append(dict(id_esdeveniment='HIST-'+str(max(int(x['id_esdeveniment'].split('-')[1]) for x in E)+1).zfill(3),id_entitat='ENT-'+c,codi_actual_referencia=c,centre=am[c]['nom'],tipus=k,data_min=d,data_max=end or d,precisio='curs' if end else 'any' if len(d)==4 else 'dia',afirmacio=claim,id_font=f,font_url=fm[f]['url'],localitzador=loc,estat='documentat; contrast parcial',notes=notes))





ev('08021041','creacio_unitats','1964-08-31','H106','L’Ordre de 31 d’agost de 1964 crea una unitat de nens, tres de pàrvuls i una maternal al grup escolar José Montserrat, dependent del consell escolar primari de la Caixa d’Estalvis de Mataró.','BOE 233, 28-09-1964, p. 12730, apartat 1','Creació d’unitats dins del grup escolar; no prova que sigui la creació inicial de tot el centre. Origen pendent de conciliar amb altres dates publicades.')
ev('08020917','reorganitzacio_unitats','1979-01-08','H107','L’Ordre de 8 de gener de 1979 desglossa vuit unitats d’EGB de Peramàs per integrar-les al nou Camí del Mig i modifica altres unitats de Peramàs.','Apartats primer (Camí del Mig) i tercer (J. M. Peramás)','Relació entre centres documentada; no és fundació de Peramàs ni una nova data d’origen.')
ev('08020917','transformacio_unitats','1979-08-17','H108','L’Ordre de 17 d’agost de 1979 transforma dues unitats d’EGB de J. M. Peramás en dues unitats de preescolar.','Apartat segon, municipi Mataró','Canvi de composició administrativa; no és el primer dia de classe ni la fundació.')
ev('08021302','projecte_arquitectonic','1993','H109','La fitxa de l’equip d’arquitectura data els projectes del Damià Campeny entre 1993 i 1998.','Fitxa tècnica, camp Dates','Període de projectes arquitectònics, no curs acadèmic ni data de creació del centre.',end='1998')
E[-1]['precisio']='període'
ev('08021302','obres_edifici','1998','H109','La fitxa de l’equip d’arquitectura data la construcció de l’actuació del Damià Campeny entre 1998 i 1999, conservant un aulari existent.','Fitxa tècnica i primer paràgraf de descripció','Obres amb conservació d’un aulari; no s’interpreta com la fundació ni la inauguració de totes les instal·lacions.',end='1999')
E[-1]['precisio']='període'
ev('08021302','ampliacio_us_seu','2016','H32','Des del curs 2016–2017 el segon de batxillerat del Damià Campeny es fa a l’edifici contigu de l’EOI del Maresme i del Centre de Recursos Educatius, segons la presentació del centre.','Presentació, paràgraf sobre edificis','Ampliació dels espais docents per manca d’espai; no s’afegeix una coordenada de seu sense verificació.',end='2017')
E.sort(key=lambda e:(e['data_min'],e['id_esdeveniment']));counts=collections.Counter(e['codi_actual_referencia'] for e in E)
assert len(E)==140 and len(counts)==73
write('esdeveniments_historics_v17.csv',E);write('fonts_historiques_v17.csv',F)
for r in a:r['nombre_fites_documentades']=counts[r['codi_centre']]
write('mataro_centres_2026_2027.csv',a)
g=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in g['features']:f['properties']=am[f['properties']['codi_centre']]
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(g,ensure_ascii=False,indent=2))
write('registre_recerca_v17.csv',[dict(data_consulta='2026-11-18',via='Text consultat',consulta=f['titol'],resultat='Fita documentada o pista identificada; veure cronologia i nota V17.',limit='No resol automàticament l’origen del centre.') for f in F if f['id_font'] in {'H106','H107','H108','H109','H110'}])
(out/'pistes_documentals_v17.md').write_text("""# Orígens pendents: contrast V17
Josep Montserrat: H110 atribueix a 1964 el patrocini de la construcció per la Caixa. H106 crea unitats dins del grup escolar el 31-08-1964; això no prova per si sol la creació inicial del centre. Hi ha pistes secundàries que remeten a 1962 i una commemoració escolar de 2023 ja documentada (HIST-074), que no es converteix en 1963 per resta. Cal consultar la premsa contemporània i l’expedient de creació. No s’ha consultat encara la notícia de 21-09-1962 citada en bibliografia secundària. Camp canònic d’origen buit.
Peramàs: H107 i H108 són modificacions de 1979, no creació inicial. El cinquantenari de 2021–2022 no genera una data exacta per resta. PEC consultat: descriu la reflexió del projecte des del curs 2018–2019, sense resoldre l’origen inicial; no s’hi atribueix una data fundacional.
Damià Campeny: H109 distingeix projectes 1993–1998 i construcció 1998–1999 amb conservació d’un aulari. H32 documenta l’ús de l’edifici contigu des de 2016–2017. Són fites de seu; l’origen institucional segueix pendent. No es trasllada la història de Satorras ni l’antiguitat de l’edifici al codi actual sense conciliar-la.
""")
# Audit is rebuilt from the updated canonical data and events.
by=collections.defaultdict(list)
for e in E:by[e['codi_actual_referencia']].append(e)
audit=[]
for r in a:
 c=r['codi_centre'];es=sorted(by[c],key=lambda e:(e['data_min'],e['id_esdeveniment']));first=es[0] if es else {};typ=r['tipus_data_origen'];d=r['origen_data_min']
 if not d:cat='camp d’origen buit; recerca pendent'
 elif 'antecedent' in typ or 'patronat' in typ or 'predecessor' in typ:cat='antecedent; no obertura del centre actual'
 elif 'autorització' in typ:cat='autorització d’obertura; no primeres classes'
 elif 'administrativa' in typ or 'creació' in typ or 'transformació' in typ or typ=='creacio_escola':cat='constitució o creació; classes pendents de distingir'
 elif 'projecte' in typ:cat='inici de projecte; no autorització del codi'
 else:cat='data d’origen declarada; contrast segons font'
 specific={
 '08065123':'Conciliar codis 08065123 i 08021089 i trobar autorització pròpia. No heretar 1905 ni 2004.',
 '08078695':'Autorització i primer curs pendents. Corregir coordenada del CSV només amb portal 27 documentat.',
 '08073946':'Autorització i efectes legals confirmats; primer curs real i relació amb Pinotxo pendents.',
 '08078877':'2012 és consolidació del projecte segons la directora; alta del codi i autorització de cicles pendents.',
 '08056948':'2015 és actuació escolar; no és fundació ni autorització.',
 '08021181':'Conciliar 1968/1970: classes inicials, comunitat religiosa i actes d’inauguració.',
 }
 audit.append(dict(codi_centre=c,centre=r['nom'],fites_documentades=len(es),categoria_origen=cat,tipus_data_origen=typ,origen_data_min=d,origen_data_max=r['origen_data_max'],font_origen=r['fundacio_font'],primera_fita_id=first.get('id_esdeveniment',''),primera_fita_data=first.get('data_min',''),primera_fita_tipus=first.get('tipus',''),primera_fita_font=first.get('font_url',''),control='Primera fita cronològica no equival a fundació.',tasca_prioritaria=specific.get(c,'Precisar què data la font d’origen i contrastar-la.' if d else 'Cercar origen del centre; no adoptar la primera fita com a fundació.')))
write('auditoria_origens_v17.csv',audit);stats=collections.Counter(x['categoria_origen'] for x in audit);norigin=sum(bool(x['origen_data_min']) for x in audit);assert norigin==56
# Candidates are extracted from documented events but do not silently overwrite canonical origins.
missing=[e for e in E if not next(r for r in a if r['codi_centre']==e['codi_actual_referencia'])['origen_data_min'] and e['tipus'] in {'origen_declarat','inauguracio_escola','antecedent_aulari','consolidacio_projecte_escolar','autoritzacio_obertura'}]
write('pistes_origen_per_revisar_v17.csv',[dict(codi_centre=e['codi_actual_referencia'],centre=e['centre'],id_esdeveniment=e['id_esdeveniment'],tipus=e['tipus'],data=e['data_min'],id_font=e['id_font'],afirmacio=e['afirmacio'],decisio='Candidat de revisió; no afegit al camp canònic d’origen automàticament.') for e in missing])
chron=(out/'cronologia.html').read_text();opts='<option value="">Tots els centres documentats</option>'+''.join('<option value="'+c+'">'+html.escape(n)+'</option>' for c,n in sorted({(e['codi_actual_referencia'],e['centre']) for e in E},key=lambda x:x[1]));chron=re.sub(r'(<select id="centre">).*?(</select>)',lambda m:m[1]+opts+m[2],chron,count=1,flags=re.S)
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['data_min']+'–'+e['data_max'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(fm[e['id_font']]['titol'])+' · '+html.escape(e['localitzador'])+'</a></p></article>' for e in E)
chron=re.sub(r'<article.*?</article>(?:<article.*?</article>)*',lambda m:items,chron,count=1,flags=re.S).replace('134 fites documentades de 73 dels 75 registres de base (97,3%)','140 fites documentades de 73 dels 75 registres de base (97,3%)').replace('V16','V17');(out/'cronologia.html').write_text(chron)
idx=(out/'index.html').read_text().replace('versió 16','versió 17').replace('134 fites','140 fites').replace('71 centres amb alguna fita documentada','73 centres amb alguna fita documentada').replace('71/75 registres · 94,7%','73/75 registres · 97,3%');idx=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',idx,count=1,flags=re.S);(out/'index.html').write_text(idx)
style='<style>body{max-width:1200px;margin:32px auto;padding:20px;font:16px system-ui;color:#223b39;background:#f5f1e8}h1{font:32px Georgia}table{border-collapse:collapse;width:100%;background:white}td,th{text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid #ccd5ce}small{display:block;line-height:1.5}a{color:#16665c}input,select{padding:10px;margin:8px 8px 16px 0;max-width:100%;font:inherit}.scroll{overflow:auto}</style>'
rows=''.join('<tr data-search="'+html.escape(x['centre'].lower()+' '+x['codi_centre'],quote=True)+'" data-cat="'+html.escape(x['categoria_origen'],quote=True)+'"><td><b>'+html.escape(x['centre'])+'</b><small>'+x['codi_centre']+'</small></td><td>'+str(x['fites_documentades'])+'</td><td>'+html.escape(x['categoria_origen'])+'<small>'+html.escape(x['origen_data_min']+' '+x['tipus_data_origen'])+'</small></td><td>'+html.escape(x['primera_fita_data']+' '+x['primera_fita_tipus'])+'</td><td>'+html.escape(x['tasca_prioritaria'])+'</td></tr>' for x in sorted(audit,key=lambda x:x['centre']))
opts='<option value="">Totes les categories</option>'+''.join('<option>'+html.escape(c)+'</option>' for c in sorted(stats))
script="""const q=document.querySelector('#q'),cat=document.querySelector('#cat'),rows=[...document.querySelectorAll('tbody tr')];function filter(){let n=0;for(const r of rows){const show=r.dataset.search.includes(q.value.toLowerCase().trim())&&(!cat.value||r.dataset.cat===cat.value);r.hidden=!show;if(show)n++;}document.querySelector('#n').textContent=n+' registres';}q.addEventListener('input',filter);cat.addEventListener('change',filter);filter();"""
(out/'auditoria-origens.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Mataró · Auditoria d’orígens V17</title>'+style+'<a href="index.html">← Mapa</a> · <a href="cronologia.html">Cronologia</a><h1>Què sabem dels orígens?</h1><p><b>73/75 codis amb alguna fita · 140 fites. 56/75 tenen una data al camp d’origen; 19 el tenen buit.</b> Les 56 dates inclouen fundacions declarades, antecedents, constitucions administratives i inicis de projectes: no són 56 primers dies de classe verificats. El 97,3% mesura qualsevol fita, no la cobertura de fundacions.</p><p>La primera fita conservada és només la més antiga de les documentades al conjunt actual. No s’utilitza automàticament com a fundació ni com a inici d’ocupació de la seu del mapa. Els 75 són codis de la base registral; no tots actius confirmats.</p><p><a href="auditoria_origens_v17.csv">Dades de l’auditoria</a> · <a href="pistes_origen_per_revisar_v17.csv">Pistes d’origen</a> · <a href="registre_recerca_v17.csv">Registre de recerca</a> · <a href="pla_recerca_pendent_v12.md">Consultes documentals preparades</a></p><label for="q">Centre o codi </label><input id="q" type="search"><label for="cat"> Categoria </label><select id="cat">'+opts+'</select><p id="n"></p><div class="scroll"><table><thead><tr><th>Centre</th><th>Fites</th><th>Camp d’origen</th><th>Primera fita documentada</th><th>Tasca pendent</th></tr></thead><tbody>'+rows+'</tbody></table></div><script>'+script+'</script></html>')




(out/'cobertura.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><title>Cobertura V17</title>'+style+'<h1>73/75 codis amb alguna fita · 140 fites</h1><p>56 camps amb una data relacionada amb l’origen; 19 buits. Sis fites noves daten reorganitzacions escolars i obres. Els camps d’origen no canvien. No són 56 fundacions verificades. Els 75 codis no són tots actius confirmats.</p><p><a href="index.html">Mapa</a> · <a href="cronologia.html">Cronologia</a> · <a href="auditoria-origens.html">Auditoria</a></p><table><tr><th>Centre</th><th>Fites</th><th>Recerca</th></tr>'+''.join('<tr><td>'+html.escape(r['nom'])+'</td><td>'+str(counts[r['codi_centre']])+'</td><td>'+html.escape(r['estat_recerca_historica'])+'</td></tr>' for r in sorted(a,key=lambda r:r['nom']))+'</table>')
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=17,fites_historiques=140,fites_noves_v17=6,camps_origen_nous_v17=0,codis_amb_camp_origen_informat=56,codis_sense_camp_origen=19,categories_auditoria_origen=dict(stats),nota='73 de 75 codis amb qualsevol fita; no equival a cobertura de fundacions. 56 camps daten orígens de naturalesa diversa, inclosos predecessors.',nota_v17='Sis fites de Josep Montserrat, Peramàs i Damià Campeny. Cap camp d’origen nou resolt; no confondre unitats, obres i seus amb fundació.');(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V17.md').write_text("""# Mataró, ciutat d’escoles — V17, 18-11-2026
Paquet acumulatiu. Obre index.html. Sense publicació en línia.
140 fites de 73/75 codis (97,3% amb qualsevol fita). Es mantenen 56 camps amb una data relacionada amb l’origen i 19 buits. Cap origen nou resolt en aquesta fase.
Sis fites noves: creació d’unitats a Josep Montserrat (31-08-1964); reorganització i transformació d’unitats a Peramàs (08-01-1979 i 17-08-1979); projectes arquitectònics (1993–1998), obres (1998–1999) i ampliació d’espais docents (2016–2017) del Damià Campeny. Els intervals arquitectònics són períodes, no cursos.
Les fonts daten fets diferents de la fundació. No s’omple el camp d’origen amb la primera fita documentada. Vegeu pistes_documentals_v17.md per als límits i els contrastos pendents, incloses les dates de Josep Montserrat.
Fitxers vigents: base canònica CSV/GeoJSON, esdeveniments_historics_v17.csv, fonts_historiques_v17.csv, auditoria_origens_v17.csv, pistes_origen_per_revisar_v17.csv, registre_recerca_v17.csv i resum_auditoria.json. La revisió d’orígens V16 i les discrepàncies V15 es conserven com a antecedents. Versions anteriors: no sumar files.
Mapa, cronologia, auditoria i cobertura sincronitzats. Cap geometria nova. Dos codis continuen sense fita: Col·legi Salesià 08065123 i Picasoques 08078695. Els 75 codis no equivalen a 75 centres actius confirmats. Consultes documentals no enviades.
Validació automatitzada de codis, fonts, dates, coherència CSV/GeoJSON/visor, 140 articles, 75 files d’auditoria i cobertura, JavaScript, enllaços locals, SHA256 i ZIP. Sense inspecció visual en navegador.
""")
shutil.copy2(__file__,out/'amplia_mataro_v17.py')
assert len(a)==75 and len(audit)==75 and norigin==56 and len(E)==140
assert len({e['id_esdeveniment'] for e in E})==140
assert all(e['id_font'] in fm and e['data_min']<=e['data_max'] for e in E)
assert chron.count('<article data-year=')==140
assert '140 fites' in chron and '140 fites' in idx
assert (out/'cobertura.html').read_text().count('<tr>')==76
payload=re.search(r'const centres=(.*?);const esc=',idx,re.S).group(1)
assert json.loads(payload)==a
assert all(f['properties']==am[f['properties']['codi_centre']] for f in g['features'])
assert len([f for f in g['features'] if f['geometry']])==73
for name in ['index.html','cronologia.html','cobertura.html','auditoria-origens.html']:
 text=(out/name).read_text()
 for link in re.findall(r'href="([^"#]+)"',text):
  if not link.startswith(('http:','https:',chr(39))):assert (out/link).exists(),link
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',text,re.S)):
  path=Path('/tmp')/('v16_'+name+str(i)+'.js');path.write_text(s);subprocess.run(['node','--check',str(path)],check=True,capture_output=True)
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(manifest,indent=2))
zp=B/'Mataro_ciutat_escoles_V17_unitats_i_seus_2026-11-18.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v17/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(json.dumps(dict(zip=str(zp),fites=len(E),camps_origen=norigin,pendents=75-norigin)))
