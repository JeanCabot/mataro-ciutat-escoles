# Mataró, ciutat d’escoles — V9
Guia vigent del paquet acumulatiu del 18-11-2026.

## Resultat
Revisió inicial dels 37 casos pendents de V8: 28 centres amb noves fites, 9 amb evidència o discrepàncies sense fita incorporada. Total: 66/75 (88%), 104 fites (40 noves). No són històries completes ni un cens de 75 centres actius verificats. El denominador continua sent el conjunt de 75 codis del CSV aportat per permetre comparar versions.

## Obre
index.html: mapa i llista. cronologia.html: fites datades amb fonts. cobertura.html: progrés i pendents. Mapes amb Internet; sense publicació en línia en aquesta fase.

## Dades vigents
esdeveniments_historics_v9.csv, fonts_historiques_v9.csv, cobertura_recerca_v9.csv, revisio_37_centres_v9.csv, evidencies_sense_fita_v9.csv, discrepancies_i_pistes_v9.csv, mataro_centres_2026_2027.csv/.geojson, mataro_seus_observades.csv i mataro_seus_v2.geojson. Fitxers de versions anteriors: checkpoints, no sumar-ne registres. El nom del GeoJSON de seus es conserva per compatibilitat.

## Correccions de vigència
Nemomarlin: cessament autoritzat segons DOGC EDF/3357/2026, amb efectes des del final del curs 2025–2026. Fila conservada amb avís; no centre actiu confirmat. Liceu: seu Centre Catòlic tancada segons la mateixa entitat el 2024; relleu de l’oferta a Valldemia, sense traslladar-hi el codi 08057126. Els punts d’aquestes dues seus figuren en gris per transparència documental.
Les Figueretes: servei provisional a Jaume Isern 18, documentat per a 2026–2027; l’antiga seu tancada el 2025 es conserva a inventari però es retira del mapa principal. No s’inventa coordenada del nou portal. Ara hi ha 73 punts de centre i 78 observacions de seu, algunes històriques: no equivalen a 78 seus actives. Les noves fites no creen geometries històriques per inferència.

## Nou casos sense fita
Col·legi Salesià, La Caseta, Peques, Picasoques, Petit Somni, Heidi Consegal, GiEscola, La Fada i Sant Josep. Tots tenen una entrada d’evidència i una tasca concreta. Les observacions de presència o oferta datada es mantenen separades de les fites per no inflar el percentatge.
Sant Josep: web 1968 vs PDF institucional 1970. No s’ha triat una fundació única. No s’atribueix a Col·legi Salesià 08065123 la fundació de 1905 de Sant Antoni de Pàdua 08021089.

## Altres cauteles
Liceu: es prioritza 1962 de la institució sobre 1959 d’un treball acadèmic. El Carreró: 1999 del centre sobre 2000 d’aquell treball. Snoopy: 1980 segons anunci del centre, amb precisió d’any i pendent de verificació registral; no es deriva l’origen de l’experiència comercial anunciada. El Xumet: 2006 segons entrevista a la directora, pendent d’autorització original. Vista Alegre: dècada de 1970, no any inicial concret. Convenis de sosteniment de bressols: dates legals, no primer dia de classe. Dates d’efectes, resolució, publicació i ocupació no s’intercanvien. El filtre temporal és de fites, no de totes les escoles actives en cada any.

## Validació
Recomptes i integritat de codis, fonts, intervals, enllaços locals, propietats GeoJSON, dades del visor, sintaxi JavaScript, SHA256 i ZIP. Sense inspecció visual amb navegador ni contrast arxivístic complet. Els programes de versions anteriors es conserven com a traçabilitat i alguns requereixen els seus directoris d’entrada originals.
