from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile,collections,subprocess
B=Path(__file__).parent;out=B/'mataro_escoles_v15';shutil.copytree(B/'mataro_escoles_v14',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,rows):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['codi_centre','centre','id_esdeveniment','tipus','data','id_font','afirmacio','decisio']);w.writeheader();w.writerows(rows)
a=read('mataro_centres_2026_2027.csv');am={r['codi_centre']:r for r in a};E=read('esdeveniments_historics_v14.csv');F=read('fonts_historiques_v14.csv');fm={r['id_font']:r for r in F}
def src(i,t,u,typ):
 r=dict(id_font=i,titol=t,url=u,consulta='2026-11-18',tipus=typ,abast='Fets i límits indicats en les fites i la revisió');F.append(r);fm[i]=r
src('H98','MASMM — fitxa fotogràfica 15615, festa de Cerdanyola','https://masmm.org/arxiu/fotografic_detail.php?afotografic_id=15615','metadades de catàleg d’arxiu; atribució retrospectiva')
src('H99','Gegants de Mataró — arxiu de sortides del Sethomes','https://www.gegantsmataro.net/totalsgegant.php?TipoGaleria=&codi=237','registre comunitari de sortides i actes')
src('H100','Ajuntament — Fent camí, EBM La Llàntia','https://www.mataro.cat/ca/temes/educacio/escoles-bressol-0-3-anys/fent-cami_ebm-la-llantia-web.pdf','relat de l’equip educatiu publicat per l’Ajuntament')
src('H101','Gegants de Mataró — La Iaia original','https://www.gegantsmataro.net/fitxagegant.php?TipoGaleria=A&codi=432','documentació comunitària del patrimoni festiu escolar')
src('H102','Ajuntament — Més Mataró 20, juliol/agost 2007, notícia bibliogràfica','https://www.mataro.cat/ca/actualitat/publicacions/mes-mataro-butlleti-municipal/2007/mm20jul07.pdf','notícia institucional sobre un llibre; llibre íntegre no consultat')
def ev(c,k,d,f,claim,loc,notes,end=None):
 E.append(dict(id_esdeveniment='HIST-'+str(max(int(x['id_esdeveniment'].split('-')[1]) for x in E)+1).zfill(3),id_entitat='ENT-'+c,codi_actual_referencia=c,centre=am[c]['nom'],tipus=k,data_min=d,data_max=end or d,precisio='curs' if end else 'any' if len(d)==4 else 'dia',afirmacio=claim,id_font=f,font_url=fm[f]['url'],localitzador=loc,estat='documentat; contrast parcial',notes=notes))



ev('08046402','origen_atribuit_cataleg','1979','H98','La descripció de la fotografia 15615 del MASMM atribueix la creació de l’escola bressol Cerdanyola a 1979.','Fitxa 15615; fotografia datada 1993; referència 015615-015336.015628_151','És una afirmació del catàleg, no una acta de creació. H99 registra un vuitè aniversari el 1989; la discrepància es conserva i no s’omple el camp d’origen amb una data única.')
ev('08046402','commemoracio','1989-06-17','H99','L’arxiu de sortides del Sethomes registra una celebració anomenada vuitè aniversari de l’Escola Bressol Cerdanyola.','Sortida de 17-06-1989','No s’infereix una fundació el 1981 restant vuit anys; cal conciliar el sentit de la commemoració amb l’atribució de 1979 de H98.')
ev('08046414','trasllat_seu','1995','H100','Trasllat de La Llàntia des del carrer de la Boixa al carrer Galícia durant el curs 1995–1996.','Text introductori, pàgina numerada 2','No és la fundació del centre; l’edifici de Galícia havia estat parvulari de l’escola pública de Cerdanyola.',end='1996')
ev('08046414','inauguracio_seu','1996-01-27','H99','L’arxiu del Sethomes registra la inauguració dels nous locals de l’EB La Llàntia i l’estrena del Jordi de la Llàntia.','Sortida de 27-01-1996','Acte festiu documentat per la comunitat gegantera; no es confon amb el primer dia de classes ni amb la fundació de l’escola.')
ev('08046414','transformacio_pedagogica','2015','H100','L’equip de La Llàntia situa al curs 2015–2016 l’inici d’un procés de reflexió i transformació del projecte educatiu.','Apartat «Un equip amb voluntat per formar-se», pàgina numerada 2','Història del canvi pedagògic, no de la creació del centre.',end='2016')
ev('08057515','patrimoni_escolar','1996','H101','Creació de la geganta original La Iaia de l’escola bressol La Riereta el curs 1996–1997 per iniciativa de l’AMPA.','Paràgraf sobre la creació de la figura','La font diu que l’escola s’havia inaugurat feia poc; no se’n deriva una data exacta d’obertura. La data de la figura no és la fundació de l’escola.',end='1997')
E.sort(key=lambda e:(e['data_min'],e['id_esdeveniment']));counts=collections.Counter(e['codi_actual_referencia'] for e in E);assert len(E)==131 and len(counts)==73
write('esdeveniments_historics_v15.csv',E);write('fonts_historiques_v15.csv',F)
origin_ids={'08070209':'HIST-105','08074291':'HIST-107','08073946':'HIST-110'}
changes=[]
for r in a:
 c=r['codi_centre'];r['nombre_fites_documentades']=counts[c]
 if c in origin_ids:
  e=next(x for x in E if x['id_esdeveniment']==origin_ids[c]);assert e['codi_actual_referencia']==c
  changes.append(dict(codi_centre=c,centre=r['nom'],tipus_anterior=r['tipus_data_origen'],data_anterior=r['origen_data_min'],nou_tipus='autorització d’obertura; primeres classes pendents',nova_data_min=e['data_min'],nova_data_max=e['data_max'],id_esdeveniment=e['id_esdeveniment'],id_font=e['id_font'],limit='Data administrativa ja documentada a V10–V11. No és el primer dia real de classes; efectes legals en fita separada.'))
  r.update(tipus_data_origen='autorització d’obertura; primeres classes pendents',origen_data_min=e['data_min'],origen_data_max=e['data_max'],fundacio_any='',fundacio_font=e['font_url'],estat_recerca_historica='autorització inicial documentada; inici real de classes pendent')
write('revisio_tres_autoritzacions_v15.csv',changes);write('mataro_centres_2026_2027.csv',a)
g=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in g['features']:f['properties']=am[f['properties']['codi_centre']]
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(g,ensure_ascii=False,indent=2))
D=read('discrepancies_i_pistes_v14.csv') if (out/'discrepancies_i_pistes_v14.csv').exists() else read('discrepancies_i_pistes_v11.csv')
D.append(dict(id='D15',centre='EB Cerdanyola',tema='origen i commemoració',dada_a='Catàleg MASMM: creada el 1979',dada_b='Arxiu Sethomes: vuitè aniversari el 17-06-1989',font='H98 | H99',decisio='Conservar afirmacions separades; no calcular 1981 ni seleccionar una fundació única.'));write('discrepancies_i_pistes_v15.csv',D)
# Audit is rebuilt from the updated canonical data and events.
by=collections.defaultdict(list)
for e in E:by[e['codi_actual_referencia']].append(e)
audit=[]
for r in a:
 c=r['codi_centre'];es=sorted(by[c],key=lambda e:(e['data_min'],e['id_esdeveniment']));first=es[0] if es else {};typ=r['tipus_data_origen'];d=r['origen_data_min']
 if not d:cat='camp d’origen buit; recerca pendent'
 elif 'antecedent' in typ or 'patronat' in typ or 'predecessor' in typ:cat='antecedent; no obertura del centre actual'
 elif 'autorització' in typ:cat='autorització d’obertura; no primeres classes'
 elif 'administrativa' in typ or 'creació' in typ or 'transformació' in typ or typ=='creacio_escola':cat='constitució o creació; classes pendents de distingir'
 elif 'projecte' in typ:cat='inici de projecte; no autorització del codi'
 else:cat='data d’origen declarada; contrast segons font'
 specific={
 '08065123':'Conciliar codis 08065123 i 08021089 i trobar autorització pròpia. No heretar 1905 ni 2004.',
 '08078695':'Autorització i primer curs pendents. Corregir coordenada del CSV només amb portal 27 documentat.',
 '08073946':'Autorització i efectes legals confirmats; primer curs real i relació amb Pinotxo pendents.',
 '08078877':'2012 és consolidació del projecte segons la directora; alta del codi i autorització de cicles pendents.',
 '08056948':'2015 és actuació escolar; no és fundació ni autorització.',
 '08021181':'Conciliar 1968/1970: classes inicials, comunitat religiosa i actes d’inauguració.',
 }
 audit.append(dict(codi_centre=c,centre=r['nom'],fites_documentades=len(es),categoria_origen=cat,tipus_data_origen=typ,origen_data_min=d,origen_data_max=r['origen_data_max'],font_origen=r['fundacio_font'],primera_fita_id=first.get('id_esdeveniment',''),primera_fita_data=first.get('data_min',''),primera_fita_tipus=first.get('tipus',''),primera_fita_font=first.get('font_url',''),control='Primera fita cronològica no equival a fundació.',tasca_prioritaria=specific.get(c,'Precisar què data la font d’origen i contrastar-la.' if d else 'Cercar origen del centre; no adoptar la primera fita com a fundació.')))
write('auditoria_origens_v15.csv',audit);stats=collections.Counter(x['categoria_origen'] for x in audit);norigin=sum(bool(x['origen_data_min']) for x in audit);assert norigin==54
# Candidates are extracted from documented events but do not silently overwrite canonical origins.
missing=[e for e in E if not next(r for r in a if r['codi_centre']==e['codi_actual_referencia'])['origen_data_min'] and e['tipus'] in {'origen_declarat','inauguracio_escola','antecedent_aulari','consolidacio_projecte_escolar','autoritzacio_obertura'}]
write('pistes_origen_per_revisar_v15.csv',[dict(codi_centre=e['codi_actual_referencia'],centre=e['centre'],id_esdeveniment=e['id_esdeveniment'],tipus=e['tipus'],data=e['data_min'],id_font=e['id_font'],afirmacio=e['afirmacio'],decisio='Candidat de revisió; no afegit al camp canònic d’origen automàticament.') for e in missing])
queries=[('CIDO','soques; Pica-Soques; Salesia; Salesians; Salesià','Sense nou acte atribuïble inequívocament als dos codis.','No prova que l’acte no existeixi; cercador de títols i indexació incompleta.'),('Web pública','08065123 autorització; Col·legi Salesià formació d’adults resolució','Retorna resolució de 2004 amb altre codi i llistats d’oferta ja coneguts.','No es converteix l’oferta en autorització inicial.'),('Web pública','Picasoques Mataró obertura; Pica-soques Mataró inauguració','Web del centre, directori i resultats homònims, sense data d’origen contrastada.','No s’atribueixen societats, revistes o escoles d’altres municipis.'),('Web oficial Picasoques','Contacte, ronda República 27','El mapa incrustat és una cerca textual de l’adreça.','No aporta una coordenada de portal verificada; no es corregeix geometria per inferència.')]
write('registre_recerca_v15.csv',[dict(data_consulta='2026-11-18',via=v,consulta=q,resultat=r,limit=l) for v,q,r,l in queries])
chron=(out/'cronologia.html').read_text();opts='<option value="">Tots els centres documentats</option>'+''.join('<option value="'+c+'">'+html.escape(n)+'</option>' for c,n in sorted({(e['codi_actual_referencia'],e['centre']) for e in E},key=lambda x:x[1]));chron=re.sub(r'(<select id="centre">).*?(</select>)',lambda m:m[1]+opts+m[2],chron,count=1,flags=re.S)
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['data_min']+'–'+e['data_max'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(fm[e['id_font']]['titol'])+' · '+html.escape(e['localitzador'])+'</a></p></article>' for e in E)
chron=re.sub(r'<article.*?</article>(?:<article.*?</article>)*',lambda m:items,chron,count=1,flags=re.S).replace('125 fites documentades de 73 dels 75 registres de base (97,3%)','131 fites documentades de 73 dels 75 registres de base (97,3%)').replace('V14','V15');(out/'cronologia.html').write_text(chron)
idx=(out/'index.html').read_text().replace('versió 14','versió 15').replace('125 fites','131 fites').replace('71 centres amb alguna fita documentada','73 centres amb alguna fita documentada').replace('71/75 registres · 94,7%','73/75 registres · 97,3%');idx=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',idx,count=1,flags=re.S);(out/'index.html').write_text(idx)
rows=''.join('<tr><td>'+html.escape(r['nom'])+'</td><td>'+str(counts[r['codi_centre']])+'</td><td>'+html.escape(r['estat_recerca_historica'])+'</td></tr>' for r in sorted(a,key=lambda r:r['nom']))
(out/'cobertura.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Cobertura V11</title><style>body{font:17px system-ui;max-width:980px;margin:40px auto;padding:20px;color:#243b35;background:#f7f5ed}table{border-collapse:collapse;width:100%}td,th{text-align:left;padding:10px;border-bottom:1px solid #ccc}a{color:#25634e}</style><h1>73 de 75 registres: 97,3%</h1><p>116 fites; històries parcials. Cobertura d’almenys una fita, de naturalesa diversa: no són 73 fundacions verificades. Gi: consolidació del projecte, sense data d’autorització del codi. Heidi: participació cultural, fundació pendent. La Fada: text íntegre i codi confirmats. Dos codis sense fita: Col·legi Salesià 08065123 i Picasoques. El denominador continua sent els 75 codis del CSV; no tots actius.</p><p><a href="index.html">Mapa</a> · <a href="cronologia.html">Cronologia</a> · <a href="revisio_pendents_v11.csv">Revisió</a> · <a href="evidencies_sense_fita_v11.csv">Dos casos sense fita</a></p><table><tr><th>Centre</th><th>Fites</th><th>Recerca</th></tr>'+rows+'</table></html>')
coverrows=''.join('<tr><td>'+html.escape(r['nom'])+'</td><td>'+str(counts[r['codi_centre']])+'</td><td>'+html.escape(r['estat_recerca_historica'])+'</td></tr>' for r in sorted(a,key=lambda r:r['nom']))
(out/'cobertura.html').write_text((out/'cobertura.html').read_text()+'<table><tr><th>Centre</th><th>Fites</th><th>Recerca</th></tr>'+coverrows+'</table>')
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=15,fites_historiques=131,centres_amb_fites=73,centres_pendents=2,cobertura_percent=97.33,centres_amb_fites_text_integre_o_narrativa=73,centres_amb_fites_nomes_metadades=0,centres_nous_v15=0,fites_noves_v15=5,camps_origen_nous_v15=5,nota='75 codis de base; vigència parcial. La Fada confirmada pel text íntegre. Cobertura de qualsevol fita; Gi consolidació de projecte i Heidi activitat cultural, sense fundació o autorització completa.');(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
style='<style>body{max-width:1200px;margin:32px auto;padding:20px;font:16px system-ui;color:#223b39;background:#f5f1e8}h1{font:32px Georgia}table{border-collapse:collapse;width:100%;background:white}td,th{text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid #ccd5ce}small{display:block;line-height:1.5}a{color:#16665c}input,select{padding:10px;margin:8px 8px 16px 0;max-width:100%;font:inherit}.scroll{overflow:auto}</style>'
rows=''.join('<tr data-search="'+html.escape(x['centre'].lower()+' '+x['codi_centre'],quote=True)+'" data-cat="'+html.escape(x['categoria_origen'],quote=True)+'"><td><b>'+html.escape(x['centre'])+'</b><small>'+x['codi_centre']+'</small></td><td>'+str(x['fites_documentades'])+'</td><td>'+html.escape(x['categoria_origen'])+'<small>'+html.escape(x['origen_data_min']+' '+x['tipus_data_origen'])+'</small></td><td>'+html.escape(x['primera_fita_data']+' '+x['primera_fita_tipus'])+'</td><td>'+html.escape(x['tasca_prioritaria'])+'</td></tr>' for x in sorted(audit,key=lambda x:x['centre']))
opts='<option value="">Totes les categories</option>'+''.join('<option>'+html.escape(c)+'</option>' for c in sorted(stats))
script="""const q=document.querySelector('#q'),cat=document.querySelector('#cat'),rows=[...document.querySelectorAll('tbody tr')];function filter(){let n=0;for(const r of rows){const show=r.dataset.search.includes(q.value.toLowerCase().trim())&&(!cat.value||r.dataset.cat===cat.value);r.hidden=!show;if(show)n++;}document.querySelector('#n').textContent=n+' registres';}q.addEventListener('input',filter);cat.addEventListener('change',filter);filter();"""
(out/'auditoria-origens.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Mataró · Auditoria d’orígens V15</title>'+style+'<a href="index.html">← Mapa</a> · <a href="cronologia.html">Cronologia</a><h1>Què sabem dels orígens?</h1><p><b>73/75 codis amb alguna fita · 131 fites. 54/75 tenen una data al camp d’origen; 21 el tenen buit.</b> Les 54 dates inclouen fundacions declarades, antecedents, constitucions administratives i inicis de projectes: no són 54 primers dies de classe verificats. El 97,3% mesura qualsevol fita, no la cobertura de fundacions.</p><p>La primera fita conservada és només la més antiga de les documentades al conjunt actual. No s’utilitza automàticament com a fundació ni com a inici d’ocupació de la seu del mapa. Els 75 són codis de la base registral; no tots actius confirmats.</p><p><a href="auditoria_origens_v15.csv">Dades de l’auditoria</a> · <a href="pistes_origen_per_revisar_v15.csv">Pistes d’origen</a> · <a href="registre_recerca_v15.csv">Registre de recerca</a> · <a href="pla_recerca_pendent_v12.md">Consultes documentals preparades</a></p><label for="q">Centre o codi </label><input id="q" type="search"><label for="cat"> Categoria </label><select id="cat">'+opts+'</select><p id="n"></p><div class="scroll"><table><thead><tr><th>Centre</th><th>Fites</th><th>Camp d’origen</th><th>Primera fita documentada</th><th>Tasca pendent</th></tr></thead><tbody>'+rows+'</tbody></table></div><script>'+script+'</script></html>')



(out/'pistes_bibliografiques_v15.md').write_text("""# Pista bibliogràfica pendent de consulta íntegra
**Una escola avançada. L’escola bressol municipal de Mataró 1979–2007.** Edició de l’Institut Municipal d’Educació, documentada a Més Mataró 20, juliol/agost de 2007 (H102).
S’ha consultat la notícia municipal, no el llibre íntegre. La notícia explica que tracta els orígens de la xarxa i el Patronat de 1979. No s’atribueix a cadascuna de les escoles l’any de creació del Patronat.
Cal localitzar un exemplar o facsímil amb paginació per contrastar Cerdanyola, Rocafonda, Tabalet, La Llàntia i La Riereta. Autor, ISBN i localització d’exemplar pendents: no s’inventen.
Per als centres de persones adultes, Can Marfà i Can Noè continuen sense origen inicial resolt. La titularitat municipal de Can Noè des de 2001–2002 no es converteix en fundació.
""")
(out/'cobertura.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Cobertura V15</title>'+style+'<h1>73/75 codis amb alguna fita · 131 fites</h1><p>54 camps de data relacionada amb l’origen informats; 21 buits. Tres camps nous corresponen a autoritzacions ja documentades: no són tres fundacions noves. Les primeres classes poden tenir una altra data. Els 75 codis no equivalen a 75 centres actius confirmats.</p><p><a href="index.html">Mapa</a> · <a href="cronologia.html">Cronologia</a> · <a href="auditoria-origens.html">Auditoria</a> · <a href="pistes_bibliografiques_v15.md">Pista bibliogràfica</a></p>')
coverrows=''.join('<tr><td>'+html.escape(r['nom'])+'</td><td>'+str(counts[r['codi_centre']])+'</td><td>'+html.escape(r['estat_recerca_historica'])+'</td></tr>' for r in sorted(a,key=lambda r:r['nom']))
(out/'cobertura.html').write_text((out/'cobertura.html').read_text()+'<table><tr><th>Centre</th><th>Fites</th><th>Recerca</th></tr>'+coverrows+'</table>')
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=15,fites_historiques=131,fites_noves_v15=6,camps_origen_nous_v15=3,codis_amb_camp_origen_informat=54,codis_sense_camp_origen=21,categories_auditoria_origen=dict(stats),nota_v15='Sis fites de Cerdanyola, La Llàntia i La Riereta; origen únic de Cerdanyola pendent. Tres camps administratius completats amb autoritzacions ja documentades.');(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V15.md').write_text("""# Mataró, ciutat d’escoles — V15, 18-11-2026
Paquet acumulatiu. Obre index.html, cronologia.html i auditoria-origens.html. Sense publicació en línia.

131 fites de 73/75 codis (97,3% amb qualsevol fita). 54 camps de data relacionada amb l’origen informats i 21 buits. Tres camps afegits reutilitzen autoritzacions de La Caseta, Petit Somni i La Fada, ja documentades a V10–V11; no són fundacions acabades de descobrir. Es tipifiquen com a autoritzacions, amb efectes legals i primeres classes separats. Els camps informats inclouen també antecedents, creacions, inauguracions i projectes.

Sis fites noves: atribució d’origen de Cerdanyola el 1979 al catàleg fotogràfic del MASMM; commemoració denominada vuitè aniversari el 17-06-1989 a l’arxiu de sortides del Sethomes; trasllat de La Llàntia de Boixa a Galícia el curs 1995–1996; acte d’inauguració dels nous locals de 27-01-1996; inici d’un canvi pedagògic a La Llàntia el curs 2015–2016; i creació de La Iaia de La Riereta el curs 1996–1997. Les fites festives s’identifiquen com a documentació comunitària retrospectiva. No daten automàticament la fundació.

Cerdanyola: discrepància conservada D15. No es calcula 1981 a partir d’un vuitè aniversari ni es fixa una data única de fundació. El catàleg és una descripció retrospectiva de fotografia de 1993, no una acta fundacional. El camp d’origen segueix buit.
La Llàntia: el trasllat i la inauguració són fets diferents. L’origen del centre encara pendent. La Riereta: la figura festiva és patrimoni escolar, no la fundació; expressions com «feia poc temps» no generen data exacta.

Pista prioritària: Una escola avançada. L’escola bressol municipal de Mataró 1979–2007, editat per l’IME. La notícia municipal de 2007 està localitzada, però el llibre íntegre no s’ha consultat; no s’atribueixen continguts ni pàgines no llegits. No es trasllada la data del Patronat a cadascuna de les escoles. Can Marfà i Can Noè continuen sense origen inicial resolt.

Fitxers vigents: esdeveniments_historics_v15.csv, fonts_historiques_v15.csv, auditoria_origens_v15.csv, pistes_origen_per_revisar_v15.csv, discrepancies_i_pistes_v15.csv, revisio_tres_autoritzacions_v15.csv, pistes_bibliografiques_v15.md i base canònica CSV/GeoJSON. Les versions anteriors són checkpoints; no sumar files. El mapa, la cronologia i l’auditoria estan sincronitzats. No s’han afegit geometries per inferència.

Dos codis continuen sense fita atribuïble: Col·legi Salesià 08065123 i Picasoques 08078695. Les consultes documentals de V12 es conserven sense enviar. 75 codis no són 75 centres actius confirmats. Es mantenen els 73 punts de centre i els avisos de vigència.

Validació: codis, fonts, intervals, 131 articles de cronologia, 75 files d’auditoria, dades del visor, GeoJSON, sintaxi JavaScript, enllaços locals, SHA256 i integritat ZIP. Sense inspecció visual amb navegador ni contrast arxivístic exhaustiu.
""")
shutil.copy2(__file__,out/'amplia_mataro_v15.py')
assert len(audit)==75 and sum(x['fites_documentades'] for x in audit)==131 and norigin==54 and len(counts)==73
assert len({e['id_esdeveniment'] for e in E})==131 and chron.count('<article data-year=')==131
assert all(e['id_font'] in fm and e['data_min']<=e['data_max'] for e in E)
assert not am['08046402']['origen_data_min']
for name in ['index.html','cronologia.html','cobertura.html','auditoria-origens.html']:
 text=(out/name).read_text()
 for link in re.findall(r'href="([^"#]+)"',text):
  if not link.startswith(('http:','https:',chr(39))):assert (out/link).exists(),link
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',text,re.S)):
  p=Path('/tmp')/('v15_'+name+str(i)+'.js');p.write_text(s);subprocess.run(['node','--check',str(p)],check=True,capture_output=True)
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(manifest,indent=2))
zp=B/'Mataro_ciutat_escoles_V15_bressols_i_fonts_2026-11-18.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v15/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(json.dumps(dict(zip=str(zp),fites=len(E),camps_origen=norigin,pendents=75-norigin)))
