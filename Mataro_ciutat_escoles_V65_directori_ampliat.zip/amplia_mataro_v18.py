from pathlib import Path
import csv,json,shutil,re,html,hashlib,zipfile,collections,subprocess
B=Path(__file__).parent;out=B/'mataro_escoles_v18';shutil.copytree(B/'mataro_escoles_v17',out,dirs_exist_ok=True)
def read(n):
 with (out/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(n,rows):
 with (out/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['codi_centre','centre','id_esdeveniment','tipus','data','id_font','afirmacio','decisio']);w.writeheader();w.writerows(rows)
a=read('mataro_centres_2026_2027.csv');am={r['codi_centre']:r for r in a};E=read('esdeveniments_historics_v17.csv');F=read('fonts_historiques_v17.csv');fm={r['id_font']:r for r in F}
def src(i,t,u,typ):
 r=dict(id_font=i,titol=t,url=u,consulta='2026-11-19',tipus=typ,abast='Fets i límits indicats en les fites i la revisió');F.append(r);fm[i]=r
src('H111','Educació — Decret 213/2007, de 25 de setembre, reproduït al Full de disposicions 1156','https://repositori.educacio.gencat.cat/bitstream/handle/20.500.12694/1085/1156_XXV_octubre.pdf?isAllowed=y&sequence=5','text normatiu reproduït en publicació oficial del Departament; consultat')
src('H112','Open Puig i Cadafalch 2019 — Can Noè','https://openpuigicadafalch.cat/9a-edicio-2019/','fitxa de patrimoni arquitectònic; apartat 07')
src('H113','Ajuntament — Acta del Consell Plenari de l’IME, 20-01-2004','https://carecitylab.cat/ca/actualitat/reunions-municipals/2004/acta-del-consell-plenari-de-linstitut-municipal','acta institucional; apartat 3.2, text consultat')
def ev(c,k,d,f,claim,loc,notes,end=None):
 E.append(dict(id_esdeveniment='HIST-'+str(max(int(x['id_esdeveniment'].split('-')[1]) for x in E)+1).zfill(3),id_entitat='ENT-'+c,codi_actual_referencia=c,centre=am[c]['nom'],tipus=k,data_min=d,data_max=end or d,precisio='curs' if end else 'any' if len(d)==4 else 'dia',afirmacio=claim,id_font=f,font_url=fm[f]['url'],localitzador=loc,estat='documentat; contrast parcial',notes=notes))






ev('08060253','creacio_administrativa_centre','2007-09-25','H111','El Decret 213/2007 crea el CFA Can Marfà, codi 08060253, per transformació de l’AFA Rocafonda.','Full 1156, p. 4679, article 1 i annex','Creació administrativa del centre; l’aula ja existia. No és el primer dia de classes ni la fundació de tota la trajectòria educativa. El nom de l’aula no permet fusionar el CFA amb Can Noè.')
ev('08060253','adequacio_activitat_docent','2007','H111','El decret preveu que l’activitat docent del centre creat s’adeqüi a la nova regulació a partir del curs 2007–2008.','Full 1156, p. 4679, article 2.1','Curs d’adequació previst per la norma, no data observada d’obertura.',end='2008')
ev('08061658','construccio_equipament_historic','1985','H112','La fitxa patrimonial data entre 1985 i 1987 la construcció de l’equipament educatiu de Can Noè, amb formació d’adults al primer pis.','Apartat 07 / Can Noè, segon paràgraf','Història de l’equipament; no creació administrativa del codi 08061658 ni prova de continuïtat institucional sense interrupcions. La mateixa obra es vincula també a l’escola bressol. No data la seu actual.',end='1987')
E[-1]['precisio']='període'
ev('08046426','construccio_equipament_historic','1985','H112','La fitxa patrimonial data entre 1985 i 1987 la construcció de l’equipament educatiu de Can Noè, amb la bressol de Rocafonda a la planta baixa.','Apartat 07 / Can Noè, segon paràgraf','Mateixa obra vinculada també a formació d’adults; dues relacions entre centres i obra, no dues obres diferents. No és la fundació de la bressol ni una data exacta d’inauguració.',end='1987')
E[-1]['precisio']='període'
ev('08046451','ampliacio_acollida_nova_seu','2004-01-09','H113','La nova seu del Tabalet acull les noves inscripcions el 9 de gener de 2004, l’endemà del trasllat del grup de l’antic centre.','Acta 20-01-2004, apartat 3.2','Entrada de nou alumnat a la nova seu, distinta del trasllat del dia 8 ja documentat. No és origen inicial del centre.')
ev('08046451','inici_servei_cuina_central','2004-01-19','H113','La cuina central del nou Tabalet comença el 19 de gener de 2004 i prepara els àpats del centre, de Cerdanyola i de les Figueretes.','Acta 20-01-2004, apartat 3.2','Inici d’un servei compartit, no fundació escolar. Una fita del servei, sense multiplicar-la per cada centre receptor.')
E.sort(key=lambda e:(e['data_min'],e['id_esdeveniment']));counts=collections.Counter(e['codi_actual_referencia'] for e in E)
assert len(E)==146 and len(counts)==73
write('esdeveniments_historics_v18.csv',E);write('fonts_historiques_v18.csv',F)
r=am['08060253'];e=next(e for e in E if e['id_esdeveniment']=='HIST-141')
changes=[dict(codi_centre=r['codi_centre'],centre=r['nom'],tipus_anterior=r['tipus_data_origen'],data_anterior=r['origen_data_min'],nou_tipus='creació administrativa per transformació d’una aula existent',nova_data_min=e['data_min'],nova_data_max=e['data_max'],id_esdeveniment=e['id_esdeveniment'],id_font=e['id_font'],limit=e['notes'])]
r.update(tipus_data_origen='creació administrativa per transformació d’una aula existent',origen_data_min=e['data_min'],origen_data_max=e['data_max'],fundacio_any='',fundacio_font=e['font_url'],estat_recerca_historica='creació administrativa del CFA documentada; inici de l’aula predecessora pendent')
for r in a:r['nombre_fites_documentades']=counts[r['codi_centre']]
write('revisio_origens_v18.csv',changes);write('mataro_centres_2026_2027.csv',a)
g=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in g['features']:f['properties']=am[f['properties']['codi_centre']]
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(g,ensure_ascii=False,indent=2))
write('registre_recerca_v18.csv',[dict(data_consulta='2026-11-19',via='Font pública',consulta=f['titol'],resultat='Text consultat; veure fites HIST-141–146.',limit='Dates administratives, obres i serveis distingits de primeres classes.') for f in F if f['id_font'] in {'H111','H112','H113'}])
(out/'pistes_documentals_v18.md').write_text("""# Recerca d’orígens V18
Can Marfà: Decret 213/2007 de 25-09, annex amb codi 08060253, carrer Jordi Joan 5 i transformació de l’AFA Rocafonda. Text consultat al Full de disposicions 1156, p. 4679. Es completa la creació administrativa; l’inici de l’aula anterior continua pendent. No s’identifica automàticament l’AFA Rocafonda amb Can Noè només pel topònim. El decret no documenta el primer dia real de classes de l’aula o del CFA.
Can Noè i bressol Rocafonda: Open Puig i Cadafalch 2019 data l’obra educativa entre 1985 i 1987 i en descriu els usos. És una obra amb dues vinculacions escolars, no dues construccions. No es trasllada la data de l’edifici als orígens institucionals ni a la seu actual del CFA.
Tabalet: l’acta de 20-01-2004 confirma tres moments de la nova seu: trasllat de l’antic alumnat el 8 (ja documentat), entrada de noves inscripcions el 9 i cuina central el 19. No es confonen amb la creació del centre. La notícia de 16-01 anuncia una inauguració per al dia 18; és una previsió de la notícia, no un relat posterior de celebració. No s’afegeix com a inauguració observada en aquesta fase.
La Riereta: les fonts comunitàries sobre la geganta no resolen la data inicial exacta; es manté pendent. El llibre d’escoles bressol de 2007 encara requereix consulta íntegra.
""")
# Audit is rebuilt from the updated canonical data and events.
by=collections.defaultdict(list)
for e in E:by[e['codi_actual_referencia']].append(e)
audit=[]
for r in a:
 c=r['codi_centre'];es=sorted(by[c],key=lambda e:(e['data_min'],e['id_esdeveniment']));first=es[0] if es else {};typ=r['tipus_data_origen'];d=r['origen_data_min']
 if not d:cat='camp d’origen buit; recerca pendent'
 elif 'antecedent' in typ or 'patronat' in typ or 'predecessor' in typ:cat='antecedent; no obertura del centre actual'
 elif 'autorització' in typ:cat='autorització d’obertura; no primeres classes'
 elif 'administrativa' in typ or 'creació' in typ or 'transformació' in typ or typ=='creacio_escola':cat='constitució o creació; classes pendents de distingir'
 elif 'projecte' in typ:cat='inici de projecte; no autorització del codi'
 else:cat='data d’origen declarada; contrast segons font'
 specific={
 '08065123':'Conciliar codis 08065123 i 08021089 i trobar autorització pròpia. No heretar 1905 ni 2004.',
 '08078695':'Autorització i primer curs pendents. Corregir coordenada del CSV només amb portal 27 documentat.',
 '08073946':'Autorització i efectes legals confirmats; primer curs real i relació amb Pinotxo pendents.',
 '08078877':'2012 és consolidació del projecte segons la directora; alta del codi i autorització de cicles pendents.',
 '08056948':'2015 és actuació escolar; no és fundació ni autorització.',
 '08021181':'Conciliar 1968/1970: classes inicials, comunitat religiosa i actes d’inauguració.',
 }
 audit.append(dict(codi_centre=c,centre=r['nom'],fites_documentades=len(es),categoria_origen=cat,tipus_data_origen=typ,origen_data_min=d,origen_data_max=r['origen_data_max'],font_origen=r['fundacio_font'],primera_fita_id=first.get('id_esdeveniment',''),primera_fita_data=first.get('data_min',''),primera_fita_tipus=first.get('tipus',''),primera_fita_font=first.get('font_url',''),control='Primera fita cronològica no equival a fundació.',tasca_prioritaria=specific.get(c,'Precisar què data la font d’origen i contrastar-la.' if d else 'Cercar origen del centre; no adoptar la primera fita com a fundació.')))
write('auditoria_origens_v18.csv',audit);stats=collections.Counter(x['categoria_origen'] for x in audit);norigin=sum(bool(x['origen_data_min']) for x in audit);assert norigin==57
# Candidates are extracted from documented events but do not silently overwrite canonical origins.
missing=[e for e in E if not next(r for r in a if r['codi_centre']==e['codi_actual_referencia'])['origen_data_min'] and e['tipus'] in {'origen_declarat','inauguracio_escola','antecedent_aulari','consolidacio_projecte_escolar','autoritzacio_obertura'}]
write('pistes_origen_per_revisar_v18.csv',[dict(codi_centre=e['codi_actual_referencia'],centre=e['centre'],id_esdeveniment=e['id_esdeveniment'],tipus=e['tipus'],data=e['data_min'],id_font=e['id_font'],afirmacio=e['afirmacio'],decisio='Candidat de revisió; no afegit al camp canònic d’origen automàticament.') for e in missing])
chron=(out/'cronologia.html').read_text();opts='<option value="">Tots els centres documentats</option>'+''.join('<option value="'+c+'">'+html.escape(n)+'</option>' for c,n in sorted({(e['codi_actual_referencia'],e['centre']) for e in E},key=lambda x:x[1]));chron=re.sub(r'(<select id="centre">).*?(</select>)',lambda m:m[1]+opts+m[2],chron,count=1,flags=re.S)
items=''.join('<article data-year="'+e['data_min'][:4]+'" data-code="'+e['codi_actual_referencia']+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['data_min']+'–'+e['data_max'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(fm[e['id_font']]['titol'])+' · '+html.escape(e['localitzador'])+'</a></p></article>' for e in E)
chron=re.sub(r'<article.*?</article>(?:<article.*?</article>)*',lambda m:items,chron,count=1,flags=re.S).replace('140 fites documentades de 73 dels 75 registres de base (97,3%)','146 fites documentades de 73 dels 75 registres de base (97,3%)').replace('V17','V18');(out/'cronologia.html').write_text(chron)
idx=(out/'index.html').read_text().replace('versió 17','versió 18').replace('140 fites','146 fites').replace('71 centres amb alguna fita documentada','73 centres amb alguna fita documentada').replace('71/75 registres · 94,7%','73/75 registres · 97,3%');idx=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',idx,count=1,flags=re.S);(out/'index.html').write_text(idx)
style='<style>body{max-width:1200px;margin:32px auto;padding:20px;font:16px system-ui;color:#223b39;background:#f5f1e8}h1{font:32px Georgia}table{border-collapse:collapse;width:100%;background:white}td,th{text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid #ccd5ce}small{display:block;line-height:1.5}a{color:#16665c}input,select{padding:10px;margin:8px 8px 16px 0;max-width:100%;font:inherit}.scroll{overflow:auto}</style>'
rows=''.join('<tr data-search="'+html.escape(x['centre'].lower()+' '+x['codi_centre'],quote=True)+'" data-cat="'+html.escape(x['categoria_origen'],quote=True)+'"><td><b>'+html.escape(x['centre'])+'</b><small>'+x['codi_centre']+'</small></td><td>'+str(x['fites_documentades'])+'</td><td>'+html.escape(x['categoria_origen'])+'<small>'+html.escape(x['origen_data_min']+' '+x['tipus_data_origen'])+'</small></td><td>'+html.escape(x['primera_fita_data']+' '+x['primera_fita_tipus'])+'</td><td>'+html.escape(x['tasca_prioritaria'])+'</td></tr>' for x in sorted(audit,key=lambda x:x['centre']))
opts='<option value="">Totes les categories</option>'+''.join('<option>'+html.escape(c)+'</option>' for c in sorted(stats))
script="""const q=document.querySelector('#q'),cat=document.querySelector('#cat'),rows=[...document.querySelectorAll('tbody tr')];function filter(){let n=0;for(const r of rows){const show=r.dataset.search.includes(q.value.toLowerCase().trim())&&(!cat.value||r.dataset.cat===cat.value);r.hidden=!show;if(show)n++;}document.querySelector('#n').textContent=n+' registres';}q.addEventListener('input',filter);cat.addEventListener('change',filter);filter();"""
(out/'auditoria-origens.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Mataró · Auditoria d’orígens V18</title>'+style+'<a href="index.html">← Mapa</a> · <a href="cronologia.html">Cronologia</a><h1>Què sabem dels orígens?</h1><p><b>73/75 codis amb alguna fita · 146 fites. 57/75 tenen una data al camp d’origen; 18 el tenen buit.</b> Les 57 dates inclouen fundacions declarades, antecedents, constitucions administratives i inicis de projectes: no són 57 primers dies de classe verificats. El 97,3% mesura qualsevol fita, no la cobertura de fundacions.</p><p>La primera fita conservada és només la més antiga de les documentades al conjunt actual. No s’utilitza automàticament com a fundació ni com a inici d’ocupació de la seu del mapa. Els 75 són codis de la base registral; no tots actius confirmats.</p><p><a href="auditoria_origens_v18.csv">Dades de l’auditoria</a> · <a href="pistes_origen_per_revisar_v18.csv">Pistes d’origen</a> · <a href="registre_recerca_v18.csv">Registre de recerca</a> · <a href="pla_recerca_pendent_v12.md">Consultes documentals preparades</a></p><label for="q">Centre o codi </label><input id="q" type="search"><label for="cat"> Categoria </label><select id="cat">'+opts+'</select><p id="n"></p><div class="scroll"><table><thead><tr><th>Centre</th><th>Fites</th><th>Camp d’origen</th><th>Primera fita documentada</th><th>Tasca pendent</th></tr></thead><tbody>'+rows+'</tbody></table></div><script>'+script+'</script></html>')




(out/'cobertura.html').write_text('<!doctype html><html lang="ca"><meta charset="utf-8"><title>Cobertura V18</title>'+style+'<h1>73/75 codis amb alguna fita · 146 fites</h1><p>57 camps amb una data relacionada amb l’origen; 18 buits. Can Marfà: creació administrativa el 2007 per transformació d’una aula existent. No són 57 fundacions verificades. Els 75 codis no són tots actius confirmats.</p><p><a href="index.html">Mapa</a> · <a href="cronologia.html">Cronologia</a> · <a href="auditoria-origens.html">Auditoria</a></p><table><tr><th>Centre</th><th>Fites</th><th>Recerca</th></tr>'+''.join('<tr><td>'+html.escape(r['nom'])+'</td><td>'+str(counts[r['codi_centre']])+'</td><td>'+html.escape(r['estat_recerca_historica'])+'</td></tr>' for r in sorted(a,key=lambda r:r['nom']))+'</table>')
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=18,fites_historiques=146,fites_noves_v18=6,camps_origen_nous_v18=1,codis_amb_camp_origen_informat=57,codis_sense_camp_origen=18,categories_auditoria_origen=dict(stats),nota='73 de 75 codis amb qualsevol fita; no equival a cobertura de fundacions. 57 camps daten orígens de naturalesa diversa, inclosos predecessors.',nota_v18='Can Marfà: creació administrativa el 25-09-2007, aula anterior pendent. Sis fites noves de normativa, equipament històric i serveis del Tabalet.');(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V18.md').write_text("""# Mataró, ciutat d’escoles — V18, 19-11-2026
Paquet acumulatiu. Obre index.html. Sense publicació en línia.
146 fites de 73/75 codis (97,3% amb qualsevol fita). 57 camps amb data relacionada amb l’origen i 18 buits. No són 57 fundacions verificades.

Novetat d’origen: creació administrativa del CFA Can Marfà, codi 08060253, pel Decret 213/2007 de 25 de setembre, per transformació de l’AFA Rocafonda. Text normatiu consultat al Full de disposicions 1156, p. 4679. El camp es tipifica com a creació administrativa; fundacio_any buit i origen de l’aula anterior pendent. El curs 2007–2008 és d’adequació normativa, no primer curs escolar observat. No s’uneixen Can Marfà i Can Noè per similitud de noms.

Sis fites noves: creació administrativa i adequació normativa del CFA Can Marfà; construcció de l’equipament educatiu de Can Noè entre 1985 i 1987, vinculada a adults i a la bressol Rocafonda (mateixa obra amb dues relacions); noves inscripcions del Tabalet el 09-01-2004 i inici de la seva cuina central el 19-01-2004. No s’afegeix de nou el trasllat del 08-01 ja documentat. Vegeu pistes_documentals_v18.md.

Fitxers vigents: base CSV/GeoJSON, esdeveniments_historics_v18.csv, fonts_historiques_v18.csv, auditoria_origens_v18.csv, pistes_origen_per_revisar_v18.csv, revisio_origens_v18.csv, registre_recerca_v18.csv i resum_auditoria.json. Historial de versions conservat; no sumar files. Les discrepàncies i pistes anteriors encara obertes es conserven.

Mapa, cronologia, cobertura i auditoria sincronitzats. Cap geometria modificada: les obres històriques no daten la seu actual. Dos codis sense fita: Col·legi Salesià 08065123 i Picasoques 08078695. Els 75 codis no equivalen a 75 centres actius confirmats. Consultes no enviades.

Validació automatitzada: codis, fonts, dates, CSV/GeoJSON/visor, 146 articles, 75 files d’auditoria i cobertura, JavaScript, enllaços locals, SHA256 i ZIP. Sense inspecció visual en navegador.
""")
shutil.copy2(__file__,out/'amplia_mataro_v18.py')
assert len(a)==75 and len(audit)==75 and norigin==57 and len(E)==146
assert len({e['id_esdeveniment'] for e in E})==146
assert all(e['id_font'] in fm and e['data_min']<=e['data_max'] for e in E)
assert chron.count('<article data-year=')==146
assert '146 fites' in chron and '146 fites' in idx
assert (out/'cobertura.html').read_text().count('<tr>')==76
payload=re.search(r'const centres=(.*?);const esc=',idx,re.S).group(1)
assert json.loads(payload)==a
assert all(f['properties']==am[f['properties']['codi_centre']] for f in g['features'])
assert len([f for f in g['features'] if f['geometry']])==73
for name in ['index.html','cronologia.html','cobertura.html','auditoria-origens.html']:
 text=(out/name).read_text()
 for link in re.findall(r'href="([^"#]+)"',text):
  if not link.startswith(('http:','https:',chr(39))):assert (out/link).exists(),link
 for i,s in enumerate(re.findall(r'<script>(.*?)</script>',text,re.S)):
  path=Path('/tmp')/('v16_'+name+str(i)+'.js');path.write_text(s);subprocess.run(['node','--check',str(path)],check=True,capture_output=True)
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'};(out/'SHA256.json').write_text(json.dumps(manifest,indent=2))
zp=B/'Mataro_ciutat_escoles_V18_adults_i_bressols_2026-11-19.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v18/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(json.dumps(dict(zip=str(zp),fites=len(E),camps_origen=norigin,pendents=75-norigin)))
