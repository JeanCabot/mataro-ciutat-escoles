import csv,json,shutil,re,zipfile,hashlib,html
from pathlib import Path
B=Path(__file__).parent; src=B/'mataro_escoles_v2'; out=B/'mataro_escoles_v3'
shutil.copytree(src,out,dirs_exist_ok=True)
def read(name):
 with (out/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(name,rows):
 with (out/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
F={
'H01':('Escola Pia de Catalunya — història','https://escolapia.cat/historia/'),
'H02':('Arxiu Provincial de l’Escola Pia — Mataró','https://ddapepc.escolapia.cat/ex%C3%A0mens-i-cert%C3%A0mens-acad%C3%A8mics-s-xviii-i-xix/matar%C3%B3'),
'H03':('Maristes — història de Valldemia','https://www.maristes.cat/ca/lescola/coneix-nos/historia-del-centre-0'),
'H04':('Institut Miquel Biada — presentació i història','https://www.biada.org/ca/el-centre/presentacio-i-historia/'),
'H05':('Ajuntament — acta del Ple 13-04-2023','https://www.mataro.cat/ca/lajuntament/ple/actes-del-ple/2023/13-04-2023/20230413_acta_ple_municipal.pdf'),
'H06':('Ajuntament — acta del Ple 08-09-2022','https://www.mataro.cat/ca/lajuntament/ple/actes-del-ple/2022/20220908_acta_ple_municipal-1.pdf'),
'H07':('Institut Miquel Biada — codi actual','https://www.biada.org/ca/empreses/perfil-del-contractant/'),
'H08':('Ajuntament — terrenys per a Joan Coromines, 18-01-2019','https://www.mataro.cat/ca/actualitat/noticies/2019/mataro-posa-a-disposicio-de-la-generalitat-els?set_language=ca')}
write('fonts_historiques_v3.csv',[{'id_font':k,'titol':v[0],'url':v[1],'consulta':'2026-11-18','tipus':'institucional','abast':'font publicada; no substitueix la consulta dels expedients originals'} for k,v in F.items()])
E=[]
def ev(code,centre,kind,d1,d2,precision,claim,f,notes='',locator=''):
 E.append({'id_esdeveniment':f'HIST-{len(E)+1:03}','id_entitat':'ENT-BIADA' if code=='08077976' else 'ENT-'+code,'codi_actual_referencia':code,'centre':centre,'tipus':kind,'data_min':d1,'data_max':d2,'precisio':precision,'afirmacio':claim,'id_font':f,'font_url':F[f][1],'localitzador':locator,'estat':'documentat en font institucional','notes':notes})
ev('08021107','Escola Pia de Mataró','establiment','1737','1737','any','Establiment de l’Escola Pia a Mataró.','H01','No equival a l’obertura de l’edifici actual.','Secció Mataró (1737–)')
ev('08021107','Escola Pia de Mataró','obertura_seu','1738-01','1738-01','mes','Obertura del col·legi a la Fonda del Pardal, Camí Ral amb Sant Antoni.','H02','La font arxivística dona el mes; no s’hi afegeix un dia exacte.','Introducció de la pàgina Mataró')
ev('08021144','Maristes Valldemia','fundacio','1855','1855','any','Fundació del Col·legi de Catalunya–Valldemia com a centre privat seglar.','H03')
ev('08021144','Maristes Valldemia','denominacio','1858','1858','any','El centre és conegut com a Valldemia.','H03')
ev('08021144','Maristes Valldemia','gestio','1888','1888','any','El centre s’incorpora a les obres dels Germans Maristes.','H03','No és una nova fundació.')
ev('08021144','Maristes Valldemia','coeducacio','1978','1978','any','Comencen els estudis mixtos al centre.','H03')
ev('08077976','Institut Miquel Biada','antecedent_institucional','1886','1886','any','Creació de l’Escola d’Arts i Oficis, antecedent que el centre reconeix a la plaça de l’Ajuntament.','H04','L’antecedent no és el codi registral actual ni la seu actual.')
ev('08077976','Institut Miquel Biada','transformacio','1958','1958','any','L’Escola es transforma en centre de formació professional.','H04')
ev('08077976','Institut Miquel Biada','trasllat','1967','1968','curs 1967/1968','Trasllat a l’edifici d’avinguda Puig i Cadafalch 89–99.','H04','L’interval representa un curs escolar, no dues dates exactes d’obertura.')
ev('08077976','Institut Miquel Biada','ensenyament','1993','1994','curs 1993/1994','Inici de la impartició d’ESO.','H04')
ev('08077976','Institut Miquel Biada','titularitat','2022-09-01','2022-09-01','dia','Pas de titularitat municipal a la xarxa de centres de la Generalitat.','H05','Confirmat també per la història del centre H04.','Antecedents del punt 14: preus públics d’educació')
ev('08067661','Escola Joan Coromines','creacio','2007','2008','curs 2007/2008','Creació del centre, ubicat provisionalment als espais de l’antiga Anxaneta de Sant Pere i Pascual Madoz.','H08','La notícia retrospectiva de 2019 documenta el curs; no un dia concret.')
ev('08067661','Escola Joan Coromines','planificacio_seu','2019-01-18','2019-01-18','data_publicacio','Notícia municipal sobre la posada a disposició dels terrenys de l’Eix Herrera per a una futura escola.','H08','No prova la construcció, l’obertura ni un trasllat efectiu. La data és de publicació.')
E.sort(key=lambda e:e['data_min'])
write('esdeveniments_historics_v3.csv',E)
a=read('mataro_centres_2026_2027.csv')
for r in a:
 r['id_entitat']='ENT-BIADA' if r['codi_centre']=='08077976' else 'ENT-'+r['codi_centre']
 r['tipus_data_origen']='';r['origen_data_min']='';r['origen_data_max']=''
 if r['codi_centre']=='08021107':r.update(fundacio_any='1737',fundacio_font=F['H01'][1],estat_recerca_historica='primeres fites documentades; història incompleta',tipus_data_origen='establiment',origen_data_min='1737',origen_data_max='1737')
 if r['codi_centre']=='08021144':r.update(fundacio_any='1855',fundacio_font=F['H03'][1],estat_recerca_historica='primeres fites documentades; història incompleta',tipus_data_origen='fundació',origen_data_min='1855',origen_data_max='1855')
 if r['codi_centre']=='08067661':r.update(fundacio_any='',fundacio_font=F['H08'][1],estat_recerca_historica='creació documentada al curs 2007/2008',tipus_data_origen='creació per curs',origen_data_min='2007',origen_data_max='2008')
 if r['codi_centre']=='08077976':r.update(fundacio_any='',fundacio_font=F['H04'][1],estat_recerca_historica='antecedent de 1886 i continuïtat documentats; no confondre amb alta registral',tipus_data_origen='antecedent institucional',origen_data_min='1886',origen_data_max='1886')
write('mataro_centres_2026_2027.csv',a)
geo=json.loads((out/'mataro_centres_2026_2027.geojson').read_text())
for f in geo['features']:f['properties']=next(r for r in a if r['codi_centre']==f['properties']['codi_centre'])
(out/'mataro_centres_2026_2027.geojson').write_text(json.dumps(geo,ensure_ascii=False,indent=2))
write('correspondencia_codis_entitats_v3.csv',[{'id_entitat':'ENT-BIADA','codi_centre':c,'estat':'continuïtat institucional documentada per triangulació','fonts':'H04 | H05 | H06 | H07','nota':'Es preserven ambdós codis. No s’atribueix automàticament una data exacta d’alta o baixa del codi.'} for c in ['08021259','08077976']])
old=read('conciliacio_codis_candidata.csv')
for r in old:r['estat']='RESOLT V3: continuïtat institucional documentada; vegeu correspondencia_codis_entitats_v3.csv';r['pendent']='Dates exactes d’alta i baixa dels codis pendents; no tractar com a tancament de la institució'
write('conciliacio_codis_candidata.csv',old)
# Cronologia independent del mapa contemporani: evita retroprojectar les ubicacions actuals.
items=''.join('<article data-year="'+e['data_min'][:4]+'"><b>'+html.escape(e['data_min'] if e['data_min']==e['data_max'] else e['precisio'])+' · '+html.escape(e['centre'])+'</b><p>'+html.escape(e['afirmacio'])+'</p><small>'+html.escape(e['notes'])+'</small><p><a href="'+html.escape(e['font_url'],quote=True)+'" target="_blank" rel="noopener">'+html.escape(F[e['id_font']][0])+'</a></p></article>' for e in E)
chron='''<!doctype html><html lang="ca"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Mataró · Primeres fites educatives</title><style>body{max-width:920px;margin:35px auto;padding:0 20px;font:16px system-ui;background:#f5f1e8;color:#223b39}h1{font:34px Georgia}article{background:white;border-left:4px solid #216c5a;margin:15px 0;padding:18px}small{display:block;line-height:1.5}a{color:#16665c}input{width:100%}</style><a href="index.html">← Mapa actual</a><h1>Mataró · Primeres fites educatives</h1><p>13 esdeveniments de quatre centres. Selecció documental inicial, sense pretensió d’exhaustivitat. La data de fundació d’una institució no situa automàticament la seva seu actual en el passat.</p><label for="year">Mostra fites amb inici fins a <b id="label">2026</b></label><input id="year" type="range" min="1737" max="2026" value="2026"><p id="n" role="status"></p>'''+items+'''<script>function paint(){let y=+document.getElementById('year').value,n=0;document.getElementById('label').textContent=y;document.querySelectorAll('article').forEach(a=>{a.hidden=+a.dataset.year>y;if(!a.hidden)n++});document.getElementById('n').textContent=n+' fites visibles. Els intervals de curs es mostren des del seu primer any, conservant la incertesa.'}document.getElementById('year').addEventListener('input',paint);paint();</script></html>'''
(out/'cronologia.html').write_text(chron)
page=(out/'index.html').read_text().replace('versió 2','versió 3')
page=re.sub(r'const centres=.*?;const esc=',lambda m:'const centres='+json.dumps(a,ensure_ascii=False).replace('</','<\\/')+';const esc=',page,count=1,flags=re.S)
page=page.replace('<nav>','<nav><a href="cronologia.html">Cronologia documentada · 13 fites</a>',1)
page=page.replace('Fundació: pendent de documentar',"Origen: '+esc(r.origen_data_min ? r.origen_data_min+(r.origen_data_max!==r.origen_data_min?'–'+r.origen_data_max:'')+' · '+r.tipus_data_origen : 'pendent de documentar')+'")
(out/'index.html').write_text(page)
seats=read('mataro_seus_observades.csv')
for s in seats:
 if s['codi_centre']=='08067661':s['inici_ocupacio']='curs 2007/2008 segons notícia retrospectiva de 2019';s['font_verificacio']+=' | H08'
 if s['codi_centre']=='08077976':s['inici_ocupacio']='curs 1967/1968 segons història del centre';s['font_verificacio']+=' | H04'
write('mataro_seus_observades.csv',seats)
sg=json.loads((out/'mataro_seus_v2.geojson').read_text())
for f in sg['features']:f['properties']=next(s for s in seats if s['id_seu_observada']==f['properties']['id_seu_observada'])
(out/'mataro_seus_v2.geojson').write_text(json.dumps(sg,ensure_ascii=False,indent=2))
st=json.loads((out/'resum_auditoria.json').read_text());st.update(versio=3,fites_historiques=13,centres_amb_fites=4,continuitats_institucionals_documentades=1)
(out/'resum_auditoria.json').write_text(json.dumps(st,ensure_ascii=False,indent=2))
(out/'LLEGEIX_ME_V3.md').write_text('''# Mataró, ciutat d’escoles — V3 · primeres fites
18-11-2026. Paquet acumulatiu; conserva la V2 i n’actualitza cens, visor i seus.

Obriu index.html (mapa actual, Internet necessari) o cronologia.html (13 fites amb selector d’any; es pot llegir sense connexió, llevat dels enllaços).

75 centres; 76 seus conegudes, 75 punts de seus. No s’han afegit ni suprimit centres actuals en aquesta fase. Picasoques continua pendent de coordenada exacta.

## Aportacions
- Quatre centres amb documentació històrica inicial: Escola Pia (establiment 1737; col·legi 1738), Valldemia (fundació 1855 i canvis), Miquel Biada (antecedent 1886, transformacions, trasllat i titularitat), Joan Coromines (creació 2007/2008 i planificació d’una seu el 2019).
- Les 13 fites són afirmacions sintetitzades de fonts institucionals, no transcripcions d’expedients primaris. Cada fila té font i precisió temporal.
- El mapa continua sent el cens actual. El selector de la cronologia només filtra fites; no representa les escoles actives a cada any ni projecta les seus actuals cap al passat.
- Biada: continuïtat institucional documentada entre els codis 08021259 i 08077976 per combinació d’actes i web del centre. Es preserven els codis. La data exacta de vigència de cada codi no s’ha deduït del canvi de titularitat.
- Origen de 1886 s’etiqueta com a antecedent de Biada, no com a data d’alta del centre administratiu actual. Coromines conserva el curs 2007/2008 sense convertir-lo en un dia exacte.
- El projecte de nou edifici de Coromines documentat el 2019 no s’ha convertit en obertura ni trasllat.

## Fitxers nous
esdeveniments_historics_v3.csv, fonts_historiques_v3.csv, correspondencia_codis_entitats_v3.csv, cronologia.html.
Els localitzadors de fonts HTML són seccions; la referència al Ple 2023 es localitza pel punt 14. Les fonts poden canviar: caldrà capturar-ne còpies documentals en una fase d’arxiu.

## Següent fase
Ampliar a altres centres amb dates contrastades; identificar i geolocalitzar seus històriques; documentar baixes i fusions; contrastar els concerts per etapa. Només després construir intervals d’activitat cartogràfica amb cobertures i incerteses explícites.

Els scripts previs es conserven com a antecedents. amplia_mataro_v3.py registra aquesta transformació i requereix el paquet V2 en una carpeta germana. LLEGEIX_ME.md descriu la V2; aquest document és la guia vigent de V3.
''')
shutil.copy2(__file__,out/'amplia_mataro_v3.py')
assert len(E)==13 and len({e['codi_actual_referencia'] for e in E})==4 and len(a)==75
for name in ['index.html','cronologia.html']:
 scripts=re.findall(r'<script>(.*?)</script>',(out/name).read_text(),re.S)
 for i,s in enumerate(scripts):Path('/tmp/'+name+str(i)+'.js').write_text(s)
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256.json'}
(out/'SHA256.json').write_text(json.dumps(manifest,indent=2))
zp=B/'Mataro_ciutat_escoles_V3_cronologia_2026-11-18.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,'mataro_escoles_v3/'+str(p.relative_to(out)))
with zipfile.ZipFile(zp) as z:assert z.testzip() is None
print(zp)
