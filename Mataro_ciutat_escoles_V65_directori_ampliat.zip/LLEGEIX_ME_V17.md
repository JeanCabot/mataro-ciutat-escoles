# Mataró, ciutat d’escoles — V17, 18-11-2026
Paquet acumulatiu. Obre index.html. Sense publicació en línia.
140 fites de 73/75 codis (97,3% amb qualsevol fita). Es mantenen 56 camps amb una data relacionada amb l’origen i 19 buits. Cap origen nou resolt en aquesta fase.
Sis fites noves: creació d’unitats a Josep Montserrat (31-08-1964); reorganització i transformació d’unitats a Peramàs (08-01-1979 i 17-08-1979); projectes arquitectònics (1993–1998), obres (1998–1999) i ampliació d’espais docents (2016–2017) del Damià Campeny. Els intervals arquitectònics són períodes, no cursos.
Les fonts daten fets diferents de la fundació. No s’omple el camp d’origen amb la primera fita documentada. Vegeu pistes_documentals_v17.md per als límits i els contrastos pendents, incloses les dates de Josep Montserrat.
Fitxers vigents: base canònica CSV/GeoJSON, esdeveniments_historics_v17.csv, fonts_historiques_v17.csv, auditoria_origens_v17.csv, pistes_origen_per_revisar_v17.csv, registre_recerca_v17.csv i resum_auditoria.json. La revisió d’orígens V16 i les discrepàncies V15 es conserven com a antecedents. Versions anteriors: no sumar files.
Mapa, cronologia, auditoria i cobertura sincronitzats. Cap geometria nova. Dos codis continuen sense fita: Col·legi Salesià 08065123 i Picasoques 08078695. Els 75 codis no equivalen a 75 centres actius confirmats. Consultes documentals no enviades.
Validació automatitzada de codis, fonts, dates, coherència CSV/GeoJSON/visor, 140 articles, 75 files d’auditoria i cobertura, JavaScript, enllaços locals, SHA256 i ZIP. Sense inspecció visual en navegador.
