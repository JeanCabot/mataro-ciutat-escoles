# V58 · Fotografies

74 de 164 fitxes amb fotografia.

- Piscina del Centre Natació Mataró en una fotografia de 2008 · Sergiportero · Domini públic per cessió de l’autor · Redimensionada a WebP · https://commons.wikimedia.org/wiki/File:CNMataro.JPG
