# Mataró, ciutat d’escoles — V14, 18-11-2026
Paquet acumulatiu. Obre index.html, cronologia.html i auditoria-origens.html. Sense publicació en línia.

125 fites, 73/75 codis amb alguna fita. 51 camps d’origen informats i 24 buits. Aquests camps no equivalen a 51 fundacions verificades: inclouen antecedents, autoritzacions, inauguracions, dates declarades i consolidació de projectes.

Cinc camps nous: Les Aigües (obertura del predecessor Santa Bernadeta el curs 1966–1967), Cenafe (autorització de 24-10-2016), Snoopy (origen declarat 1980 segons anunci conservat), Vista Alegre (antecedent d’aulari a la dècada 1970–1979) i Gi (consolidació del projecte el 2012 segons la directora). Els tres darrers reutilitzen fites existents i no generen nous esdeveniments. No es converteix cap dècada ni autorització en un primer dia de classes.

Les Aigües: glosa històrica de la Fundació el Maresme de 2026. Afegeix obertura de Santa Bernadeta el curs 1966–1967 i inauguració oficial el 26-10-1966. Precisa la conversió en escola pública Les Aigües l’1-09-1990 a la fita HIST-088, conservant-ne l’identificador. No implica que el codi públic actual existís el 1966 ni que l’edifici actual fos llavors ocupat. El relat institucional és retrospectiu; contrast amb documents contemporanis pendent.
Cenafe: text íntegre ENS/2463/2016 confirma codi 08075475 i plaça Canigó 7. Resolució 24-10-2016, publicació 08-11-2016, efectes des de l’inici del curs 2016–2017. No és el canvi de titular de 2020 ni prova de primeres classes. No s’afegeix una geometria nova.
Angeleta Ferrer: s’afegeix el pla estratègic 2000–2004 com a fita d’etapa; el camp d’origen segueix buit. La història del solar o de l’edifici no data automàticament la fundació de l’escola; altres dates del relat requereixen contrast.

Dades vigents: esdeveniments_historics_v14.csv, fonts_historiques_v14.csv, auditoria_origens_v14.csv, pistes_origen_per_revisar_v14.csv, revisio_cinc_origens_v14.csv i base canònica CSV/GeoJSON. Versions anteriors: checkpoints; no sumar registres. Es conserven mapa, cronologia, auditoria, proves i scripts. Consultes documentals de V12 encara sense enviar.

Continuen sense fita atribuïble Col·legi Salesià 08065123 i Picasoques 08078695. Les geometries i els avisos de vigència es mantenen: 73 punts de centre, 78 observacions de seu, 75 codis de base que no equivalen a 75 centres actius confirmats.

Validació de codis, fonts, intervals, dades del visor, GeoJSON, 125 articles de cronologia, 75 files d’auditoria, sintaxi JavaScript, enllaços locals, SHA256 i integritat ZIP. Sense inspecció visual en navegador ni auditoria arxivística exhaustiva.
