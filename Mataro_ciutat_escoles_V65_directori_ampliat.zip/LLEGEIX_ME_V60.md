# V60 · Instagram

Sis fitxes guanyen un enllaç i dues passen al perfil específic.

- Instagram del Consorci Sanitari del Maresme · [@csdmaresme_oficial](https://www.instagram.com/csdmaresme_oficial/) · [Font](https://www.csdm.cat/ca/actualitat/noticies/1852/obrim-compte-a-instagram)
- Instagram del Consorci Sanitari del Maresme · [@csdmaresme_oficial](https://www.instagram.com/csdmaresme_oficial/) · [Font](https://www.csdm.cat/ca/actualitat/noticies/1852/obrim-compte-a-instagram)
- Instagram de Nemomarlin · [@escuelasinfantilesnemomarlin](https://www.instagram.com/escuelasinfantilesnemomarlin/) · [Font](https://escuelanemomarlin.com/)
- Instagram de hoy-voy · [@hoyvoyautoescuelas](https://www.instagram.com/hoyvoyautoescuelas/) · [Font](https://www.youtube.com/watch?v=zBCvW3pgKS4)
- Instagram del Gremi d’Hostaleria · [@gremihostaleriamataro](https://www.instagram.com/gremihostaleriamataro/) · [Font](https://gremihostaleria.com/contacte/)
- Instagram del Centre Atlètic Laietània · [@atletismelaietania](https://www.instagram.com/atletismelaietania/) · [Font](https://atletismelaietania.com/)
- Instagram de l’Aula de Teatre · [@auladeteatredemataro](https://www.instagram.com/auladeteatredemataro/) · [Font](https://carecitylab.cat/ca/actualitat/xarxes-socials/xarxes-socials)
- Instagram de Mataró Art Contemporani · [@mac_mataro](https://www.instagram.com/mac_mataro/) · [Font](https://carecitylab.cat/ca/actualitat/xarxes-socials/xarxes-socials)
