# V25 · Lleure i casals

Obre index.html. La capa Lleure i casals està activada en obrir el mapa.

13 entitats i 24 casals, agrupats en 31 ubicacions. Les fitxes indiquen l’adreça documentada i el període quan consta. Les coordenades de la capa procedeixen de l’ICGC. La Riera 182 es representa amb el punt del tram 124–182 de Valldemia. CRAJEC es representa amb el punt de l’equipament Centre Cívic Rocafonda.
