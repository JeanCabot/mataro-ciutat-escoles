# Mataró, ciutat d’escoles — V10, 18-11-2026
Paquet acumulatiu. Obre index.html per al mapa, cronologia.html per a les fites i cobertura.html per al progrés. No s’ha publicat en línia.

113 fites de 71 dels 75 codis de base (94,7%); són històries parcials, no 71 fundacions verificades. La Fada s’incorpora amb les metadades institucionals d’autorització per nom i municipi: codi, adreça i efectes del text íntegre encara pendents. Sense aquest cas parcial, cobertura 70/75 (93,3%). Els 75 són els codis del CSV aportat; no tots són centres actius confirmats.

Novetats: La Caseta, resolució 28-03-2011 amb efectes des de l’inici del curs 2010–2011; Petit Somni, resolució 14-05-2014 amb efectes des del curs 2014–2015; Peques, canvi explícit a Acuarella Mataró el 08-11-2018; La Fada, autorització ENS/21/2014 de 02-01-2014 segons CIDO. Sant Josep: comunitat religiosa formal de 1970 i commemoració de 06-05-2023; fundació única 1968/1970 pendent. Resolució, publicació, efectes legals i primer dia de classes són conceptes separats.

Quatre codis sense fita atribuïble: Col·legi Salesià 08065123, Picasoques 08078695, Heidi Consegal 08056948 i GiEscola 08078877. La resolució salesiana de 2004 porta 08021089 i s’ha incorporat a aquest codi, sense transferir-la al codi adult 08065123. La correcció posterior només esmena la comarca. Cal acte de conciliació de codis.

Fitxers vigents: esdeveniments_historics_v10.csv, fonts_historiques_v10.csv, revisio_9_centres_v10.csv, evidencies_sense_fita_v10.csv, discrepancies_i_pistes_v10.csv, cobertura_recerca_v10.csv, mataro_centres_2026_2027.csv/.geojson i inventari de seus. Els fitxers V1–V9 es mantenen com a checkpoints: no s’han de sumar. Documents oficials consultats de V10 i text extret a documents_v10; La Fada conserva la fitxa CIDO i no un PDF que no s’ha pogut obtenir.

El nom Peques del CSV es conserva, amb nota de denominació legal de 2018; Misha i vigència posterior encara pendents. Es mantenen les correccions V9: Nemomarlin cessat, seu antiga del Liceu tancada, Figueretes provisional a Isern 18 sense geometria inventada. Mapa amb 73 punts i 78 observacions de seu (no 78 seus actives). El filtre temporal representa fites, no un cens complet d’escoles actives per any.

Validació: codis i fonts íntegres, intervals coherents, 113 articles a cronologia, propietats GeoJSON i dades del visor sincronitzades, sintaxi JavaScript correcta, enllaços locals, SHA256 i integritat ZIP. Sense inspecció visual en navegador ni comprovació arxivística exhaustiva.
